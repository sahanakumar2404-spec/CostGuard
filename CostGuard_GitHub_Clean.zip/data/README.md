# CostGuard Data Directory
# Reserved for cloud pricing databases, SKU reference catalogs, and mapping caches (Phase 2+).
