$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$venvPython = Join-Path $scriptDir ".venv\Scripts\python.exe"

if (Test-Path $venvPython) {
    & $venvPython -m costguard $args
} else {
    python -m costguard $args
}
exit $LASTEXITCODE
