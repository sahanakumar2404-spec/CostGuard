"""
CostGuard Terraform Plan Parser
Parses Terraform speculative execution plan JSON and extracts structured resource changes.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Optional, TextIO, Union

from costguard.models import ActionType, PlanParseResult, ResourceChange

# Common known resource type prefixes across major cloud providers
KNOWN_PROVIDER_PREFIXES = (
    "aws_",
    "azurerm_",
    "azuread_",
    "google_",
    "google-beta_",
    "oci_",
    "alicloud_",
    "openstack_",
    "kubernetes_",
    "helm_",
    "cloudflare_",
    "datadog_",
    "snowflake_",
    "mongodbatlas_",
    "null_",
    "random_",
    "local_",
    "tls_",
    "time_",
    "vault_",
)

# Common resource types where SKU / size is typically expected
COMPUTE_AND_DB_TYPES = (
    "instance",
    "vm",
    "database",
    "db",
    "cluster",
    "disk",
    "volume",
    "node_pool",
    "node_group",
    "redis",
    "elasticache",
    "service_plan",
    "app_service",
)


def normalize_action(raw_actions: Any) -> ActionType:
    """
    Normalizes Terraform plan change actions into standard ActionType.

    Terraform actions list possibilities:
      - ["create"] -> ActionType.CREATE
      - ["delete"] -> ActionType.DELETE
      - ["update"] -> ActionType.UPDATE
      - ["delete", "create"] -> ActionType.REPLACE
      - ["create", "delete"] -> ActionType.REPLACE
      - ["no-op"] -> ActionType.NOOP
      - ["read"] -> ActionType.NOOP
    """
    if not raw_actions:
        return ActionType.UNKNOWN

    if isinstance(raw_actions, str):
        raw_actions = [raw_actions]

    if not isinstance(raw_actions, (list, tuple)):
        return ActionType.UNKNOWN

    actions_lower = [str(a).lower().strip() for a in raw_actions if a is not None]

    if not actions_lower:
        return ActionType.UNKNOWN

    # Check for replacement (delete and create in any order)
    if "delete" in actions_lower and "create" in actions_lower:
        return ActionType.REPLACE

    if len(actions_lower) == 1:
        single = actions_lower[0]
        if single == "create":
            return ActionType.CREATE
        elif single == "delete":
            return ActionType.DELETE
        elif single == "update":
            return ActionType.UPDATE
        elif single in ("no-op", "read"):
            return ActionType.NOOP
        elif single == "replace":
            return ActionType.REPLACE

    # Fallback checks
    if "create" in actions_lower:
        return ActionType.CREATE
    if "delete" in actions_lower:
        return ActionType.DELETE
    if "update" in actions_lower:
        return ActionType.UPDATE

    return ActionType.UNKNOWN


def extract_sku(resource_type: str, state: Optional[dict[str, Any]]) -> Optional[str]:
    """
    Extracts SKU / VM size / instance type / tier from resource state dictionary.
    Handles AWS, Azure, GCP, and generic patterns.
    """
    if not state or not isinstance(state, dict):
        return None

    res_type = resource_type.lower()

    # AWS Specific
    if res_type == "aws_instance":
        return state.get("instance_type")
    if res_type in ("aws_db_instance", "aws_rds_cluster_instance"):
        return state.get("instance_class")
    if res_type in ("aws_elasticache_cluster", "aws_elasticache_replication_group", "aws_redshift_cluster"):
        return state.get("node_type")
    if res_type == "aws_ebs_volume":
        vol_type = state.get("type") or state.get("volume_type")
        size = state.get("size")
        if vol_type and size:
            return f"{vol_type} ({size}GB)"
        return vol_type or (f"{size}GB" if size else None)
    if res_type == "aws_eks_node_group":
        types = state.get("instance_types")
        if isinstance(types, list) and types:
            return str(types[0])
        return str(types) if types else None
    if res_type == "aws_launch_template":
        return state.get("instance_type")

    # Azure Specific
    if res_type in ("azurerm_linux_virtual_machine", "azurerm_windows_virtual_machine"):
        return state.get("size")
    if res_type == "azurerm_virtual_machine":
        return state.get("vm_size") or state.get("size")
    if res_type == "azurerm_managed_disk":
        sat = state.get("storage_account_type")
        disk_size = state.get("disk_size_gb")
        if sat and disk_size:
            return f"{sat} ({disk_size}GB)"
        return sat or (f"{disk_size}GB" if disk_size else None)
    if res_type in ("azurerm_mssql_database", "azurerm_service_plan"):
        return state.get("sku_name")
    if res_type == "azurerm_storage_account":
        tier = state.get("account_tier")
        rep = state.get("account_replication_type")
        if tier and rep:
            return f"{tier}_{rep}"
        return tier or rep

    # GCP Specific
    if res_type in ("google_compute_instance", "google_compute_instance_template"):
        return state.get("machine_type")
    if res_type == "google_compute_disk":
        disk_type = state.get("type")
        size = state.get("size")
        if disk_type and size:
            return f"{disk_type} ({size}GB)"
        return disk_type or (f"{size}GB" if size else None)
    if res_type == "google_sql_database_instance":
        settings = state.get("settings")
        if isinstance(settings, dict):
            tier = settings.get("tier")
            if tier:
                return tier
        elif isinstance(settings, list) and settings and isinstance(settings[0], dict):
            tier = settings[0].get("tier")
            if tier:
                return tier
        return state.get("tier")
    if res_type == "google_storage_bucket":
        return state.get("storage_class")

    # Generic Fallback Search
    for key in (
        "instance_type",
        "machine_type",
        "vm_size",
        "size",
        "sku_name",
        "instance_class",
        "node_type",
        "tier",
        "storage_class",
        "storage_account_type",
        "volume_type",
        "shape",
        "flavor",
    ):
        val = state.get(key)
        if val is not None and not isinstance(val, (dict, list)):
            return str(val)

    # Check nested "sku" dict
    sku_val = state.get("sku")
    if isinstance(sku_val, dict):
        return sku_val.get("name") or sku_val.get("size")
    elif isinstance(sku_val, str):
        return sku_val

    return None


def extract_region(resource_type: str, state: Optional[dict[str, Any]]) -> Optional[str]:
    """
    Extracts cloud region / location from resource state dictionary.
    Handles AWS availability zones, Azure locations, GCP zones/regions, and generic patterns.
    """
    if not state or not isinstance(state, dict):
        return None

    # Direct explicit region or location
    region = state.get("region")
    if region and isinstance(region, str):
        return region

    location = state.get("location")
    if location and isinstance(location, str):
        return location

    # AWS availability_zone handling
    az = state.get("availability_zone")
    if az and isinstance(az, str):
        # Extract region from AZ (e.g. us-east-1a -> us-east-1, eu-west-1b -> eu-west-1)
        match = re.match(r"^([a-z]{2}-[a-z]+-\d+)[a-z]$", az)
        if match:
            return match.group(1)
        return az

    # GCP zone handling
    zone = state.get("zone")
    if zone and isinstance(zone, str):
        # Extract region from GCP zone (e.g. us-central1-a -> us-central1)
        match = re.match(r"^([a-z]+-[a-z]+\d+)-[a-z]$", zone)
        if match:
            return match.group(1)
        return zone

    # Check ARN or resource ID for embedded region
    for id_key in ("arn", "id", "self_link"):
        id_val = state.get(id_key)
        if isinstance(id_val, str):
            # AWS ARN format: arn:partition:service:region:account-id:resource-id
            arn_match = re.search(r"^arn:[^:]*:[^:]*:([^:]*):", id_val)
            if arn_match and arn_match.group(1):
                return arn_match.group(1)
            # GCP self_link zone format: .../zones/([a-z]+-[a-z]+\d+-[a-z])/...
            gcp_match = re.search(r"/zones/([a-z]+-[a-z]+\d+)", id_val)
            if gcp_match:
                return gcp_match.group(1)
            # Azure resource ID location is often not in the ID, but location key is standard

    # Generic fallbacks
    for key in ("placement_region", "geo"):
        val = state.get(key)
        if isinstance(val, str) and val:
            return val

    return None


def parse_plan_dict(plan: dict[str, Any]) -> PlanParseResult:
    """
    Parses a pre-loaded Terraform plan dictionary into a PlanParseResult.
    Guaranteed not to raise uncaught exceptions on missing fields or malformed data.
    """
    warnings: list[str] = []
    resource_changes: list[ResourceChange] = []

    if not isinstance(plan, dict):
        warnings.append(f"Plan root must be a JSON object, got {type(plan).__name__}")
        return PlanParseResult(warnings=warnings)

    format_version = plan.get("format_version")
    terraform_version = plan.get("terraform_version")

    raw_changes = plan.get("resource_changes")
    if raw_changes is None:
        warnings.append("Plan is missing 'resource_changes' field")
        return PlanParseResult(
            resource_changes=[],
            warnings=warnings,
            format_version=format_version,
            terraform_version=terraform_version,
            raw_plan=plan,
        )

    if not isinstance(raw_changes, list):
        warnings.append(f"'resource_changes' must be a list, got {type(raw_changes).__name__}")
        return PlanParseResult(
            resource_changes=[],
            warnings=warnings,
            format_version=format_version,
            terraform_version=terraform_version,
            raw_plan=plan,
        )

    if len(raw_changes) == 0:
        warnings.append("Plan 'resource_changes' list is empty")
        return PlanParseResult(
            resource_changes=[],
            warnings=warnings,
            format_version=format_version,
            terraform_version=terraform_version,
            raw_plan=plan,
        )

    for idx, item in enumerate(raw_changes):
        if not isinstance(item, dict):
            warnings.append(f"Resource change item #{idx} is not an object: {repr(item)}")
            continue

        # Extract address
        address = item.get("address")
        if not address or not isinstance(address, str):
            address = item.get("name") if isinstance(item.get("name"), str) else f"unknown_resource_{idx}"
            warnings.append(f"Resource change #{idx} missing 'address'; defaulting to '{address}'")

        # Extract resource_type
        resource_type = item.get("type") or item.get("resource_type")
        if not resource_type or not isinstance(resource_type, str):
            # Attempt to deduce type from address prefix (e.g. 'aws_instance.web' -> 'aws_instance')
            if "." in address:
                resource_type = address.split(".")[0]
            else:
                resource_type = "unknown"
            warnings.append(f"Resource '{address}' missing 'type'; defaulted to '{resource_type}'")

        # Validate resource type
        if not any(resource_type.startswith(p) for p in KNOWN_PROVIDER_PREFIXES):
            warnings.append(f"Resource '{address}' has unrecognized or custom resource type '{resource_type}'")

        # Extract change block
        change_block = item.get("change")
        if not isinstance(change_block, dict):
            # Fallback: check if actions/before/after are directly on the item
            if any(k in item for k in ("actions", "before", "after")):
                change_block = item
            else:
                change_block = {}
                warnings.append(f"Resource '{address}' missing 'change' block")

        # Extract actions
        raw_actions = change_block.get("actions")
        action = normalize_action(raw_actions)

        # Extract states
        before_state = change_block.get("before")
        after_state = change_block.get("after")

        if before_state is not None and not isinstance(before_state, dict):
            before_state = None
        if after_state is not None and not isinstance(after_state, dict):
            after_state = None

        # If action was UNKNOWN, attempt inference from before/after presence
        if action == ActionType.UNKNOWN:
            if before_state is None and after_state is not None:
                action = ActionType.CREATE
                warnings.append(f"Resource '{address}': missing actions inferred as CREATE from states")
            elif before_state is not None and after_state is None:
                action = ActionType.DELETE
                warnings.append(f"Resource '{address}': missing actions inferred as DELETE from states")
            elif before_state is not None and after_state is not None:
                action = ActionType.UPDATE
                warnings.append(f"Resource '{address}': missing actions inferred as UPDATE from states")
            else:
                warnings.append(f"Resource '{address}' has unknown action: {raw_actions}")

        # State completeness warnings
        if action in (ActionType.UPDATE, ActionType.DELETE, ActionType.REPLACE) and before_state is None:
            warnings.append(f"Resource '{address}' ({action.value}) missing 'before' state")
        if action in (ActionType.CREATE, ActionType.UPDATE, ActionType.REPLACE) and after_state is None:
            warnings.append(f"Resource '{address}' ({action.value}) missing 'after' state")

        # Extract SKU / VM sizes
        old_sku = extract_sku(resource_type, before_state)
        new_sku = extract_sku(resource_type, after_state)

        # Extract region / location
        old_region = extract_region(resource_type, before_state)
        new_region = extract_region(resource_type, after_state)

        # SKU missing warning for compute/database types or unrecognized resource types
        effective_sku = new_sku or old_sku
        is_known_provider = any(resource_type.startswith(p) for p in KNOWN_PROVIDER_PREFIXES)
        is_compute_or_db = any(kw in resource_type.lower() for kw in COMPUTE_AND_DB_TYPES)
        if not effective_sku and (is_compute_or_db or not is_known_provider):
            warnings.append(f"Resource '{address}' ({resource_type}): SKU / VM size could not be determined")

        # Region / Location missing warning
        effective_region = new_region or old_region
        if not effective_region and (is_known_provider or not is_known_provider):
            warnings.append(f"Resource '{address}' ({resource_type}): Location / region could not be determined")

        rc = ResourceChange(
            address=address,
            resource_type=resource_type,
            action=action,
            before_state=before_state,
            after_state=after_state,
            old_sku=old_sku,
            new_sku=new_sku,
            old_region=old_region,
            new_region=new_region,
        )
        resource_changes.append(rc)

    return PlanParseResult(
        resource_changes=resource_changes,
        warnings=warnings,
        format_version=format_version,
        terraform_version=terraform_version,
        raw_plan=plan,
    )


def parse_plan_json(json_content: str) -> PlanParseResult:
    """
    Parses a Terraform plan JSON string.
    Safely captures JSONDecodeError and returns clean diagnostics.
    """
    if not json_content or not json_content.strip():
        return PlanParseResult(
            warnings=["Input is empty or whitespace only"],
        )

    try:
        plan_dict = json.loads(json_content)
    except json.JSONDecodeError as exc:
        return PlanParseResult(
            warnings=[f"Invalid JSON format: {exc.msg} (line {exc.lineno}, column {exc.colno})"],
        )
    except Exception as exc:
        return PlanParseResult(
            warnings=[f"Failed to parse JSON: {str(exc)}"],
        )

    return parse_plan_dict(plan_dict)


def parse_plan_file(filepath: Union[str, Path]) -> PlanParseResult:
    """
    Reads and parses a Terraform plan JSON from a file path.
    Safely catches file read errors.
    """
    path = Path(filepath)
    if not path.exists():
        return PlanParseResult(
            warnings=[f"Plan file not found: {filepath}"],
        )

    try:
        content = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        try:
            content = path.read_text(encoding="latin-1")
        except Exception as exc:
            return PlanParseResult(
                warnings=[f"Could not read plan file '{filepath}': {str(exc)}"],
            )
    except Exception as exc:
        return PlanParseResult(
            warnings=[f"Could not read plan file '{filepath}': {str(exc)}"],
        )

    return parse_plan_json(content)


def parse_plan(source: Union[str, Path, TextIO, dict[str, Any]]) -> PlanParseResult:
    """
    Universal entrypoint for parsing Terraform plan data from various input types:
      - dict (already parsed JSON)
      - Path or existing file path string
      - JSON string
      - File-like stream (sys.stdin)
    """
    if isinstance(source, dict):
        return parse_plan_dict(source)

    if isinstance(source, Path):
        return parse_plan_file(source)

    if hasattr(source, "read"):
        try:
            content = source.read()
            return parse_plan_json(content)
        except Exception as exc:
            return PlanParseResult(
                warnings=[f"Failed to read from input stream: {str(exc)}"],
            )

    if isinstance(source, str):
        # Check if it points to an existing file
        try:
            p = Path(source)
            if p.is_file():
                return parse_plan_file(p)
        except OSError:
            pass
        # Otherwise treat as JSON string
        return parse_plan_json(source)

    return PlanParseResult(
        warnings=[f"Unsupported plan source type: {type(source).__name__}"],
    )
