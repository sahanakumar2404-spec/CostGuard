"""
CostGuard SQLite Pricing Cache
Embedded write-through caching layer for cloud pricing lookups.
"""

from __future__ import annotations

import json
import sqlite3
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional


@dataclass
class CachedPrice:
    """
    Represents a cached pricing record.

    Attributes:
        resource_type: Normalized resource type (e.g. 'azurerm_linux_virtual_machine').
        sku: SKU / VM size (e.g. 'Standard_D4s_v5').
        region: Cloud region / location (e.g. 'eastus').
        price: Unit retail price (e.g. 0.192).
        currency: Pricing currency (default 'USD').
        retrieved_at: ISO 8601 UTC timestamp of retrieval.
        metadata: Additional metadata dictionary (meterName, unitOfMeasure, etc.).
    """
    resource_type: str
    sku: str
    region: str
    price: float
    currency: str = "USD"
    retrieved_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def unit_of_measure(self) -> str:
        return self.metadata.get("unit_of_measure", "1 Hour")

    @property
    def monthly_price(self) -> float:
        """Calculates estimated monthly cost based on unit of measure."""
        unit = self.unit_of_measure.lower()
        if "hour" in unit:
            return round(self.price * 730, 4)
        return round(self.price, 4)

    def to_dict(self) -> dict[str, Any]:
        return {
            "resource_type": self.resource_type,
            "sku": self.sku,
            "region": self.region,
            "price": self.price,
            "currency": self.currency,
            "retrieved_at": self.retrieved_at,
            "monthly_price": self.monthly_price,
            "metadata": self.metadata,
        }


class SQLitePricingCache:
    """
    Thread-safe SQLite write-through cache for cloud resource pricing.
    """

    DEFAULT_DB_PATH = Path(__file__).parent.parent / "data" / "pricing_cache.db"

    def __init__(self, db_path: Optional[Path | str] = None) -> None:
        if db_path is None:
            self.db_path = self.DEFAULT_DB_PATH
            # Ensure data directory exists
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            self._db_uri = str(self.db_path)
        elif str(db_path) == ":memory:":
            self._db_uri = ":memory:"
            self.db_path = Path(":memory:")
        else:
            self.db_path = Path(db_path)
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            self._db_uri = str(self.db_path)

        self._conn = sqlite3.connect(self._db_uri, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row

        # Metrics
        self.hits: int = 0
        self.misses: int = 0
        self.api_calls: int = 0

        self._init_db()

    def _init_db(self) -> None:
        """Creates table and indices if they do not already exist."""
        with self._conn:
            self._conn.execute(
                """
                CREATE TABLE IF NOT EXISTS pricing_cache (
                    lookup_key TEXT PRIMARY KEY,
                    resource_type TEXT NOT NULL,
                    sku TEXT NOT NULL,
                    region TEXT NOT NULL,
                    price REAL NOT NULL,
                    currency TEXT NOT NULL,
                    retrieved_at TEXT NOT NULL,
                    metadata TEXT
                )
                """
            )
            self._conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_lookup ON pricing_cache(lookup_key)"
            )
            self._conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_res_sku_reg ON pricing_cache(resource_type, sku, region)"
            )

    @staticmethod
    def normalize_key(resource_type: str, sku: str, region: str) -> str:
        """
        Builds a normalized, case-insensitive lookup key.
        e.g. 'azurerm_linux_virtual_machine:standard_d4s_v5:eastus'
        """
        r_type = resource_type.strip().lower()
        r_sku = sku.strip().lower()
        r_region = region.strip().lower().replace(" ", "").replace("-", "")
        return f"{r_type}:{r_sku}:{r_region}"

    def get(self, resource_type: str, sku: str, region: str) -> Optional[CachedPrice]:
        """
        Retrieves pricing from cache if available.
        Updates hit/miss counters.
        """
        if not resource_type or not sku or not region:
            return None

        key = self.normalize_key(resource_type, sku, region)
        cursor = self._conn.cursor()
        cursor.execute(
            """
            SELECT resource_type, sku, region, price, currency, retrieved_at, metadata
            FROM pricing_cache
            WHERE lookup_key = ?
            """,
            (key,),
        )
        row = cursor.fetchone()

        if row:
            self.hits += 1
            meta = {}
            if row["metadata"]:
                try:
                    meta = json.loads(row["metadata"])
                except Exception:
                    meta = {}
            return CachedPrice(
                resource_type=row["resource_type"],
                sku=row["sku"],
                region=row["region"],
                price=float(row["price"]),
                currency=row["currency"],
                retrieved_at=row["retrieved_at"],
                metadata=meta,
            )

        self.misses += 1
        return None

    def set(
        self,
        resource_type: str,
        sku: str,
        region: str,
        price: float,
        currency: str = "USD",
        metadata: Optional[dict[str, Any]] = None,
        retrieved_at: Optional[str] = None,
    ) -> CachedPrice:
        """
        Inserts or replaces a pricing entry in SQLite cache.
        """
        key = self.normalize_key(resource_type, sku, region)
        ts = retrieved_at or datetime.now(timezone.utc).isoformat()
        meta_dict = metadata or {}
        meta_json = json.dumps(meta_dict)

        with self._conn:
            self._conn.execute(
                """
                INSERT OR REPLACE INTO pricing_cache
                (lookup_key, resource_type, sku, region, price, currency, retrieved_at, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    key,
                    resource_type.strip(),
                    sku.strip(),
                    region.strip(),
                    float(price),
                    currency.strip(),
                    ts,
                    meta_json,
                ),
            )

        return CachedPrice(
            resource_type=resource_type,
            sku=sku,
            region=region,
            price=float(price),
            currency=currency,
            retrieved_at=ts,
            metadata=meta_dict,
        )

    def has(self, resource_type: str, sku: str, region: str) -> bool:
        """Checks if a key exists in cache without altering hit/miss counters."""
        key = self.normalize_key(resource_type, sku, region)
        cursor = self._conn.cursor()
        cursor.execute("SELECT 1 FROM pricing_cache WHERE lookup_key = ?", (key,))
        return cursor.fetchone() is not None

    def clear(self) -> None:
        """Clears all cached records and resets counters."""
        with self._conn:
            self._conn.execute("DELETE FROM pricing_cache")
        self.hits = 0
        self.misses = 0
        self.api_calls = 0

    def stats(self) -> dict[str, int]:
        """Returns statistics for cache performance."""
        return {
            "cache_hits": self.hits,
            "cache_misses": self.misses,
            "api_calls": self.api_calls,
        }

    def close(self) -> None:
        """Closes the underlying SQLite database connection."""
        if self._conn:
            self._conn.close()

    def __enter__(self) -> SQLitePricingCache:
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.close()
