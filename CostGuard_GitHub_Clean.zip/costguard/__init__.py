"""
CostGuard - Terraform Speculative Execution Plan Cost Analyzer.
Phase 1: Plan ingestion, resource change extraction, and structured modeling.
Phase 2: Azure Retail Prices API integration and SQLite write-through caching.
Phase 3: Cost accounting engine, monthly delta calculations, and budget circuit breaker.
"""

from costguard.accounting import (
    HOURS_PER_MONTH,
    CostAccountingEngine,
    CostAnalysisReport,
    ResourceCostChange,
    SkippedResource,
    format_cost_table,
    format_currency,
)
from costguard.cache import CachedPrice, SQLitePricingCache
from costguard.cli import main
from costguard.models import ActionType, PlanParseResult, ResourceChange
from costguard.parser import (
    extract_region,
    extract_sku,
    normalize_action,
    parse_plan,
    parse_plan_dict,
    parse_plan_file,
    parse_plan_json,
)
from costguard.pricing import AzurePricingClient, PriceResult

__version__ = "0.3.0"

__all__ = [
    "__version__",
    "HOURS_PER_MONTH",
    "ActionType",
    "ResourceChange",
    "PlanParseResult",
    "parse_plan",
    "parse_plan_json",
    "parse_plan_file",
    "parse_plan_dict",
    "extract_sku",
    "extract_region",
    "normalize_action",
    "SQLitePricingCache",
    "CachedPrice",
    "AzurePricingClient",
    "PriceResult",
    "CostAccountingEngine",
    "CostAnalysisReport",
    "ResourceCostChange",
    "SkippedResource",
    "format_cost_table",
    "format_currency",
    "main",
]
