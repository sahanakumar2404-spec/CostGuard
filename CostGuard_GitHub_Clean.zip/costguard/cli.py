"""
CostGuard CLI
Command-line interface for analyzing Terraform execution plans for resource changes,
monthly cost accounting, and budget circuit breaker enforcement.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Optional, Sequence

from costguard.accounting import CostAccountingEngine, CostAnalysisReport, format_cost_table
from costguard.cache import SQLitePricingCache
from costguard.models import ActionType, PlanParseResult, ResourceChange
from costguard.parser import parse_plan_file, parse_plan_json
from costguard.pricing import AzurePricingClient, PriceResult

__version__ = "0.3.0"

# Ensure UTF-8 output encoding on Windows consoles
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
if sys.stderr and hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def format_sku_transition(rc: ResourceChange) -> str:
    """Formats old -> new SKU transition for CLI display."""
    old = rc.old_sku or "-"
    new = rc.new_sku or "-"
    if rc.action == ActionType.CREATE.value:
        return new
    if rc.action == ActionType.DELETE.value:
        return old
    if old == new:
        return old
    return f"{old} -> {new}"


def format_region_transition(rc: ResourceChange) -> str:
    """Formats old -> new region transition for CLI display."""
    old = rc.old_region or "-"
    new = rc.new_region or "-"
    if rc.action == ActionType.CREATE.value:
        return new
    if rc.action == ActionType.DELETE.value:
        return old
    if old == new:
        return old
    return f"{old} -> {new}"


def print_human_report(
    result: PlanParseResult,
    pricing_map: Optional[dict[str, Any]] = None,
    pricing_stats: Optional[dict[str, int]] = None,
    verbose: bool = False,
) -> None:
    """Renders a clean, structured CLI report of resource changes and warnings."""
    summary = result.summary

    print("=" * 70)
    print("CostGuard (Phase 1) - Terraform Plan Resource Change Analyzer")
    print("=" * 70)

    # Metadata
    meta_parts = []
    if result.terraform_version:
        meta_parts.append(f"Terraform v{result.terraform_version}")
    if result.format_version:
        meta_parts.append(f"Format v{result.format_version}")
    if meta_parts:
        print(f"Plan Info: {' | '.join(meta_parts)}")

    print(f"Total Changes: {summary['total']}")
    print(
        f"  CREATE: {summary['create']}  |  "
        f"UPDATE: {summary['update']}  |  "
        f"DELETE: {summary['delete']}  |  "
        f"REPLACE: {summary['replace']}"
        + (f"  |  NOOP: {summary['noop']}" if summary['noop'] else "")
        + (f"  |  UNKNOWN: {summary['unknown']}" if summary['unknown'] else "")
    )
    print("-" * 70)

    if not result.resource_changes:
        print("No resource changes detected in plan.")
    else:
        print("Resource Changes:")
        for idx, rc in enumerate(result.resource_changes, 1):
            sku_str = format_sku_transition(rc)
            reg_str = format_region_transition(rc)

            print(f"  {idx}. [{rc.action}] {rc.address}")
            print(f"     Type   : {rc.resource_type}")
            print(f"     SKU    : {sku_str}")
            print(f"     Region : {reg_str}")

            if pricing_map and rc.address in pricing_map:
                cost_item = pricing_map[rc.address]
                if hasattr(cost_item, "new_monthly_cost") and hasattr(cost_item, "pricing_source"):
                    unit_p = cost_item.new_hourly_price or cost_item.old_hourly_price
                    m_cost = cost_item.new_monthly_cost or cost_item.old_monthly_cost
                    print(
                        f"     Price  : ${unit_p:.4f} / 1 Hour "
                        f"(~${m_cost:.2f}/mo) [{cost_item.pricing_source.upper()}]"
                    )
                elif hasattr(cost_item, "price"):
                    print(
                        f"     Price  : ${cost_item.price:.4f} / {cost_item.unit_of_measure} "
                        f"(~${cost_item.monthly_price:.2f}/mo) [{cost_item.source.upper()}]"
                    )

            if verbose:
                if rc.before_state:
                    print(f"     Before : {json.dumps(rc.before_state, indent=8)}")
                if rc.after_state:
                    print(f"     After  : {json.dumps(rc.after_state, indent=8)}")

    print("-" * 70)
    if pricing_stats:
        print(
            f"Pricing Engine: Cache Hits: {pricing_stats['cache_hits']}  |  "
            f"Cache Misses: {pricing_stats['cache_misses']}  |  "
            f"API Calls: {pricing_stats['api_calls']}"
        )
        print("-" * 70)

    warning_count = len(result.warnings)
    if warning_count > 0:
        print(f"Warnings ({warning_count}):")
        for w in result.warnings:
            print(f"  * {w}")
    else:
        print("Warnings: 0 (clean plan parse)")
    print("=" * 70)


def build_parser() -> argparse.ArgumentParser:
    """Builds and returns the argparse.ArgumentParser instance."""
    parser = argparse.ArgumentParser(
        prog="costguard",
        description=(
            "CostGuard receives a Terraform speculative execution plan in JSON "
            "and extracts structured resource-change information for cost analysis."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  costguard --plan sample_plans/create.json\n"
            "  cat sample_plans/create.json | costguard\n"
            "  costguard --plan sample_plans/create.json --max-increase 100\n"
            "  costguard --plan sample_plans/update.json --json\n"
            "  costguard --plan sample_plans/create.json --offline\n"
        ),
    )

    parser.add_argument(
        "-p",
        "--plan",
        type=str,
        default=None,
        help="Path to Terraform plan JSON file (e.g. from 'terraform show -json tfplan').",
    )

    parser.add_argument(
        "--max-increase",
        type=float,
        default=None,
        metavar="AMOUNT",
        help="Maximum allowed monthly cost increase in USD. Fails with exit code 1 if exceeded.",
    )

    parser.add_argument(
        "--json",
        action="store_true",
        help="Output structured JSON representation instead of human-readable text.",
    )

    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Display detailed attributes (before/after states).",
    )

    parser.add_argument(
        "--offline",
        action="store_true",
        help="Operate in offline mode using local SQLite cache without making live API calls.",
    )

    parser.add_argument(
        "--no-pricing",
        action="store_true",
        help="Skip pricing lookups and perform plan change extraction only.",
    )

    parser.add_argument(
        "--web",
        action="store_true",
        help="Launch the local CostGuard web visualization interface.",
    )

    parser.add_argument(
        "--port",
        type=int,
        default=5000,
        help="HTTP port for local web interface (default: 5000).",
    )

    parser.add_argument(
        "--host",
        type=str,
        default="127.0.0.1",
        help="HTTP host to bind local web interface (default: 127.0.0.1).",
    )

    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Do not open browser automatically when launching web interface.",
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
        help="Show CostGuard version and exit.",
    )

    return parser


def run_cli(args: Optional[Sequence[str]] = None) -> int:
    """
    Main CLI logic with return code.
    Exit codes:
      0: Success (and budget check passed if --max-increase specified)
      1: Budget check FAILED (total_delta > max_increase)
      2: Invalid CLI or invalid input (missing file, bad syntax, invalid options)
    """
    parser = build_parser()
    parsed_args = parser.parse_args(args)

    if parsed_args.max_increase is not None and parsed_args.max_increase < 0:
        print("costguard: error: --max-increase must be a non-negative number.", file=sys.stderr)
        return 2

    # Launch local web visualization dashboard if requested
    if getattr(parsed_args, "web", False):
        from costguard.web import start_web_app

        start_web_app(
            host=parsed_args.host,
            port=parsed_args.port,
            plan_path=parsed_args.plan,
            max_increase=parsed_args.max_increase,
            offline=parsed_args.offline,
            open_browser=not getattr(parsed_args, "no_browser", False),
        )
        return 0

    plan_source: Optional[str] = None
    from_file = False

    if parsed_args.plan:
        plan_source = parsed_args.plan
        from_file = True
    elif not sys.stdin.isatty():
        # Input piped via stdin
        try:
            stdin_content = sys.stdin.read()
            plan_source = stdin_content
            from_file = False
        except Exception as exc:
            msg = f"Error reading from stdin: {exc}"
            if parsed_args.json:
                print(json.dumps({"error": msg, "warnings": [msg]}))
            else:
                print(f"costguard: error: {msg}", file=sys.stderr)
            return 2
    else:
        # No input provided
        parser.print_help(sys.stderr)
        print(
            "\ncostguard: error: No input plan provided. "
            "Use '--plan <filepath>' or pipe JSON via stdin (e.g. 'cat plan.json | costguard').",
            file=sys.stderr,
        )
        return 2

    # Perform parsing
    if from_file:
        filepath = Path(plan_source)
        if not filepath.exists():
            msg = f"Plan file not found: {plan_source}"
            if parsed_args.json:
                print(json.dumps({"error": msg, "warnings": [msg]}))
            else:
                print(f"costguard: error: {msg}", file=sys.stderr)
            return 2
        result = parse_plan_file(filepath)
    else:
        result = parse_plan_json(plan_source)

    # Check for fatal parse errors (such as invalid JSON syntax, empty input, or unreadable file)
    has_fatal_error = any(
        w.startswith("Invalid JSON format")
        or w.startswith("Input is empty")
        or w.startswith("Plan file not found")
        for w in result.warnings
    )

    if has_fatal_error and not result.resource_changes:
        if parsed_args.json:
            print(json.dumps(result.to_dict(), indent=2))
        else:
            print("=" * 70, file=sys.stderr)
            print("CostGuard Parse Error", file=sys.stderr)
            print("=" * 70, file=sys.stderr)
            for w in result.warnings:
                print(f"  * {w}", file=sys.stderr)
            print("=" * 70, file=sys.stderr)
        return 2

    # Run Cost Accounting & Budget Engine
    report: Optional[CostAnalysisReport] = None
    cost_map: dict[str, Any] = {}

    if not parsed_args.no_pricing and result.resource_changes:
        pricing_client = AzurePricingClient(offline=parsed_args.offline)
        engine = CostAccountingEngine(pricing_client=pricing_client)
        report = engine.analyze_plan(result, max_increase=parsed_args.max_increase)
        cost_map = {c.address: c for c in report.cost_changes}

    # Format Output
    if parsed_args.json:
        output_dict = result.to_dict()
        if report:
            output_dict["cost_analysis"] = report.to_dict()
            output_dict["pricing_stats"] = report.pricing_stats
        print(json.dumps(output_dict, indent=2))
    else:
        # 1. Print Plan Resource Change Report
        print_human_report(
            result,
            pricing_map=cost_map,
            pricing_stats=report.pricing_stats if report else None,
            verbose=parsed_args.verbose,
        )

        # 2. Print Cost Accounting & Budget Firewall Table
        if report and (report.cost_changes or report.skipped_resources or parsed_args.max_increase is not None):
            print()
            cost_table = format_cost_table(report)
            print(cost_table)

    # Determine Exit Code
    if parsed_args.max_increase is not None and report is not None:
        if report.budget_passed is False:
            return 1
        return 0

    return 0


def main() -> None:
    """Entrypoint for console_scripts."""
    try:
        exit_code = run_cli()
        sys.exit(exit_code)
    except KeyboardInterrupt:
        sys.exit(130)
    except BrokenPipeError:
        sys.exit(0)


if __name__ == "__main__":
    main()
