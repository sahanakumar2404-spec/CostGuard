"""
CostGuard Azure Pricing Engine
Fetches live Azure Retail Prices and manages write-through caching.
"""

from __future__ import annotations

import json
import logging
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Optional, Sequence

from costguard.cache import CachedPrice, SQLitePricingCache

logger = logging.getLogger(__name__)

# Standard hours per month used across cloud providers (730 hours)
HOURS_PER_MONTH = 730


@dataclass
class PriceResult:
    """
    Structured pricing quote for a cloud resource.

    Attributes:
        resource_type: Cloud resource type (e.g. 'azurerm_linux_virtual_machine').
        sku: Resource SKU / VM size.
        region: Cloud region / location.
        price: Unit price in specified currency.
        currency: Currency code (e.g. 'USD').
        unit_of_measure: Unit of billing (e.g. '1 Hour', '1/Month').
        monthly_price: Estimated monthly cost.
        source: Pricing source ('api' or 'cache').
        product_name: Official Azure product name if available.
        meter_name: Official Azure meter name if available.
        metadata: Raw API metadata details.
    """
    resource_type: str
    sku: str
    region: str
    price: float
    currency: str = "USD"
    unit_of_measure: str = "1 Hour"
    monthly_price: float = 0.0
    source: str = "api"
    product_name: str = ""
    meter_name: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.monthly_price == 0.0 and self.price > 0.0:
            unit = self.unit_of_measure.lower()
            if "hour" in unit:
                self.monthly_price = round(self.price * HOURS_PER_MONTH, 4)
            else:
                self.monthly_price = round(self.price, 4)

    def to_dict(self) -> dict[str, Any]:
        return {
            "resource_type": self.resource_type,
            "sku": self.sku,
            "region": self.region,
            "unit_price": self.price,
            "currency": self.currency,
            "unit_of_measure": self.unit_of_measure,
            "monthly_price": self.monthly_price,
            "source": self.source,
            "product_name": self.product_name,
            "meter_name": self.meter_name,
            "metadata": self.metadata,
        }


class AzurePricingClient:
    """
    Client for querying official Azure Retail Prices API with SQLite write-through caching.
    
    Adheres strictly to rules:
      - Normal Consumption pricing only
      - Strict Spot and Low Priority exclusion
      - Never hardcodes prices
      - Safe error handling (timeout, network, offline, unknown SKU)
      - Falls back to valid cache on API failure
    """

    BASE_URL = "https://prices.azure.com/api/retail/prices"

    def __init__(
        self,
        cache: Optional[SQLitePricingCache] = None,
        timeout: float = 10.0,
        offline: bool = False,
        currency_code: str = "USD",
        base_url: Optional[str] = None,
    ) -> None:
        self.cache = cache if cache is not None else SQLitePricingCache()
        self.timeout = timeout
        self.offline = offline
        self.currency_code = currency_code
        self.base_url = base_url or self.BASE_URL
        self.warnings: list[str] = []

    @staticmethod
    def normalize_region(region: str) -> str:
        """
        Normalizes human or Terraform location names to ARM region names.
        e.g. 'West Europe' -> 'westeurope', 'East US' -> 'eastus'.
        """
        if not region:
            return ""
        return region.strip().lower().replace(" ", "").replace("-", "")

    def build_query(
        self,
        resource_type: str,
        sku: str,
        region: str,
        service_info: Optional[dict[str, str]] = None,
    ) -> str:
        """
        Constructs an OData $filter string for the Azure Retail Prices API.
        """
        arm_region = self.normalize_region(region)
        clean_sku = sku.strip()

        clauses: list[str] = []

        if arm_region:
            clauses.append(f"armRegionName eq '{arm_region}'")

        # Always filter for standard Consumption pricing
        clauses.append("priceType eq 'Consumption'")

        # Resource specific and SKU matching
        res_lower = resource_type.lower()
        if "virtual_machine" in res_lower:
            # Query either armSkuName or skuName
            clauses.append(f"(armSkuName eq '{clean_sku}' or skuName eq '{clean_sku}')")
        elif "disk" in res_lower:
            clauses.append(f"(armSkuName eq '{clean_sku}' or skuName eq '{clean_sku}' or contains(skuName, '{clean_sku}'))")
        else:
            clauses.append(f"(armSkuName eq '{clean_sku}' or skuName eq '{clean_sku}' or contains(skuName, '{clean_sku}'))")

        if service_info and "serviceName" in service_info:
            clauses.append(f"serviceName eq '{service_info['serviceName']}'")

        return " and ".join(clauses)

    def _execute_api_request(self, filter_expr: str) -> list[dict[str, Any]]:
        """
        Executes HTTP request to Azure Retail Prices API and parses JSON response.
        """
        params = {"$filter": filter_expr}
        if self.currency_code and self.currency_code != "USD":
            params["currencyCode"] = self.currency_code

        query_string = urllib.parse.urlencode(params)
        full_url = f"{self.base_url}?{query_string}"

        req = urllib.request.Request(
            full_url,
            headers={
                "User-Agent": "CostGuard/0.1.0 (Terraform Cost Governance)",
                "Accept": "application/json",
            },
        )

        with urllib.request.urlopen(req, timeout=self.timeout) as response:
            content = response.read().decode("utf-8")
            data = json.loads(content)
            items = data.get("Items", [])
            if not isinstance(items, list):
                raise ValueError("Malformed API response: 'Items' is not a list")
            return items

    def filter_and_select_price(
        self,
        items: Sequence[dict[str, Any]],
        resource_type: str,
        sku: str,
    ) -> Optional[dict[str, Any]]:
        """
        Filters raw Azure Retail Prices API items to find the single applicable standard price:
          - Enforces Consumption priceType
          - Strictly excludes Spot items
          - Strictly excludes Low Priority items
          - Selects correct OS (Linux vs Windows)
          - Picks primary compute/service meter
        """
        candidates: list[dict[str, Any]] = []
        is_windows_target = "windows" in resource_type.lower()
        clean_sku = sku.strip().lower()

        for item in items:
            # 1. Enforce priceType == 'Consumption'
            p_type = str(item.get("type", "")).strip().lower()
            if p_type != "consumption":
                continue

            retail_price = item.get("retailPrice")
            if retail_price is None or not isinstance(retail_price, (int, float)):
                continue

            sku_name = str(item.get("skuName", "")).lower()
            meter_name = str(item.get("meterName", "")).lower()
            product_name = str(item.get("productName", "")).lower()
            arm_sku = str(item.get("armSkuName", "")).lower()

            # 2. Exclude Spot instances
            if "spot" in sku_name or "spot" in meter_name or "spot" in product_name:
                continue

            # 3. Exclude Low Priority instances
            if (
                "low priority" in sku_name
                or "low priority" in meter_name
                or "low priority" in product_name
                or "lowpriority" in sku_name
            ):
                continue

            # 4. OS selection for Virtual Machines
            if "virtual_machine" in resource_type.lower():
                is_windows_item = "windows" in product_name or "windows" in meter_name
                if is_windows_target and not is_windows_item:
                    continue
                if not is_windows_target and is_windows_item:
                    continue

            # 5. SKU matching check
            # Verify that either armSkuName or skuName reflects the requested SKU
            if clean_sku not in arm_sku and clean_sku not in sku_name and clean_sku not in meter_name:
                continue

            candidates.append(item)

        if not candidates:
            return None

        # Prefer standard primary compute/service meters (e.g. '1 Hour')
        def score_candidate(item: dict[str, Any]) -> int:
            score = 0
            unit = str(item.get("unitOfMeasure", "")).lower()
            if "hour" in unit:
                score += 10
            meter = str(item.get("meterName", "")).lower()
            # De-prioritize secondary add-ons (mount, temp, operations)
            if "mount" in meter or "operations" in meter:
                score -= 5
            return score

        candidates.sort(key=score_candidate, reverse=True)
        return candidates[0]

    def get_price(
        self,
        resource_type: str,
        sku: str,
        region: str,
        service_info: Optional[dict[str, str]] = None,
        force_refresh: bool = False,
    ) -> Optional[PriceResult]:
        """
        Retrieves pricing for a resource following the write-through cache flow:
          CACHE CHECK
          ↓
          cache hit → return cached price
          ↓
          cache miss → query Azure API
          ↓
          filter & select normal Consumption price (exclude Spot & Low Priority)
          ↓
          save to SQLite cache
          ↓
          return price

        Safe error handling:
          - If API fails and valid cached pricing exists, return cached pricing.
          - If neither cache nor API can provide price, return None with warning.
          - Never crashes; never invents a price.
        """
        if not resource_type or not sku or not region:
            warn = f"Cannot fetch pricing: missing required parameter (type={resource_type}, sku={sku}, region={region})"
            self.warnings.append(warn)
            return None

        # Step 1: CACHE CHECK (unless force_refresh is requested)
        if not force_refresh:
            cached = self.cache.get(resource_type, sku, region)
            if cached is not None:
                return PriceResult(
                    resource_type=cached.resource_type,
                    sku=cached.sku,
                    region=cached.region,
                    price=cached.price,
                    currency=cached.currency,
                    unit_of_measure=cached.unit_of_measure,
                    monthly_price=cached.monthly_price,
                    source="cache",
                    product_name=cached.metadata.get("product_name", ""),
                    meter_name=cached.metadata.get("meter_name", ""),
                    metadata=cached.metadata,
                )

        # Step 2: Handle offline mode
        if self.offline:
            # If force_refresh was true or item was missing in cache
            cached_fallback = self.cache.get(resource_type, sku, region)
            if cached_fallback:
                return PriceResult(
                    resource_type=cached_fallback.resource_type,
                    sku=cached_fallback.sku,
                    region=cached_fallback.region,
                    price=cached_fallback.price,
                    currency=cached_fallback.currency,
                    unit_of_measure=cached_fallback.unit_of_measure,
                    monthly_price=cached_fallback.monthly_price,
                    source="cache",
                    metadata=cached_fallback.metadata,
                )
            warn = f"Offline mode: cannot fetch pricing for {resource_type} (SKU: {sku}, Region: {region})"
            self.warnings.append(warn)
            return None

        # Step 3: Query Azure Retail Prices API
        self.cache.api_calls += 1
        query_filter = self.build_query(resource_type, sku, region, service_info)

        try:
            items = self._execute_api_request(query_filter)
        except urllib.error.HTTPError as exc:
            # Check for fallback cache
            cached_fallback = self.cache.get(resource_type, sku, region)
            if cached_fallback:
                return PriceResult(
                    resource_type=cached_fallback.resource_type,
                    sku=cached_fallback.sku,
                    region=cached_fallback.region,
                    price=cached_fallback.price,
                    currency=cached_fallback.currency,
                    unit_of_measure=cached_fallback.unit_of_measure,
                    monthly_price=cached_fallback.monthly_price,
                    source="cache",
                    metadata=cached_fallback.metadata,
                )
            warn = f"Azure Retail Prices API HTTP {exc.code} for {sku} in {region}: {exc.reason}"
            self.warnings.append(warn)
            return None
        except (urllib.error.URLError, TimeoutError) as exc:
            # Check for fallback cache
            cached_fallback = self.cache.get(resource_type, sku, region)
            if cached_fallback:
                return PriceResult(
                    resource_type=cached_fallback.resource_type,
                    sku=cached_fallback.sku,
                    region=cached_fallback.region,
                    price=cached_fallback.price,
                    currency=cached_fallback.currency,
                    unit_of_measure=cached_fallback.unit_of_measure,
                    monthly_price=cached_fallback.monthly_price,
                    source="cache",
                    metadata=cached_fallback.metadata,
                )
            warn = f"Azure Retail Prices API connection/timeout error for {sku} in {region}: {str(exc)}"
            self.warnings.append(warn)
            return None
        except Exception as exc:
            cached_fallback = self.cache.get(resource_type, sku, region)
            if cached_fallback:
                return PriceResult(
                    resource_type=cached_fallback.resource_type,
                    sku=cached_fallback.sku,
                    region=cached_fallback.region,
                    price=cached_fallback.price,
                    currency=cached_fallback.currency,
                    unit_of_measure=cached_fallback.unit_of_measure,
                    monthly_price=cached_fallback.monthly_price,
                    source="cache",
                    metadata=cached_fallback.metadata,
                )
            warn = f"Failed to retrieve Azure price for {sku} in {region}: {str(exc)}"
            self.warnings.append(warn)
            return None

        # Step 4: Filter results and select applicable price
        selected = self.filter_and_select_price(items, resource_type, sku)
        if not selected:
            warn = (
                f"No standard Azure Consumption pricing found for {resource_type} "
                f"(SKU: '{sku}', Region: '{region}'). Spot/Low Priority were excluded."
            )
            self.warnings.append(warn)
            return None

        unit_price = float(selected.get("retailPrice", 0.0))
        unit_of_measure = str(selected.get("unitOfMeasure", "1 Hour"))
        product_name = str(selected.get("productName", ""))
        meter_name = str(selected.get("meterName", ""))
        currency = str(selected.get("currencyCode", self.currency_code))

        metadata = {
            "product_name": product_name,
            "meter_name": meter_name,
            "service_name": selected.get("serviceName", ""),
            "unit_of_measure": unit_of_measure,
            "meter_id": selected.get("meterId", ""),
            "arm_sku_name": selected.get("armSkuName", ""),
        }

        # Step 5: Save to SQLite cache (write-through)
        self.cache.set(
            resource_type=resource_type,
            sku=sku,
            region=region,
            price=unit_price,
            currency=currency,
            metadata=metadata,
        )

        # Step 6: Return price result
        return PriceResult(
            resource_type=resource_type,
            sku=sku,
            region=region,
            price=unit_price,
            currency=currency,
            unit_of_measure=unit_of_measure,
            source="api",
            product_name=product_name,
            meter_name=meter_name,
            metadata=metadata,
        )

    def stats(self) -> dict[str, int]:
        """Returns cache and API performance metrics."""
        return self.cache.stats()
