"""
CostGuard module execution entry point.
Enables running via: python -m costguard
"""

from costguard.cli import main

if __name__ == "__main__":
    main()
