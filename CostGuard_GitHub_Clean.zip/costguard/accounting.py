"""
CostGuard Cost Accounting & Budget Engine
Calculates monthly resource costs, delta projections, and enforces budget circuit breakers.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional, Sequence

from costguard.models import ActionType, PlanParseResult, ResourceChange
from costguard.pricing import AzurePricingClient, PriceResult

# Challenge specification: monthly_cost = hourly_price * 730
HOURS_PER_MONTH = 730

# Known non-billable resource prefixes and types
NON_BILLABLE_TYPES = (
    "random_",
    "null_",
    "local_",
    "tls_",
    "time_",
    "terraform_data",
    "azurerm_resource_group",
    "azurerm_virtual_network",
    "azurerm_subnet",
    "azurerm_network_security_group",
    "azurerm_network_security_rule",
    "azurerm_route_table",
    "azurerm_route",
    "azuread_",
)


def format_currency(amount: float, show_sign: bool = False) -> str:
    """
    Formats a numeric currency amount into standard representation ($XX.XX).
    Only formats at the display boundary; intermediate math remains full float precision.
    """
    if show_sign:
        if amount > 0:
            return f"+${amount:,.2f}"
        elif amount < 0:
            return f"-${abs(amount):,.2f}"
        return f"${amount:,.2f}"
    return f"${amount:,.2f}"


@dataclass
class ResourceCostChange:
    """
    Cost change details for an individual billable resource.

    Attributes:
        address: Terraform resource address.
        resource_type: Resource type name.
        action: Normalized action (CREATE, DELETE, UPDATE, REPLACE).
        old_sku: SKU prior to change.
        new_sku: SKU after change.
        old_region: Region prior to change.
        new_region: Region after change.
        old_hourly_price: Hourly unit price prior to change.
        new_hourly_price: Hourly unit price after change.
        old_monthly_cost: Calculated old monthly cost (old_hourly_price * 730).
        new_monthly_cost: Calculated new monthly cost (new_hourly_price * 730).
        monthly_delta: Monthly cost delta (new_monthly_cost - old_monthly_cost).
        currency: Currency code.
        pricing_source: Source of pricing ('api' or 'cache').
        percentage_change: Percentage cost change if old_monthly_cost > 0.
        reason: Plain-English explanation for why cost changed.
        explanation: Summary explanation string.
    """
    address: str
    resource_type: str
    action: str
    old_sku: Optional[str] = None
    new_sku: Optional[str] = None
    old_region: Optional[str] = None
    new_region: Optional[str] = None
    old_hourly_price: float = 0.0
    new_hourly_price: float = 0.0
    old_monthly_cost: float = 0.0
    new_monthly_cost: float = 0.0
    monthly_delta: float = 0.0
    currency: str = "USD"
    pricing_source: str = "api"
    percentage_change: Optional[float] = None
    reason: str = ""
    explanation: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "address": self.address,
            "resource_type": self.resource_type,
            "action": self.action,
            "old_sku": self.old_sku,
            "new_sku": self.new_sku,
            "old_region": self.old_region,
            "new_region": self.new_region,
            "old_hourly_price": self.old_hourly_price,
            "new_hourly_price": self.new_hourly_price,
            "old_monthly_cost": round(self.old_monthly_cost, 2),
            "new_monthly_cost": round(self.new_monthly_cost, 2),
            "monthly_delta": round(self.monthly_delta, 2),
            "currency": self.currency,
            "pricing_source": self.pricing_source,
            "percentage_change": round(self.percentage_change, 1) if self.percentage_change is not None else None,
            "reason": self.reason,
            "explanation": self.explanation,
        }


@dataclass
class SkippedResource:
    """
    Represents a resource that was not priced or is non-billable.
    """
    address: str
    resource_type: str
    action: str
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "address": self.address,
            "resource_type": self.resource_type,
            "action": self.action,
            "reason": self.reason,
        }


@dataclass
class OptimizationSuggestion:
    """
    Advisory optimization suggestion for infrastructure cost efficiency.
    """
    resource_address: str
    category: str
    title: str
    description: str
    advisory_notice: str = "Advisory recommendation only. Requires engineer validation before applying changes."

    def to_dict(self) -> dict[str, Any]:
        return {
            "resource_address": self.resource_address,
            "category": self.category,
            "title": self.title,
            "description": self.description,
            "advisory_notice": self.advisory_notice,
        }


@dataclass
class CostAnalysisReport:
    """
    Complete cost accounting and budget assessment report.
    """
    cost_changes: list[ResourceCostChange] = field(default_factory=list)
    skipped_resources: list[SkippedResource] = field(default_factory=list)
    total_old_cost: float = 0.0
    total_new_cost: float = 0.0
    total_delta: float = 0.0
    currency: str = "USD"
    max_increase: Optional[float] = None
    budget_passed: Optional[bool] = None
    warnings: list[str] = field(default_factory=list)
    pricing_stats: dict[str, int] = field(default_factory=dict)
    plan_summary: dict[str, int] = field(default_factory=dict)
    top_contributors: list[ResourceCostChange] = field(default_factory=list)
    optimization_suggestions: list[OptimizationSuggestion] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "summary": {
                "total_old_cost": round(self.total_old_cost, 2),
                "total_new_cost": round(self.total_new_cost, 2),
                "total_delta": round(self.total_delta, 2),
                "currency": self.currency,
                "billable_resources_count": len(self.cost_changes),
                "skipped_resources_count": len(self.skipped_resources),
            },
            "cost_changes": [c.to_dict() for c in self.cost_changes],
            "skipped_resources": [s.to_dict() for s in self.skipped_resources],
            "top_contributors": [c.to_dict() for c in self.top_contributors],
            "optimization_suggestions": [s.to_dict() for s in self.optimization_suggestions],
            "warnings": self.warnings,
            "pricing_stats": self.pricing_stats,
        }
        if self.max_increase is not None:
            data["budget"] = {
                "max_increase": round(self.max_increase, 2),
                "total_delta": round(self.total_delta, 2),
                "passed": self.budget_passed,
                "status": "PASS" if self.budget_passed else "FAIL",
            }
        return data


class CostAccountingEngine:
    """
    Core cost calculation and budget enforcement engine.
    """

    def __init__(self, pricing_client: Optional[AzurePricingClient] = None) -> None:
        self.pricing_client = pricing_client or AzurePricingClient()

    def is_non_billable(self, resource_type: str) -> bool:
        """Determines if a resource type is fundamentally non-billable."""
        r_type = resource_type.lower()
        return any(r_type.startswith(prefix) or r_type == prefix for prefix in NON_BILLABLE_TYPES)

    def calculate_resource_cost(self, rc: ResourceChange) -> ResourceCostChange | SkippedResource:
        """
        Calculates the old cost, new cost, and monthly delta for an individual resource.
        Adheres to challenge rules:
          CREATE:  old = 0, new = price
          DELETE:  old = price, new = 0
          UPDATE:  old = old price, new = new price
          REPLACE: old = old resource price, new = new resource price
        """
        # 1. Non-billable component check
        if self.is_non_billable(rc.resource_type):
            return SkippedResource(
                address=rc.address,
                resource_type=rc.resource_type,
                action=str(rc.action),
                reason="Non-billable infrastructure component",
            )

        # 2. Check for Azure support
        is_azure = "azure" in rc.resource_type.lower() or rc.resource_type.startswith("azurerm_")
        if not is_azure:
            return SkippedResource(
                address=rc.address,
                resource_type=rc.resource_type,
                action=str(rc.action),
                reason="Pricing provider for this cloud is not configured in this engine",
            )

        action = str(rc.action).upper()

        # CREATE
        if action == ActionType.CREATE.value:
            if not rc.new_sku or not rc.new_region:
                return SkippedResource(
                    address=rc.address,
                    resource_type=rc.resource_type,
                    action=action,
                    reason="Missing SKU or region for create",
                )
            p_res = self.pricing_client.get_price(rc.resource_type, rc.new_sku, rc.new_region)
            if not p_res:
                return SkippedResource(
                    address=rc.address,
                    resource_type=rc.resource_type,
                    action=action,
                    reason=f"Pricing unavailable for SKU '{rc.new_sku}' in region '{rc.new_region}'",
                )
            old_cost = 0.0
            new_cost = p_res.price * HOURS_PER_MONTH
            delta = new_cost - old_cost
            reason = f"Newly provisioned {rc.resource_type} ('{rc.new_sku}' in {rc.new_region}) adding {format_currency(new_cost)}/month."
            explanation = f"CREATE {rc.new_sku}: {format_currency(old_cost)} -> {format_currency(new_cost)} ({format_currency(delta, show_sign=True)}/mo). Reason: Newly provisioned infrastructure."

            return ResourceCostChange(
                address=rc.address,
                resource_type=rc.resource_type,
                action=action,
                old_sku=None,
                new_sku=rc.new_sku,
                old_region=None,
                new_region=rc.new_region,
                old_hourly_price=0.0,
                new_hourly_price=p_res.price,
                old_monthly_cost=old_cost,
                new_monthly_cost=new_cost,
                monthly_delta=delta,
                currency=p_res.currency,
                pricing_source=p_res.source,
                percentage_change=None,
                reason=reason,
                explanation=explanation,
            )

        # DELETE
        elif action == ActionType.DELETE.value:
            if not rc.old_sku or not rc.old_region:
                return SkippedResource(
                    address=rc.address,
                    resource_type=rc.resource_type,
                    action=action,
                    reason="Missing SKU or region for delete",
                )
            p_res = self.pricing_client.get_price(rc.resource_type, rc.old_sku, rc.old_region)
            if not p_res:
                return SkippedResource(
                    address=rc.address,
                    resource_type=rc.resource_type,
                    action=action,
                    reason=f"Pricing unavailable for SKU '{rc.old_sku}' in region '{rc.old_region}'",
                )
            old_cost = p_res.price * HOURS_PER_MONTH
            new_cost = 0.0
            delta = new_cost - old_cost  # Negative delta
            reason = f"Decommissioned {rc.resource_type} ('{rc.old_sku}' in {rc.old_region}) eliminating {format_currency(old_cost)}/month."
            explanation = f"DELETE {rc.old_sku}: {format_currency(old_cost)} -> {format_currency(new_cost)} ({format_currency(delta, show_sign=True)}/mo, -100.0%). Reason: Resource decommissioned."

            return ResourceCostChange(
                address=rc.address,
                resource_type=rc.resource_type,
                action=action,
                old_sku=rc.old_sku,
                new_sku=None,
                old_region=rc.old_region,
                new_region=None,
                old_hourly_price=p_res.price,
                new_hourly_price=0.0,
                old_monthly_cost=old_cost,
                new_monthly_cost=new_cost,
                monthly_delta=delta,
                currency=p_res.currency,
                pricing_source=p_res.source,
                percentage_change=-100.0,
                reason=reason,
                explanation=explanation,
            )

        # UPDATE or REPLACE
        elif action in (ActionType.UPDATE.value, ActionType.REPLACE.value):
            old_sku = rc.old_sku or rc.new_sku
            new_sku = rc.new_sku or rc.old_sku
            old_reg = rc.old_region or rc.new_region
            new_reg = rc.new_region or rc.old_region

            if not old_sku or not old_reg or not new_sku or not new_reg:
                return SkippedResource(
                    address=rc.address,
                    resource_type=rc.resource_type,
                    action=action,
                    reason="Missing SKU or region for update/replace comparison",
                )

            p_old = self.pricing_client.get_price(rc.resource_type, old_sku, old_reg)
            if not p_old:
                return SkippedResource(
                    address=rc.address,
                    resource_type=rc.resource_type,
                    action=action,
                    reason=f"Pricing unavailable for prior SKU '{old_sku}' in region '{old_reg}'",
                )

            p_new = self.pricing_client.get_price(rc.resource_type, new_sku, new_reg)
            if not p_new:
                return SkippedResource(
                    address=rc.address,
                    resource_type=rc.resource_type,
                    action=action,
                    reason=f"Pricing unavailable for new SKU '{new_sku}' in region '{new_reg}'",
                )

            old_cost = p_old.price * HOURS_PER_MONTH
            new_cost = p_new.price * HOURS_PER_MONTH
            delta = new_cost - old_cost
            pct = ((new_cost - old_cost) / old_cost * 100.0) if old_cost > 0 else None

            if delta > 0:
                pct_str = f"+{pct:.1f}%" if pct is not None else "N/A"
                reason = f"Upgraded SKU from '{old_sku}' to '{new_sku}' in {new_reg} (+{format_currency(delta)}/mo, {pct_str})."
                explanation = f"{action} {old_sku} -> {new_sku}: {format_currency(old_cost)} -> {format_currency(new_cost)} (+{format_currency(delta)}/mo, {pct_str}). Reason: Instance capacity upgraded."
            elif delta < 0:
                pct_str = f"{pct:.1f}%" if pct is not None else "N/A"
                reason = f"Downgraded SKU from '{old_sku}' to '{new_sku}' in {new_reg} ({format_currency(delta, show_sign=True)}/mo, {pct_str})."
                explanation = f"{action} {old_sku} -> {new_sku}: {format_currency(old_cost)} -> {format_currency(new_cost)} ({format_currency(delta, show_sign=True)}/mo, {pct_str}). Reason: Instance capacity downscaled."
            else:
                reason = f"Updated configuration with same pricing tier ('{new_sku}' in {new_reg}); monthly cost unchanged."
                explanation = f"{action} {new_sku}: {format_currency(old_cost)} -> {format_currency(new_cost)} ($0.00/mo). Reason: In-place update without pricing rate modification."

            return ResourceCostChange(
                address=rc.address,
                resource_type=rc.resource_type,
                action=action,
                old_sku=old_sku,
                new_sku=new_sku,
                old_region=old_reg,
                new_region=new_reg,
                old_hourly_price=p_old.price,
                new_hourly_price=p_new.price,
                old_monthly_cost=old_cost,
                new_monthly_cost=new_cost,
                monthly_delta=delta,
                currency=p_new.currency,
                pricing_source="api" if (p_old.source == "api" or p_new.source == "api") else "cache",
                percentage_change=pct,
                reason=reason,
                explanation=explanation,
            )

        # Unknown / NOOP
        return SkippedResource(
            address=rc.address,
            resource_type=rc.resource_type,
            action=action,
            reason=f"Action '{action}' does not impact cloud bill",
        )

    def analyze_plan(
        self,
        plan_result: PlanParseResult,
        max_increase: Optional[float] = None,
    ) -> CostAnalysisReport:
        """
        Runs cost accounting across all resource changes in a Terraform plan.
        Sums totals with full intermediate precision.
        Evaluates budget threshold if max_increase is specified.
        Identifies top cost contributors and generates conservative advisory suggestions.
        """
        cost_changes: list[ResourceCostChange] = []
        skipped_resources: list[SkippedResource] = []

        for rc in plan_result.resource_changes:
            try:
                item = self.calculate_resource_cost(rc)
                if isinstance(item, ResourceCostChange):
                    cost_changes.append(item)
                else:
                    skipped_resources.append(item)
            except Exception as exc:
                skipped_resources.append(
                    SkippedResource(
                        address=rc.address,
                        resource_type=rc.resource_type,
                        action=str(rc.action),
                        reason=f"Unexpected error calculating cost: {exc}",
                    )
                )

        # Totals with full unrounded precision
        total_old = sum(c.old_monthly_cost for c in cost_changes)
        total_new = sum(c.new_monthly_cost for c in cost_changes)
        total_delta = total_new - total_old

        # Budget check
        budget_passed: Optional[bool] = None
        if max_increase is not None:
            budget_passed = total_delta <= max_increase

        # Top cost contributors (positive delta, descending order)
        top_contributors = sorted(
            [c for c in cost_changes if c.monthly_delta > 0],
            key=lambda c: c.monthly_delta,
            reverse=True,
        )

        # Conservative, explainable optimization suggestions
        suggestions: list[OptimizationSuggestion] = []
        non_prod_keywords = (
            "dev", "development", "test", "testing", "qa",
            "stage", "staging", "sandbox", "poc", "nonprod", "non-prod"
        )

        for c in cost_changes:
            matching_rc = next((r for r in plan_result.resource_changes if r.address == c.address), None)

            # Heuristic 1: Non-production workload running 24/7 at significant projected cost
            is_non_prod = False
            detected_tag_or_name = ""
            addr_lower = c.address.lower()
            for kw in non_prod_keywords:
                parts = addr_lower.replace("-", "_").replace(".", "_").split("_")
                if kw in parts:
                    is_non_prod = True
                    detected_tag_or_name = kw
                    break

            if not is_non_prod and matching_rc:
                tags = {}
                if matching_rc.after_state and isinstance(matching_rc.after_state, dict):
                    tags = matching_rc.after_state.get("tags") or {}
                elif matching_rc.before_state and isinstance(matching_rc.before_state, dict):
                    tags = matching_rc.before_state.get("tags") or {}
                if isinstance(tags, dict):
                    for k, v in tags.items():
                        v_str = str(v).lower()
                        for kw in non_prod_keywords:
                            if kw in v_str:
                                is_non_prod = True
                                detected_tag_or_name = f"tag '{k}={v}'"
                                break
                        if is_non_prod:
                            break

            if is_non_prod and c.new_monthly_cost >= 50.0:
                suggestions.append(
                    OptimizationSuggestion(
                        resource_address=c.address,
                        category="Non-Production Sizing",
                        title=f"Non-production resource sized at {format_currency(c.new_monthly_cost)}/mo",
                        description=(
                            f"Resource '{c.address}' appears to target a non-production environment ({detected_tag_or_name}) "
                            f"with continuous 24/7 monthly runtime ({format_currency(c.new_monthly_cost)}/mo based on 730 hours). "
                            f"Recommendation: Verify if 24/7 execution is required or if automated off-hours shutdown schedules "
                            f"(e.g. ~250 hours/mo) or burstable B-series SKUs can be utilized."
                        ),
                    )
                )

            # Heuristic 2: Unusually large VM SKU increase
            if c.action in (ActionType.UPDATE.value, ActionType.REPLACE.value) and c.monthly_delta >= 70.0:
                pct_text = f" (+{c.percentage_change:.1f}%)" if c.percentage_change else ""
                suggestions.append(
                    OptimizationSuggestion(
                        resource_address=c.address,
                        category="Significant SKU Upgrade",
                        title=f"Significant instance upgrade for '{c.address}' ({format_currency(c.monthly_delta, show_sign=True)}/mo)",
                        description=(
                            f"Resource SKU upgraded from '{c.old_sku}' to '{c.new_sku}' in {c.new_region}, "
                            f"increasing projected cost by {format_currency(c.monthly_delta, show_sign=True)}/mo{pct_text}. "
                            f"Recommendation: Confirm CPU/memory utilization benchmarks require this capacity jump before deployment."
                        ),
                    )
                )
            elif c.action == ActionType.CREATE.value and c.new_monthly_cost >= 180.0:
                suggestions.append(
                    OptimizationSuggestion(
                        resource_address=c.address,
                        category="High-Capacity Provisioning",
                        title=f"High-capacity resource provisioned at {format_currency(c.new_monthly_cost)}/mo",
                        description=(
                            f"Newly provisioned {c.resource_type} ({c.new_sku}) adds {format_currency(c.new_monthly_cost)}/mo. "
                            f"Recommendation: If workload will run continuously, evaluate Azure 1-Year or 3-Year Reservations "
                            f"or Savings Plans for potential rate reductions."
                        ),
                    )
                )

        warnings = list(plan_result.warnings)
        if self.pricing_client.warnings:
            warnings.extend(self.pricing_client.warnings)

        return CostAnalysisReport(
            cost_changes=cost_changes,
            skipped_resources=skipped_resources,
            total_old_cost=total_old,
            total_new_cost=total_new,
            total_delta=total_delta,
            currency="USD",
            max_increase=max_increase,
            budget_passed=budget_passed,
            warnings=warnings,
            pricing_stats=self.pricing_client.stats(),
            plan_summary=plan_result.summary,
            top_contributors=top_contributors,
            optimization_suggestions=suggestions,
        )


def format_cost_table(report: CostAnalysisReport) -> str:
    """
    Renders professional terminal output matching the challenge specifications:
      COSTGUARD
      Terraform Cost Firewall

      Resource                         Action     Old      New      Delta
      --------------------------------------------------------------------
      ...
      --------------------------------------------------------------------
      TOTAL                                      $XX.XX   $XX.XX   +$XX.XX

      Budget Limit: $XX.XX
      Projected Increase: $XX.XX

      ✓ BUDGET CHECK: PASS / ✗ BUDGET CHECK: FAILED
    """
    lines: list[str] = []
    lines.append("COSTGUARD (Phase 1, 2 & 3)")
    lines.append("Terraform Cost Firewall")
    lines.append("=" * 72)
    if report.plan_summary:
        s = report.plan_summary
        lines.append(
            f"Plan Changes: Total: {s.get('total', 0)} | "
            f"CREATE: {s.get('create', 0)} | "
            f"UPDATE: {s.get('update', 0)} | "
            f"DELETE: {s.get('delete', 0)} | "
            f"REPLACE: {s.get('replace', 0)}"
        )
        lines.append("-" * 72)
    lines.append(f"{'Resource':<32} {'Action':<9} {'Old':>9} {'New':>9} {'Delta':>10}")
    lines.append("-" * 72)

    if not report.cost_changes:
        lines.append("No billable resource cost changes detected.")
    else:
        for c in report.cost_changes:
            # Abbreviate address if too long
            addr = c.address
            if len(addr) > 31:
                addr = addr[:28] + "..."
            old_str = format_currency(c.old_monthly_cost)
            new_str = format_currency(c.new_monthly_cost)
            delta_str = format_currency(c.monthly_delta, show_sign=True)
            lines.append(f"{addr:<32} {c.action:<9} {old_str:>9} {new_str:>9} {delta_str:>10}")

    lines.append("-" * 72)
    tot_old = format_currency(report.total_old_cost)
    tot_new = format_currency(report.total_new_cost)
    tot_delta = format_currency(report.total_delta, show_sign=True)
    lines.append(f"{'TOTAL':<42} {tot_old:>9} {tot_new:>9} {tot_delta:>10}")
    lines.append("=" * 72)

    # Top Cost Contributors section
    if report.top_contributors:
        lines.append(f"\nTop Cost Contributors ({len(report.top_contributors)}):")
        for idx, tc in enumerate(report.top_contributors[:5], 1):
            pct_str = f" ({tc.percentage_change:+.1f}%)" if tc.percentage_change is not None else ""
            sku_disp = tc.new_sku or tc.old_sku or "-"
            lines.append(
                f"  {idx}. {tc.address} [{tc.action} {sku_disp}]: "
                f"{format_currency(tc.monthly_delta, show_sign=True)}/mo{pct_str}"
            )
            if tc.reason:
                lines.append(f"     Reason: {tc.reason}")
        lines.append("-" * 72)

    # Optimization Recommendations (Advisory)
    if report.optimization_suggestions:
        lines.append(f"\nOptimization Recommendations (Advisory - {len(report.optimization_suggestions)}):")
        for idx, sug in enumerate(report.optimization_suggestions, 1):
            lines.append(f"  {idx}. [{sug.category.upper()}] {sug.title}")
            lines.append(f"     {sug.description}")
            lines.append(f"     * Note: {sug.advisory_notice}")
        lines.append("-" * 72)

    # Skipped resources display
    if report.skipped_resources:
        lines.append(f"\nSkipped Resources ({len(report.skipped_resources)}):")
        for s in report.skipped_resources:
            lines.append(f"  * {s.address} ({s.action}): {s.reason}")
        lines.append("-" * 72)

    # Budget Check Section
    if report.max_increase is not None:
        lines.append("")
        lines.append(f"Budget Limit: {format_currency(report.max_increase)}")
        lines.append(f"Projected Increase: {format_currency(report.total_delta, show_sign=True)}")
        lines.append("")
        if report.budget_passed:
            lines.append("✓ BUDGET CHECK: PASS")
        else:
            lines.append("✗ BUDGET CHECK: FAILED")
            lines.append("Deployment BLOCKED")
            lines.append("Exit Code: 1")
        lines.append("=" * 72)

    return "\n".join(lines)
