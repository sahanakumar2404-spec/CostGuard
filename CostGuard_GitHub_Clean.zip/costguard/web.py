"""
CostGuard Web Application Server
Serves the local visualization dashboard and provides real cost-analysis JSON endpoints.
"""

from __future__ import annotations

import argparse
import http.server
import json
import logging
import sys
import threading
import urllib.parse
from pathlib import Path
from typing import Any, Optional

from costguard.accounting import CostAccountingEngine, CostAnalysisReport, format_currency
from costguard.cache import SQLitePricingCache
from costguard.models import PlanParseResult
from costguard.parser import parse_plan_file, parse_plan_json
from costguard.pricing import AzurePricingClient

logger = logging.getLogger(__name__)

WEB_DIR = Path(__file__).parent.parent / "web"
SAMPLE_PLANS_DIR = Path(__file__).parent.parent / "sample_plans"


def generate_analysis_payload(
    plan_source: str,
    max_increase: Optional[float] = None,
    offline: bool = False,
    pricing_client: Optional[AzurePricingClient] = None,
    action: Optional[str] = None,
) -> dict[str, Any]:
    """
    Executes the real CostGuard engine on a plan file or JSON string
    and returns a structured serialization payload for web consumers.

    Supports optional action filtering (ALL, CREATE, UPDATE, DELETE, REPLACE).
    The Python accounting engine is the single source of truth for all calculations.
    """
    plan_path = Path(plan_source)
    if plan_path.exists() and plan_path.is_file():
        plan_result = parse_plan_file(plan_path)
        plan_name = plan_path.name
    else:
        plan_result = parse_plan_json(plan_source)
        plan_name = "custom_plan.json"

    client = pricing_client or AzurePricingClient(offline=offline)
    engine = CostAccountingEngine(pricing_client=client)
    report = engine.analyze_plan(plan_result, max_increase=max_increase)

    # Compute action counts across all parsed resources in the Terraform plan
    action_counts = {
        "ALL": len(plan_result.resource_changes),
        "CREATE": sum(1 for rc in plan_result.resource_changes if rc.action == "CREATE"),
        "UPDATE": sum(1 for rc in plan_result.resource_changes if rc.action == "UPDATE"),
        "DELETE": sum(1 for rc in plan_result.resource_changes if rc.action == "DELETE"),
        "REPLACE": sum(1 for rc in plan_result.resource_changes if rc.action == "REPLACE"),
    }

    # Normalize action parameter
    norm_action = (action or "ALL").strip().upper()
    if norm_action not in {"ALL", "CREATE", "UPDATE", "DELETE", "REPLACE"}:
        norm_action = "ALL"

    # Filter cost changes and skipped resources based on action
    if norm_action == "ALL":
        filtered_changes = report.cost_changes
        filtered_skipped = report.skipped_resources
        filtered_total_old = report.total_old_cost
        filtered_total_new = report.total_new_cost
        filtered_total_delta = report.total_delta
        filtered_suggestions = report.optimization_suggestions
        filtered_top_contributors = report.top_contributors
        filtered_total_changes = len(plan_result.resource_changes)
    else:
        filtered_changes = [c for c in report.cost_changes if c.action == norm_action]
        filtered_skipped = [s for s in report.skipped_resources if (s.action or "").upper() == norm_action]
        filtered_total_old = sum(c.old_monthly_cost for c in filtered_changes)
        filtered_total_new = sum(c.new_monthly_cost for c in filtered_changes)
        filtered_total_delta = filtered_total_new - filtered_total_old
        filtered_total_changes = action_counts.get(norm_action, len(filtered_changes) + len(filtered_skipped))

        # Top contributors strictly from filtered changes
        filtered_top_contributors = sorted(
            filtered_changes, key=lambda c: abs(c.monthly_delta), reverse=True
        )[:5]

        # Optimization suggestions strictly for filtered resources
        filtered_addrs = {c.address for c in filtered_changes} | {s.address for s in filtered_skipped}
        filtered_suggestions = [
            s for s in report.optimization_suggestions if s.resource_address in filtered_addrs
        ]

    # Generate explainable "Why did cost change?" insights strictly from actual data
    increases = [c for c in filtered_changes if c.monthly_delta > 0]
    decreases = [c for c in filtered_changes if c.monthly_delta < 0]
    unchanged = [c for c in filtered_changes if c.monthly_delta == 0]

    largest_inc = max(increases, key=lambda c: c.monthly_delta, default=None)
    largest_dec = min(decreases, key=lambda c: c.monthly_delta, default=None)

    explanations: list[str] = []
    if norm_action != "ALL":
        if not filtered_changes and not filtered_skipped:
            explanations.append(f"No {norm_action} resources found in this Terraform plan.")
        elif not filtered_changes:
            s_count = len(filtered_skipped)
            explanations.append(
                f"{s_count} {norm_action} resource{'s were' if s_count > 1 else ' was'} skipped (non-billable). No direct cost impact."
            )

    if increases:
        count_str = f"{len(increases)} {norm_action if norm_action != 'ALL' else ''} resource{'s' if len(increases) > 1 else ''}".strip()
        explanations.append(f"{count_str} increased projected monthly cost.")
    if largest_inc:
        sku_info = f" ({largest_inc.new_sku})" if largest_inc.new_sku else ""
        explanations.append(
            f"'{largest_inc.address}'{sku_info} contributed the largest increase: "
            f"{format_currency(largest_inc.monthly_delta, show_sign=True)}/month."
        )
    if decreases:
        count_str = f"{len(decreases)} {norm_action if norm_action != 'ALL' else ''} resource{'s' if len(decreases) > 1 else ''}".strip()
        explanations.append(f"{count_str} reduced projected monthly cost.")
    if largest_dec:
        explanations.append(
            f"'{largest_dec.address}' contributed the largest decrease: "
            f"{format_currency(largest_dec.monthly_delta, show_sign=True)}/month."
        )
    if not increases and not decreases and (norm_action == "ALL" or filtered_changes):
        explanations.append("No billable cost delta detected across parsed resources.")

    # Budget calculations
    budget_info: Optional[dict[str, Any]] = None
    if max_increase is not None:
        if norm_action == "ALL":
            is_passed = report.budget_passed
            eval_delta = report.total_delta
        else:
            is_passed = filtered_total_delta <= max_increase
            eval_delta = filtered_total_delta

        rem = max_increase - eval_delta
        pct = round((eval_delta / max_increase * 100), 1) if max_increase > 0 else (0.0 if eval_delta <= 0 else 100.0)
        budget_info = {
            "max_increase": round(max_increase, 2),
            "max_increase_formatted": format_currency(max_increase),
            "total_delta": round(eval_delta, 2),
            "total_delta_formatted": format_currency(eval_delta, show_sign=True),
            "remaining_budget": round(rem, 2),
            "remaining_budget_formatted": format_currency(rem, show_sign=True),
            "percent_used": pct,
            "passed": is_passed,
            "status": "PASS" if is_passed else "FAILED",
            "plan_passed": report.budget_passed,
            "plan_total_delta": round(report.total_delta, 2),
            "filter_action": norm_action,
        }

    return {
        "status": "success",
        "plan_file": plan_name,
        "selected_action": norm_action,
        "action_counts": action_counts,
        "terraform_version": plan_result.terraform_version or "Unknown",
        "format_version": plan_result.format_version or "Unknown",
        "summary": {
            "total_old_cost": round(filtered_total_old, 2),
            "total_old_cost_formatted": format_currency(filtered_total_old),
            "total_new_cost": round(filtered_total_new, 2),
            "total_new_cost_formatted": format_currency(filtered_total_new),
            "total_delta": round(filtered_total_delta, 2),
            "total_delta_formatted": format_currency(filtered_total_delta, show_sign=True),
            "currency": report.currency,
            "total_changes": filtered_total_changes,
            "billable_count": len(filtered_changes),
            "skipped_count": len(filtered_skipped),
            "plan_counts": plan_result.summary,
            "selected_action": norm_action,
            "action_counts": action_counts,
        },
        "budget": budget_info,
        "top_contributors": [c.to_dict() for c in filtered_top_contributors],
        "optimization_suggestions": [s.to_dict() for s in filtered_suggestions],
        "cost_changes": [c.to_dict() for c in filtered_changes],
        "skipped_resources": [s.to_dict() for s in filtered_skipped],
        "cache_stats": report.pricing_stats,
        "insights": {
            "largest_increase_resource": largest_inc.address if largest_inc else None,
            "largest_increase_amount": round(largest_inc.monthly_delta, 2) if largest_inc else 0.0,
            "largest_decrease_resource": largest_dec.address if largest_dec else None,
            "largest_decrease_amount": round(largest_dec.monthly_delta, 2) if largest_dec else 0.0,
            "increase_count": len(increases),
            "decrease_count": len(decreases),
            "unchanged_count": len(unchanged),
            "explanations": explanations,
            "itemized_reasons": [
                {
                    "address": c.address,
                    "action": c.action,
                    "old_sku": c.old_sku,
                    "new_sku": c.new_sku,
                    "old_monthly_cost": round(c.old_monthly_cost, 2),
                    "new_monthly_cost": round(c.new_monthly_cost, 2),
                    "monthly_delta": round(c.monthly_delta, 2),
                    "percentage_change": c.percentage_change,
                    "reason": c.reason,
                }
                for c in filtered_changes
            ],
        },
        "warnings": report.warnings,
    }


class CostGuardHTTPHandler(http.server.SimpleHTTPRequestHandler):
    """
    Custom HTTP request handler serving static dashboard files and JSON API.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, directory=str(WEB_DIR), **kwargs)

    def do_GET(self) -> None:
        parsed_url = urllib.parse.urlparse(self.path)
        path = parsed_url.path

        if path in ("/", "/index.html"):
            self.send_file_response(WEB_DIR / "index.html", "text/html")
        elif path == "/styles.css":
            self.send_file_response(WEB_DIR / "styles.css", "text/css")
        elif path == "/app.js":
            self.send_file_response(WEB_DIR / "app.js", "application/javascript")
        elif path == "/api/analysis":
            self.handle_api_analysis()
        elif path == "/api/plans":
            self.handle_api_plans()
        else:
            super().do_GET()

    def do_POST(self) -> None:
        parsed_url = urllib.parse.urlparse(self.path)
        if parsed_url.path == "/api/analyze":
            self.handle_api_post_analyze()
        else:
            self.send_error(404, "Endpoint not found")

    def send_file_response(self, file_path: Path, content_type: str) -> None:
        if not file_path.exists():
            self.send_error(404, f"File {file_path.name} not found")
            return
        content = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", f"{content_type}; charset=utf-8")
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(content)

    def send_json_response(self, data: dict[str, Any], status: int = 200) -> None:
        payload = json.dumps(data, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(payload)

    def handle_api_analysis(self) -> None:
        server: Any = self.server
        plan_path = getattr(server, "plan_path", str(SAMPLE_PLANS_DIR / "create.json"))
        max_increase = getattr(server, "max_increase", None)
        offline = getattr(server, "offline", False)

        parsed_url = urllib.parse.urlparse(self.path)
        query_params = urllib.parse.parse_qs(parsed_url.query)
        action = query_params.get("action", [None])[0]

        try:
            payload = generate_analysis_payload(
                plan_source=plan_path,
                max_increase=max_increase,
                offline=offline,
                action=action,
            )
            self.send_json_response(payload)
        except Exception as exc:
            self.send_json_response({"status": "error", "message": str(exc)}, status=500)

    def handle_api_plans(self) -> None:
        plans = []
        if SAMPLE_PLANS_DIR.exists():
            for p in sorted(SAMPLE_PLANS_DIR.glob("*.json")):
                plans.append(p.name)
        self.send_json_response({"plans": plans})

    def handle_api_post_analyze(self) -> None:
        content_len = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_len).decode("utf-8")
        try:
            req_data = json.loads(body)
            plan_name = req_data.get("plan", "create.json")
            action = req_data.get("action")
            max_inc = req_data.get("max_increase")
            if max_inc is not None:
                max_inc = float(max_inc)

            plan_file = SAMPLE_PLANS_DIR / plan_name
            if not plan_file.exists():
                self.send_json_response({"status": "error", "message": f"Plan {plan_name} not found"}, status=404)
                return

            server: Any = self.server
            server.plan_path = str(plan_file)
            server.max_increase = max_inc

            payload = generate_analysis_payload(
                plan_source=str(plan_file),
                max_increase=max_inc,
                offline=getattr(server, "offline", False),
                action=action,
            )
            self.send_json_response(payload)
        except Exception as exc:
            self.send_json_response({"status": "error", "message": str(exc)}, status=400)


def create_server(
    host: str = "127.0.0.1",
    port: int = 5000,
    plan_path: Optional[str] = None,
    max_increase: Optional[float] = None,
    offline: bool = False,
) -> http.server.ThreadingHTTPServer:
    """
    Creates and returns a threaded HTTP server configured for CostGuard web.
    """
    target_plan = plan_path or str(SAMPLE_PLANS_DIR / "create.json")
    server = http.server.ThreadingHTTPServer((host, port), CostGuardHTTPHandler)
    setattr(server, "plan_path", target_plan)
    setattr(server, "max_increase", max_increase)
    setattr(server, "offline", offline)
    return server


def start_web_app(
    host: str = "127.0.0.1",
    port: int = 5000,
    plan_path: Optional[str] = None,
    max_increase: Optional[float] = None,
    offline: bool = False,
    open_browser: bool = False,
) -> None:
    """
    Starts the local CostGuard web application server.
    """
    target_plan = plan_path or str(SAMPLE_PLANS_DIR / "create.json")
    server = create_server(
        host=host,
        port=port,
        plan_path=target_plan,
        max_increase=max_increase,
        offline=offline,
    )
    url = f"http://{host}:{port}"

    print("=" * 70)
    print("CostGuard Web Visualization Interface")
    print("=" * 70)
    print(f"Server URL   : {url}")
    print(f"Active Plan  : {target_plan}")
    if max_increase is not None:
        print(f"Budget Limit : {format_currency(max_increase)}")
    print("Status       : Running (Press Ctrl+C to stop)")
    print("=" * 70)

    if open_browser:
        try:
            import webbrowser
            webbrowser.open(url)
        except Exception:
            pass

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping CostGuard web server...")
    finally:
        server.server_close()


def main() -> None:
    """Entrypoint for python -m costguard.web"""
    parser = argparse.ArgumentParser(
        prog="costguard.web",
        description="Launch CostGuard local web visualization interface.",
    )
    parser.add_argument(
        "-p",
        "--plan",
        type=str,
        default=str(SAMPLE_PLANS_DIR / "create.json"),
        help="Path to Terraform plan JSON file.",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=5000,
        help="HTTP port to listen on (default 5000).",
    )
    parser.add_argument(
        "--host",
        type=str,
        default="127.0.0.1",
        help="HTTP host to bind to (default 127.0.0.1).",
    )
    parser.add_argument(
        "--max-increase",
        type=float,
        default=None,
        help="Maximum allowed monthly cost increase in USD.",
    )
    parser.add_argument(
        "--offline",
        action="store_true",
        help="Operate in offline mode using local SQLite cache.",
    )
    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Do not open browser automatically.",
    )

    args = parser.parse_args()
    start_web_app(
        host=args.host,
        port=args.port,
        plan_path=args.plan,
        max_increase=args.max_increase,
        offline=args.offline,
        open_browser=not args.no_browser,
    )


if __name__ == "__main__":
    main()
