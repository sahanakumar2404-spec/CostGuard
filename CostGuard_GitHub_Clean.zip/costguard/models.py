"""
CostGuard Data Models
Defines core data structures for Terraform plan resource change analysis.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class ActionType(str, Enum):
    """
    Standard normalized Terraform resource change actions.
    Inherits from str for seamless serialization and backward compatibility.
    """
    CREATE = "CREATE"
    DELETE = "DELETE"
    UPDATE = "UPDATE"
    REPLACE = "REPLACE"
    NOOP = "NOOP"
    UNKNOWN = "UNKNOWN"

    def __str__(self) -> str:
        return self.value


@dataclass
class ResourceChange:
    """
    Represents a structured resource change extracted from a Terraform plan.

    Attributes:
        address: Full Terraform resource address (e.g. 'aws_instance.web').
        resource_type: Terraform resource type (e.g. 'aws_instance').
        action: Normalized action (CREATE, DELETE, UPDATE, REPLACE, etc.).
        before_state: Dictionary of resource attributes before the change (or None).
        after_state: Dictionary of resource attributes after the change (or None).
        old_sku: SKU / instance size prior to change (if applicable).
        new_sku: SKU / instance size after change (if applicable).
        old_region: Cloud region / location prior to change (if applicable).
        new_region: Cloud region / location after change (if applicable).
    """
    address: str
    resource_type: str
    action: ActionType | str
    before_state: Optional[dict[str, Any]] = None
    after_state: Optional[dict[str, Any]] = None
    old_sku: Optional[str] = None
    new_sku: Optional[str] = None
    old_region: Optional[str] = None
    new_region: Optional[str] = None

    def __post_init__(self) -> None:
        # Normalize action to string or ActionType value
        if isinstance(self.action, ActionType):
            self.action = self.action.value
        elif isinstance(self.action, str):
            self.action = self.action.upper()
        else:
            self.action = str(self.action).upper()

    @property
    def sku(self) -> Optional[str]:
        """Convenience property for primary/effective SKU (new_sku if available, else old_sku)."""
        return self.new_sku or self.old_sku

    @property
    def region(self) -> Optional[str]:
        """Convenience property for primary/effective region (new_region if available, else old_region)."""
        return self.new_region or self.old_region

    @property
    def is_create(self) -> bool:
        return self.action == ActionType.CREATE.value

    @property
    def is_delete(self) -> bool:
        return self.action == ActionType.DELETE.value

    @property
    def is_update(self) -> bool:
        return self.action == ActionType.UPDATE.value

    @property
    def is_replace(self) -> bool:
        return self.action == ActionType.REPLACE.value

    def to_dict(self) -> dict[str, Any]:
        """Serialize resource change to dictionary for JSON output or downstream consumption."""
        return {
            "address": self.address,
            "resource_type": self.resource_type,
            "action": self.action,
            "before_state": self.before_state,
            "after_state": self.after_state,
            "old_sku": self.old_sku,
            "new_sku": self.new_sku,
            "old_region": self.old_region,
            "new_region": self.new_region,
            "sku": self.sku,
            "region": self.region,
        }


@dataclass
class PlanParseResult:
    """
    Represents the full result of parsing a Terraform plan.

    Attributes:
        resource_changes: List of parsed ResourceChange instances.
        warnings: List of diagnostic or non-fatal warning messages.
        format_version: Terraform plan format version if present.
        terraform_version: Terraform CLI version if present.
        raw_plan: Original raw parsed dictionary if available.
    """
    resource_changes: list[ResourceChange] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    format_version: Optional[str] = None
    terraform_version: Optional[str] = None
    raw_plan: Optional[dict[str, Any]] = None

    @property
    def summary(self) -> dict[str, int]:
        """Calculates breakdown of resource change actions."""
        counts = {
            "total": len(self.resource_changes),
            "create": 0,
            "update": 0,
            "delete": 0,
            "replace": 0,
            "noop": 0,
            "unknown": 0,
        }
        for rc in self.resource_changes:
            action = rc.action
            if action == ActionType.CREATE.value:
                counts["create"] += 1
            elif action == ActionType.UPDATE.value:
                counts["update"] += 1
            elif action == ActionType.DELETE.value:
                counts["delete"] += 1
            elif action == ActionType.REPLACE.value:
                counts["replace"] += 1
            elif action == ActionType.NOOP.value:
                counts["noop"] += 1
            else:
                counts["unknown"] += 1
        return counts

    def to_dict(self) -> dict[str, Any]:
        """Converts parse result to structured dict suitable for JSON export."""
        return {
            "summary": self.summary,
            "resource_changes": [rc.to_dict() for rc in self.resource_changes],
            "warnings": self.warnings,
            "format_version": self.format_version,
            "terraform_version": self.terraform_version,
        }
