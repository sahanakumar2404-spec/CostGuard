/**
 * CostGuard Web Dashboard Client
 * Fetches real cost-analysis data from CostGuard Python engine and renders
 * summary cards, Chart.js visualizations, itemized tables, and budget guardrails.
 */

let costChartInstance = null;
let contributorsChartInstance = null;
let currentAction = "ALL";

function formatCurrency(val, showSign = false) {
  if (val === null || val === undefined) return "$0.00";
  const num = Number(val);
  const formatted = Math.abs(num).toLocaleString("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  if (showSign) {
    if (num > 0) return `+${formatted}`;
    if (num < 0) return `-${formatted}`;
  }
  return formatted;
}

async function fetchAnalysis() {
  try {
    const params = new URLSearchParams();
    if (currentAction && currentAction !== "ALL") {
      params.set("action", currentAction);
    }
    const url = params.toString() ? `/api/analysis?${params.toString()}` : "/api/analysis";
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP error ${res.status}`);
    const data = await res.json();
    renderDashboard(data);
  } catch (err) {
    console.error("Failed to load CostGuard analysis:", err);
  }
}

async function evaluateCustomPlan() {
  const planSelect = document.getElementById("planSelect");
  const budgetInput = document.getElementById("budgetInput");

  const planName = planSelect ? planSelect.value : "01_create.json";
  const budgetVal = budgetInput && budgetInput.value ? parseFloat(budgetInput.value) : null;

  try {
    const res = await fetch("/api/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: jsonPayload({
        plan: planName,
        max_increase: budgetVal,
        action: currentAction,
      }),
    });
    if (!res.ok) throw new Error(`HTTP error ${res.status}`);
    const data = await res.json();
    renderDashboard(data);
  } catch (err) {
    console.error("Failed to evaluate plan:", err);
  }
}

function setupActionSelector() {
  const actionButtons = document.querySelectorAll(".btn-action");
  actionButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const action = btn.getAttribute("data-action");
      if (!action || action === currentAction) return;
      currentAction = action;
      updateActionButtonStates();
      evaluateCustomPlan();
    });
  });
}

function updateActionButtonStates() {
  const actionButtons = document.querySelectorAll(".btn-action");
  actionButtons.forEach((btn) => {
    const action = btn.getAttribute("data-action");
    if (action === currentAction) {
      btn.classList.add("active");
    } else {
      btn.classList.remove("active");
    }
  });
}

function jsonPayload(obj) {
  return JSON.stringify(obj);
}

function renderDashboard(data) {
  if (!data || data.status !== "success") return;

  const summary = data.summary || {};
  const budget = data.budget;
  const changes = data.cost_changes || [];
  const skipped = data.skipped_resources || [];
  const cacheStats = data.cache_stats || {};
  const insights = data.insights || {};

  // 1. Action Counts & Selector State
  const counts = data.action_counts || {};
  const countAll = document.getElementById("countAll");
  const countCreate = document.getElementById("countCreate");
  const countUpdate = document.getElementById("countUpdate");
  const countDelete = document.getElementById("countDelete");
  const countReplace = document.getElementById("countReplace");

  if (countAll) countAll.textContent = counts.ALL ?? 0;
  if (countCreate) countCreate.textContent = counts.CREATE ?? 0;
  if (countUpdate) countUpdate.textContent = counts.UPDATE ?? 0;
  if (countDelete) countDelete.textContent = counts.DELETE ?? 0;
  if (countReplace) countReplace.textContent = counts.REPLACE ?? 0;

  if (data.selected_action) {
    currentAction = data.selected_action;
    updateActionButtonStates();
  }

  // 2. Metadata Ribbon
  document.getElementById("metaPlanFile").textContent = data.plan_file || "tfplan";
  document.getElementById("metaTfVersion").textContent = data.terraform_version || "1.x";
  document.getElementById("metaTotalChanges").textContent = summary.total_changes || 0;
  document.getElementById("metaBillableCount").textContent = summary.billable_count || 0;
  document.getElementById("metaSkippedCount").textContent = summary.skipped_count || 0;
  const metaFilterAction = document.getElementById("metaFilterAction");
  if (metaFilterAction) {
    metaFilterAction.textContent = data.selected_action || currentAction;
  }

  // 3. Summary Cards
  document.getElementById("currentCostVal").textContent = formatCurrency(summary.total_old_cost);
  document.getElementById("projectedCostVal").textContent = formatCurrency(summary.total_new_cost);

  const deltaElem = document.getElementById("monthlyDeltaVal");
  deltaElem.textContent = formatCurrency(summary.total_delta, true);
  if (summary.total_delta > 0) {
    deltaElem.className = "card-value delta-pos";
  } else if (summary.total_delta < 0) {
    deltaElem.className = "card-value delta-neg";
  } else {
    deltaElem.className = "card-value delta-zero";
  }

  const budgetStatusElem = document.getElementById("budgetStatusVal");
  const budgetStatusSub = document.getElementById("budgetStatusSub");
  if (budget) {
    budgetStatusElem.textContent = budget.status;
    budgetStatusElem.className = `card-value badge-status ${budget.passed ? "status-pass" : "status-fail"}`;
    const actionNote = data.selected_action && data.selected_action !== "ALL" ? ` (${data.selected_action})` : "";
    budgetStatusSub.textContent = `Limit: ${formatCurrency(budget.max_increase)}${actionNote}`;
  } else {
    budgetStatusElem.textContent = "UNSET";
    budgetStatusElem.className = "card-value badge-status";
    budgetStatusSub.textContent = "No limit set";
  }

  // 4. Budget Guardrail Banner
  const banner = document.getElementById("budgetBanner");
  const guardIcon = document.getElementById("guardrailIcon");
  const guardTitle = document.getElementById("guardrailTitle");
  const guardSub = document.getElementById("guardrailSubtitle");
  const guardLimit = document.getElementById("guardrailLimit");
  const guardInc = document.getElementById("guardrailIncrease");
  const guardRem = document.getElementById("guardrailRemaining");
  const progressBar = document.getElementById("budgetProgressBar");

  if (budget) {
    banner.style.display = "block";
    guardLimit.textContent = formatCurrency(budget.max_increase);
    guardInc.textContent = formatCurrency(budget.total_delta, true);
    guardRem.textContent = formatCurrency(budget.remaining_budget, true);

    const actionLabel = data.selected_action && data.selected_action !== "ALL" ? ` [${data.selected_action}]` : "";
    if (budget.passed) {
      banner.className = "budget-guardrail-section pass";
      guardIcon.textContent = "✓";
      guardTitle.textContent = `✓ BUDGET CHECK: PASS${actionLabel}`;
      if (data.selected_action && data.selected_action !== "ALL") {
        guardSub.textContent = `Projected monthly increase for ${data.selected_action} is within allowed limits. (Plan total: ${formatCurrency(budget.plan_total_delta, true)})`;
      } else {
        guardSub.textContent = "Projected monthly increase is within allowed limits.";
      }
    } else {
      banner.className = "budget-guardrail-section failed";
      guardIcon.textContent = "✗";
      guardTitle.textContent = `✗ BUDGET CHECK: FAILED — DEPLOYMENT BLOCKED${actionLabel}`;
      guardSub.textContent = `Cost delta exceeds maximum budget increase by ${formatCurrency(Math.abs(budget.remaining_budget))}.`;
    }

    const pct = Math.min(Math.max(budget.percent_used || 0, 0), 100);
    progressBar.style.width = `${pct}%`;
  } else {
    banner.className = "budget-guardrail-section";
    guardIcon.textContent = "ℹ";
    guardTitle.textContent = "BUDGET GUARDRAIL: INACTIVE";
    guardSub.textContent = "Specify a budget limit using '--max-increase <amount>' or in the header to activate circuit breaker.";
    guardLimit.textContent = "None";
    guardInc.textContent = formatCurrency(summary.total_delta, true);
    guardRem.textContent = "N/A";
    progressBar.style.width = "0%";
  }

  // 5. Render Charts
  renderCharts(summary, changes);

  // 6. Why Did Cost Change?
  const insightsBody = document.getElementById("insightsBody");
  insightsBody.innerHTML = "";
  const explanations = insights.explanations || [];
  if (explanations.length === 0) {
    insightsBody.innerHTML = '<div class="insight-point"><span class="insight-text">No significant cost variations detected.</span></div>';
  } else {
    explanations.forEach((text) => {
      const point = document.createElement("div");
      point.className = "insight-point";
      point.innerHTML = `<span class="insight-bullet">▸</span><span class="insight-text">${text}</span>`;
      insightsBody.appendChild(point);
    });
  }

  // 7. Optimization Recommendations (Advisory)
  const suggestionsBody = document.getElementById("suggestionsBody");
  if (suggestionsBody) {
    suggestionsBody.innerHTML = "";
    const suggestions = data.optimization_suggestions || [];
    if (suggestions.length === 0) {
      suggestionsBody.innerHTML = '<div class="suggestion-empty">No high-risk cost anomalies detected; projected changes adhere to baseline sizing best practices.</div>';
    } else {
      suggestions.forEach((sug) => {
        const item = document.createElement("div");
        item.className = "suggestion-item";
        item.innerHTML = `
          <div class="suggestion-header-row">
            <span class="badge-category">${sug.category}</span>
            <span class="suggestion-title">${sug.title}</span>
          </div>
          <div class="suggestion-desc">${sug.description}</div>
          <div class="suggestion-notice">${sug.advisory_notice}</div>
        `;
        suggestionsBody.appendChild(item);
      });
    }
  }

  // 8. Resource Breakdown Table
  const filterLabel = data.selected_action && data.selected_action !== "ALL" ? `${data.selected_action} ` : "";
  const resourcesTableBody = document.getElementById("resourcesTableBody");
  resourcesTableBody.innerHTML = "";
  if (changes.length === 0) {
    resourcesTableBody.innerHTML = `<tr><td colspan="11" style="text-align:center; padding: 24px; color: var(--text-dim);">No billable ${filterLabel}resource changes found in this plan.</td></tr>`;
  } else {
    changes.forEach((c) => {
      const tr = document.createElement("tr");

      const deltaClass = c.monthly_delta > 0 ? "delta-pos" : c.monthly_delta < 0 ? "delta-neg" : "delta-zero";
      const actionClass = c.action ? c.action.toLowerCase() : "unknown";
      const skuDisplay = c.action === "UPDATE" || c.action === "REPLACE"
        ? (c.old_sku !== c.new_sku ? `${c.old_sku || "-"} → ${c.new_sku || "-"}` : c.new_sku || "-")
        : (c.new_sku || c.old_sku || "-");
      const regionDisplay = c.new_region || c.old_region || "-";

      let pctStr = "—";
      let pctClass = "pct-zero";
      if (c.percentage_change !== null && c.percentage_change !== undefined) {
        pctStr = `${c.percentage_change > 0 ? "+" : ""}${c.percentage_change.toFixed(1)}%`;
        pctClass = c.percentage_change > 0 ? "pct-pos" : c.percentage_change < 0 ? "pct-neg" : "pct-zero";
      } else if (c.action === "CREATE") {
        pctStr = "New";
        pctClass = "pct-pos";
      }
      const reasonDisplay = c.reason || "Standard configuration";

      tr.innerHTML = `
        <td style="font-weight: 600;">${c.address}</td>
        <td><span class="badge-action ${actionClass}">${c.action}</span></td>
        <td style="color: var(--text-muted); font-size: 12px;">${c.resource_type}</td>
        <td class="font-mono">${skuDisplay}</td>
        <td class="font-mono" style="color: var(--text-muted);">${regionDisplay}</td>
        <td class="text-right font-mono">${formatCurrency(c.old_monthly_cost)}</td>
        <td class="text-right font-mono">${formatCurrency(c.new_monthly_cost)}</td>
        <td class="text-right font-mono ${deltaClass}">${formatCurrency(c.monthly_delta, true)}</td>
        <td class="text-right font-mono ${pctClass}">${pctStr}</td>
        <td class="reason-text">${reasonDisplay}</td>
        <td><span style="font-size: 11px; padding: 2px 6px; border-radius: 4px; background: rgba(255,255,255,0.06); text-transform: uppercase;">${c.pricing_source}</span></td>
      `;
      resourcesTableBody.appendChild(tr);
    });
  }

  // 9. Skipped Resources Table
  const skippedTableBody = document.getElementById("skippedTableBody");
  skippedTableBody.innerHTML = "";
  if (skipped.length === 0) {
    skippedTableBody.innerHTML = `<tr><td colspan="3" style="text-align: center; padding: 16px; color: var(--text-dim);">No ${filterLabel}resources skipped.</td></tr>`;
  } else {
    skipped.forEach((s) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td style="font-weight: 600;">${s.address}</td>
        <td><span class="badge-action ${s.action ? s.action.toLowerCase() : ""}">${s.action}</span></td>
        <td style="color: var(--text-muted); font-size: 12px;">${s.reason}</td>
      `;
      skippedTableBody.appendChild(tr);
    });
  }

  // 8. Cache & API Telemetry
  const hits = cacheStats.cache_hits || 0;
  const misses = cacheStats.cache_misses || 0;
  const apiCalls = cacheStats.api_calls || 0;
  const totalQueries = hits + misses;
  const ratio = totalQueries > 0 ? Math.round((hits / totalQueries) * 100) : 0;

  document.getElementById("statHits").textContent = hits;
  document.getElementById("statMisses").textContent = misses;
  document.getElementById("statApiCalls").textContent = apiCalls;
  document.getElementById("statHitRatio").textContent = `${ratio}%`;
}

function renderCharts(summary, changes) {
  if (typeof Chart === "undefined") {
    console.warn("Chart.js not loaded. Skipping chart rendering.");
    return;
  }

  // 1. Comparison Bar Chart (Old vs New)
  const ctxCompare = document.getElementById("costComparisonChart");
  if (costChartInstance) {
    costChartInstance.destroy();
  }

  costChartInstance = new Chart(ctxCompare, {
    type: "bar",
    data: {
      labels: ["Current Cost", "Projected Cost"],
      datasets: [
        {
          label: "Monthly Cost ($ USD)",
          data: [summary.total_old_cost || 0, summary.total_new_cost || 0],
          backgroundColor: ["rgba(156, 163, 175, 0.4)", "rgba(59, 130, 246, 0.7)"],
          borderColor: ["#9CA3AF", "#3B82F6"],
          borderWidth: 1.5,
          borderRadius: 6,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (ctx) => `Monthly: ${formatCurrency(ctx.parsed.y)}`,
          },
        },
      },
      scales: {
        x: {
          ticks: { color: "#9CA3AF", font: { family: "Inter, sans-serif" } },
          grid: { display: false },
        },
        y: {
          ticks: {
            color: "#9CA3AF",
            callback: (v) => formatCurrency(v),
            font: { family: "monospace" },
          },
          grid: { color: "rgba(255, 255, 255, 0.05)" },
        },
      },
    },
  });

  // 2. Top Cost Contributors Chart (Horizontal Bar Chart)
  const ctxContributors = document.getElementById("contributorsChart");
  if (contributorsChartInstance) {
    contributorsChartInstance.destroy();
  }

  // Sort changes by absolute monthly delta descending
  const sorted = [...changes].sort((a, b) => Math.abs(b.monthly_delta) - Math.abs(a.monthly_delta)).slice(0, 5);
  const labels = sorted.map((c) => {
    const parts = c.address.split(".");
    return parts.length > 1 ? parts[1] : c.address;
  });
  const dataVals = sorted.map((c) => c.monthly_delta);
  const bgColors = dataVals.map((v) => (v >= 0 ? "rgba(239, 68, 68, 0.7)" : "rgba(16, 185, 129, 0.7)"));
  const borderColors = dataVals.map((v) => (v >= 0 ? "#EF4444" : "#10B981"));

  contributorsChartInstance = new Chart(ctxContributors, {
    type: "bar",
    data: {
      labels: labels.length > 0 ? labels : ["No Cost Changes"],
      datasets: [
        {
          label: "Monthly Delta ($ USD)",
          data: dataVals.length > 0 ? dataVals : [0],
          backgroundColor: bgColors.length > 0 ? bgColors : ["rgba(156, 163, 175, 0.4)"],
          borderColor: borderColors.length > 0 ? borderColors : ["#9CA3AF"],
          borderWidth: 1.5,
          borderRadius: 4,
        },
      ],
    },
    options: {
      indexAxis: "y",
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (ctx) => `Delta: ${formatCurrency(ctx.parsed.x, true)}/mo`,
          },
        },
      },
      scales: {
        x: {
          ticks: {
            color: "#9CA3AF",
            callback: (v) => formatCurrency(v, true),
            font: { family: "monospace" },
          },
          grid: { color: "rgba(255, 255, 255, 0.05)" },
        },
        y: {
          ticks: { color: "#F9FAFB", font: { family: "monospace", size: 11 } },
          grid: { display: false },
        },
      },
    },
  });
}

async function loadAvailablePlans() {
  try {
    const res = await fetch("/api/plans");
    if (!res.ok) return;
    const data = await res.json();
    const plans = data.plans || [];
    const planSelect = document.getElementById("planSelect");
    if (!planSelect || plans.length === 0) return;

    const currentVal = planSelect.value;
    planSelect.innerHTML = "";
    plans.forEach((p) => {
      const opt = document.createElement("option");
      opt.value = p;
      opt.textContent = `sample_plans/${p}`;
      if (p === currentVal) opt.selected = true;
      planSelect.appendChild(opt);
    });
  } catch (err) {
    console.debug("Could not fetch plan list:", err);
  }
}

// Initial bootstrap on DOM ready
document.addEventListener("DOMContentLoaded", () => {
  setupActionSelector();
  loadAvailablePlans();
  fetchAnalysis();

  const reanalyzeBtn = document.getElementById("reanalyzeBtn");
  if (reanalyzeBtn) {
    reanalyzeBtn.addEventListener("click", evaluateCustomPlan);
  }
  const planSelect = document.getElementById("planSelect");
  if (planSelect) {
    planSelect.addEventListener("change", evaluateCustomPlan);
  }
});
