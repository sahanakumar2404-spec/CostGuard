# CostGuard (Phases 1–5)

**CostGuard** is an open-source, production-ready cost governance and speculative execution plan analyzer for Terraform. It ingests Terraform plan JSON, extracts structured resource changes, queries live retail pricing from the official Azure Retail Prices API with an embedded SQLite write-through cache, calculates exact monthly cost deltas (730-hour standard), enforces budget circuit breakers before deployment, delivers smart explainable cost insights with conservative advisory suggestions, and provides a polished local FinOps web dashboard.

---

## Capabilities Overview

### Phase 1: Ingestion & Resource Modeling
* **Standalone CLI (`costguard`)**: Receives Terraform execution plans via `--plan <file>` or piped standard input (`cat plan.json | costguard`).
* **Normalized Change Actions**: Full support for `CREATE`, `DELETE`, `UPDATE`, and `REPLACE` (including `["delete", "create"]` and `["create", "delete"]`).
* **Multi-Cloud Extraction**: Extracts SKU / VM size and cloud region/location across AWS, Azure, and GCP.
* **Safe Diagnostic Engine**: Never crashes on malformed JSON, empty plans, missing fields, or unrecognized resource types; returns actionable warnings.

### Phase 2: Live Azure Pricing & SQLite Cache
* **Live Azure Retail Prices API**: Queries `https://prices.azure.com/api/retail/prices` dynamically without hardcoding prices.
* **Consumption Pricing Enforcement**: Strictly filters for standard Consumption pricing, excluding Spot and Low Priority items.
* **SQLite Write-Through Cache**:
  - Checks local cache (`data/pricing_cache.db`) before remote calls.
  - Automatically writes live pricing responses to SQLite.
  - Tracks performance metrics: `cache_hits`, `cache_misses`, `api_calls`.
* **Safe Degradation**: Falls back to valid cache on network failure or runs in `--offline` mode.

### Phase 3: Cost Accounting Engine & Budget Circuit Breaker
* **730-Hour Standard Monthly Formula**:
  $$\text{monthly\_cost} = \text{hourly\_price} \times 730$$
* **Action Cost Rules**:
  - `CREATE`: $\text{old} = \$0.00$, $\text{new} = \text{price}$, $\text{delta} = +\text{new}$
  - `DELETE`: $\text{old} = \text{price}$, $\text{new} = \$0.00$, $\text{delta} = -\text{old}$
  - `UPDATE`: $\text{old} = \text{old\_price}$, $\text{new} = \text{new\_price}$, $\text{delta} = \text{new} - \text{old}$
  - `REPLACE`: $\text{old} = \text{old\_price}$, $\text{new} = \text{new\_price}$, $\text{delta} = \text{new} - \text{old}$
* **Full Precision Accounting**: Intermediate cost summations remain unrounded float values; rounding is only applied at the display boundary.
* **Non-Billable Resource Handling**: Gracefully skips infrastructure components (e.g. `random_pet`, `azurerm_resource_group`) with clear diagnostic reasons without crashing.
* **Budget Circuit Breaker (`--max-increase <amount>`)**:
  - $\text{total\_delta} \le \text{max\_increase}$: **PASS** (Exit Code `0`)
  - $\text{total\_delta} > \text{max\_increase}$: **FAILED / BLOCKED** (Exit Code `1`)
  - Invalid CLI / input: **INVALID** (Exit Code `2`)

### Phase 4: FinOps Web Visualization & Reporting Dashboard
* **Primary CLI with Supporting Web UI**: The CLI remains the primary gatekeeper for CI/CD pipelines, while `--web` provides an intuitive interactive visual dashboard for engineering teams.
* **Zero External Backend Dependencies**: Implemented natively using Python's standard `http.server.ThreadingHTTPServer` without requiring heavy frameworks.
* **Ground-Truth Data Flow**: Does NOT duplicate cost calculation logic in JavaScript or use fake mock data. The frontend consumes real CostGuard engine output via JSON endpoints.
* **Interactive Plan Switching & Budget Tuning**: Switch between plans (`sample_plans/*.json`) or adjust budget limits dynamically via the UI header.
* **Rich Data Visualizations (Chart.js)**:
  - **Cost Comparison Bar Chart**: Side-by-side comparison of Current Cost vs. Projected Cost.
  - **Top Cost Contributors Chart**: Horizontal bar chart ranking resources by monthly delta impact.
* **Budget Circuit Breaker Guardrail Banner**: Real-time visual pass/fail indicator, remaining budget headroom, and percentage-utilized progress bar.
* **Itemized Resource & Skipped Components Tables**: Detailed table with resource addresses, actions, SKUs, regions, old/new monthly rates, delta, % change, reason, and pricing source badges.
* **Embedded Cache Telemetry**: Live dashboard cards displaying cache hits, cache misses, Azure API call count, and hit ratio.

### Phase 5: Smart Analysis, Conservative Suggestions & Demo Scenarios
* **Smart Cost Explanations**:
  - Every priced resource provides action, old/new SKU, old/new monthly cost, delta, percentage change, and reason.
  - Explanations explicitly clarify newly provisioned capacity, decommissioned instances, upgrades, downgrades, or in-place modifications.
* **Top Cost Contributors Ranking**:
  - Automatically identifies and sorts resources driving the largest positive monthly increases.
  - Exact accounting precision is maintained across both CLI tables and Web UI graphs.
* **Conservative Advisory Optimization Suggestions**:
  - **Non-Production Workload Sizing**: Detects non-production environments (`dev`, `test`, `staging`, `qa`, `sandbox`) running 24/7 at significant projected cost; advises reviewing off-hours auto-shutdown schedules or burstable B-series SKUs.
  - **Significant SKU Upgrades**: Flags steep instance upgrades (e.g. +300% / >$70/mo) to verify performance benchmarks justify the tier jump.
  - **High-Capacity Provisioning**: Highlights newly provisioned large instances; suggests evaluating 1-Year or 3-Year Azure Savings Plans / Reservations.
  - **Strict Advisory Standard**: Suggestions are purely advisory, never claim guaranteed savings, never modify Terraform code, and are clearly marked for engineer validation.
* **Hostile / Edge Input Robustness**:
  - Handled cleanly without unhandled tracebacks: malformed JSON syntax, missing resource fields, missing SKU, missing region, unknown cloud resource types, duplicate resource definitions, invalid actions, and network API failure with SQLite cache fallback.
* **5 Realistic Demo Scenarios**:
  - `sample_plans/01_create.json`: CREATE resources including Azure VMs and non-billable components.
  - `sample_plans/02_delete.json`: DELETE resources demonstrating negative monthly cost deltas.
  - `sample_plans/03_update_sku.json`: UPDATE/REPLACE demonstrating SKU upgrade (+300%) and advisory suggestions.
  - `sample_plans/04_mixed_hostile.json`: Mixture of valid, unsupported, missing-field, and corrupted inputs handled safely.
  - `sample_plans/05_budget_fail.json`: Realistic plan breaching a $100 budget limit to demonstrate deployment blocking.

---

## Architecture & Responsibilities

```
                         +-----------------------------------+
                         |    Terraform Speculative Plan     |
                         |           (JSON format)           |
                         +-----------------+-----------------+
                                           |
                                           v
                         +-----------------------------------+
                         |       CostGuard Plan Parser       |
                         |  (Extracts Action, SKU, Region)   |
                         +-----------------+-----------------+
                                           |
                                           v
                         +-----------------------------------+
                         |     Azure Pricing Client &        |
                         |   SQLite Write-Through Cache      |
                         +-----------------+-----------------+
                                           |
                                           v
                         +-----------------------------------+
                         |      Cost Accounting Engine       |
                         | (730h formula, Deltas, Top        |
                         |  Contributors, Advisory Insights) |
                         +--------+-----------------+--------+
                                  |                 |
                 +----------------+                 +----------------+
                 v                                                   v
+---------------------------------+               +----------------------------------+
|          CostGuard CLI          |               |     Local Web HTTP API Server    |
| (Terminal tables, Top contribs, |               | (Zero-dependency ThreadingServer |
|   Suggestions, CI/CD gates:     |               |   endpoints: /api/analysis)      |
|   exit codes 0 / 1 / 2)         |               +-----------------+----------------+
+---------------------------------+                                 |
                                                                    v
                                                  +----------------------------------+
                                                  |      FinOps Web Dashboard        |
                                                  |   (Charts, Insights, Breakdown)  |
                                                  +----------------------------------+
```

| Layer | Responsibility | Output / Interface |
|---|---|---|
| **CLI (`costguard`)** | Automated CI/CD enforcement, blocking deployments on budget breach, stdout/stderr formatting, return codes (`0`, `1`, `2`). | Terminal table, stderr diagnostics, JSON stdout. |
| **Engine (`costguard.accounting`)** | Single source of truth for cost calculations, 730h monthly formula, delta logic, top contributors, advisory suggestions, and budget evaluation. | Python dataclasses, unrounded calculations. |
| **Web Server (`costguard.web`)** | Lightweight local HTTP server serving static dashboard assets and JSON analysis APIs. | `http://127.0.0.1:5000/api/analysis` |
| **Web UI (`web/`)** | Visual representation of real engine output: charts, guardrail banner, explainable insights, itemized tables, optimization recommendations. | Responsive browser interface. |

---

## Project Structure

```
costguard/
├── costguard/
│   ├── __init__.py           # Package exports and public API
│   ├── cli.py                # Argparse CLI, table formatting, and exit code management
│   ├── accounting.py         # Cost accounting engine, 730h formula, budget evaluator, advisory suggestions
│   ├── pricing.py            # Azure Retail Prices API client, query builder, filters
│   ├── cache.py              # Embedded SQLite write-through pricing cache
│   ├── parser.py             # Terraform plan ingestion and multi-cloud attribute extractors
│   ├── models.py             # ResourceChange, PlanParseResult, ActionType
│   ├── web.py                # Phase 4/5 local HTTP server and serialization engine
│   └── __main__.py           # Module entrypoint (python -m costguard)
├── web/
│   ├── index.html            # FinOps web dashboard layout, summary cards, chart canvases, suggestions
│   ├── styles.css            # Professional dark-mode design system and responsive grid
│   └── app.js                # Client-side Chart.js rendering and dynamic API integration
├── tests/
│   ├── __init__.py
│   ├── test_smart_analysis.py# [Phase 5] Smart explanations, top contributors, suggestions, hostile inputs, demo scenarios
│   ├── test_web.py           # Phase 4 unit & integration tests for web server and API
│   ├── test_accounting.py    # Unit tests for cost calculations, deltas, budgets, exit codes
│   ├── test_pricing.py       # Azure API client, filtering, Spot/Low Priority, mock/live tests
│   ├── test_cache.py         # SQLite cache operations, normalization, metrics
│   ├── test_cli.py           # CLI flags, stdin piping, subprocess tests
│   ├── test_parser.py        # Actions, SKUs, regions, edge cases, hostile inputs
│   └── test_models.py        # Dataclass serialization and properties
├── sample_plans/
│   ├── 01_create.json        # [Demo 1] Multi-cloud creation plan (Azure VMs, AWS bastion, non-billable components)
│   ├── 02_delete.json        # [Demo 2] Resource teardown plan demonstrating negative monthly cost deltas
│   ├── 03_update_sku.json    # [Demo 3] SKU upgrade (+300%) & dev resource triggering advisory recommendations
│   ├── 04_mixed_hostile.json # [Demo 4] Hostile plan with missing fields, invalid types, and corrupted blocks
│   ├── 05_budget_fail.json   # [Demo 5] Plan exceeding $100 budget limit to demonstrate circuit breaker blocking
│   ├── create.json           # Baseline creation plan
│   ├── delete.json           # Baseline deletion plan
│   ├── update.json           # Baseline update plan
│   ├── replace.json          # Baseline replacement plan
│   ├── malformed.json        # Truncated / broken JSON syntax
│   ├── hostile.json          # Valid JSON with corrupted / missing fields
│   └── empty.json            # Empty plan with 0 resource changes
├── data/
│   ├── pricing_cache.db      # SQLite write-through cache database
│   └── README.md             # Data directory documentation
├── pyproject.toml            # PEP 517/518 build metadata & CLI entrypoint
├── setup.py                  # Setup script for editable installations
├── requirements.txt          # Python dependencies (pytest)
├── costguard.bat             # Windows CLI launcher script
├── .gitignore
├── README.md
└── REPORT.md
```

---

## Installation & Setup

CostGuard requires **Python 3.10+** and relies solely on Python's standard library for runtime operations.

```bash
# 1. Initialize environment
python -m venv .venv

# 2. Activate environment
# Windows PowerShell:
.\.venv\Scripts\Activate.ps1
# Linux / macOS:
source .venv/bin/activate

# 3. Install in editable mode
pip install -r requirements.txt
pip install -e .
```

---

## CLI Demo Commands

Execute all five realistic demo scenarios from PowerShell:

### Demo 1: Resource Creation (`01_create.json`)
```bash
python -m costguard --plan sample_plans/01_create.json
# Or using the launcher:
.\costguard.bat --plan sample_plans/01_create.json
```
*Output Summary:* Provisions 2 Azure VMs (`Standard_D2s_v5` and `Standard_D4s_v5`), skips non-billable VNet/Resource Group, adds `+$210.24/mo`, lists top contributors. Exit code: `0`.

### Demo 2: Resource Deletion (`02_delete.json`)
```bash
python -m costguard --plan sample_plans/02_delete.json
```
*Output Summary:* Decommissions 2 legacy VMs (`Standard_D4s_v5` and `Standard_B2s`), resulting in a negative monthly delta of `-$170.53/mo`. Exit code: `0`.

### Demo 3: SKU Upgrade & Advisory Optimization (`03_update_sku.json`)
```bash
python -m costguard --plan sample_plans/03_update_sku.json
```
*Output Summary:* Upgrades primary database from `Standard_D2s_v5` to `Standard_D8s_v5` (`+$210.24/mo`, `+300.0%`) and creates a development VM (`+$140.16/mo`). Generates conservative advisory recommendations for Significant SKU Upgrade and Non-Production Sizing. Exit code: `0`.

### Demo 4: Mixed Hostile & Edge Cases (`04_mixed_hostile.json`)
```bash
python -m costguard --plan sample_plans/04_mixed_hostile.json
```
*Output Summary:* Safely processes a plan containing corrupted entries, missing addresses, missing SKUs, missing locations, non-billable security groups, and unsupported services. Emits clear diagnostics, prices the 1 valid VM (`+$30.37/mo`), and never crashes with an unhandled traceback. Exit code: `0`.

### Demo 5: Budget Circuit Breaker Failure (`05_budget_fail.json`)
```bash
python -m costguard --plan sample_plans/05_budget_fail.json --max-increase 100
```
*Output Summary:* Projected increase is `+$210.24`, which exceeds the `--max-increase 100` budget limit. The circuit breaker triggers `✗ BUDGET CHECK: FAILED — Deployment BLOCKED` and terminates with exit code `1`.

---

## Web Dashboard Demo

Launch the local web visualization dashboard:

```bash
# Launch on port 5000
costguard --web --plan sample_plans/01_create.json --port 5000

# Or launch module directly
python -m costguard.web --port 5000
```

Open `http://127.0.0.1:5000` in your web browser.

The web UI provides:
- Live dynamic dropdown switching across all sample plans (`01_create.json` through `05_budget_fail.json`).
- **Interactive Action Selector** (`[ CREATE ] [ UPDATE ] [ DELETE ] [ REPLACE ] [ ALL ]`) with dynamic count badges (e.g. `CREATE (2)`).
- Action-sliced real-time filtering for summary cards, budget checks, charts, insights, and breakdown tables using Python as the single source of truth.
- Current monthly cost, projected monthly cost, and monthly delta.
- Circuit breaker banner with pass/fail states and budget progress bar.
- Interactive Chart.js visualizations (Cost Comparison and Top Cost Contributors).
- Explainable "Why Did Cost Change?" insights.
- Conservative Advisory Optimization Suggestions.
- Itemized resource table with % change and plain-English reasons.
- Skipped resources table with diagnostic reasons.
- Embedded SQLite cache and Azure Retail API telemetry.

---

## Running Tests

Run the complete test suite across all modules:

```bash
pytest -v
```

All 175 tests pass:
- Cost calculations (CREATE, DELETE, UPDATE, REPLACE)
- 730-hour monthly standard formula
- Positive and negative monthly deltas
- Non-billable resource skipping and reason logging
- Budget circuit breaker evaluation (PASS / FAIL)
- Exit code verification (`0`, `1`, `2`)
- Azure Retail Prices API client, query builder, and Spot/Low Priority filters
- SQLite write-through caching, hits, misses, and persistence
- Terraform execution plan ingestion, action normalizer, and edge cases
- Web application payload generation, accuracy, and precision
- Web HTTP server endpoints (`/`, `/styles.css`, `/app.js`, `/api/analysis`, `/api/plans`, `/api/analyze`, 404s)
- Action selector filtering (`ALL`, `CREATE`, `UPDATE`, `DELETE`, `REPLACE`) and badge counts
- Action-sliced budget guardrail preservation and single source of truth verification
- Smart cost explanations, itemized reasons, and percentage deltas
- Top cost contributors presentation sorting and value preservation
- Conservative advisory optimization suggestions (non-prod, upgrade, high capacity)
- Hostile / edge-case handling (missing fields, missing SKU/region, duplicate resources, malformed JSON)
- 5 demo scenarios validation across all action filters
