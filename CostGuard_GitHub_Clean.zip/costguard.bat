@echo off
if exist "%~dp0.venv\Scripts\python.exe" (
    "%~dp0.venv\Scripts\python.exe" -m costguard %*
) else (
    python -m costguard %*
)
exit /b %ERRORLEVEL%
