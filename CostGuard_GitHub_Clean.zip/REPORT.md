# CostGuard — Final Report

## 1. Problem Statement

Cloud infrastructure costs represent one of the fastest-growing operational expenses for modern engineering organizations. Traditional cloud cost governance (FinOps) suffers from a fundamental timing flaw: cost accounting occurs **post-facto**, typically via monthly billing summaries or retroactive cost dashboards days or weeks after infrastructure has already been provisioned and charges have accrued.

During code review and pull requests, developers and DevOps engineers frequently lack immediate visibility into the financial ramifications of their Terraform changes. A simple modification to an instance SKU, a provisioning loop, or an inadvertently deployed staging cluster can silently introduce thousands of dollars in recurring monthly commitments. Furthermore, existing CI/CD deployment pipelines lack automated policy guardrails capable of programmatically blocking deployments that violate departmental or project-level cost boundaries.

---

## 2. Solution Overview

**CostGuard** solves this problem by functioning as an automated **pre-deployment Terraform Cost Firewall**. CostGuard intercepts speculative Terraform execution plans in JSON format (e.g., from `terraform plan -out=tfplan && terraform show -json tfplan`), extracts planned infrastructure state transitions, queries the official Azure Retail Prices API with an embedded SQLite write-through cache, calculates exact monthly cost changes using the industry-standard 730-hour cloud month formula, and enforces strict budget circuit breakers.

CostGuard pairs a headless, scriptable CLI designed for automated CI/CD gating (with standardized exit codes `0`, `1`, and `2`) with a polished, zero-dependency local web dashboard that provides engineering and FinOps teams with transparent cost visualizations, itemized resource breakdowns, explainable cost change insights, and conservative advisory optimization recommendations.

---

## 3. What We Built

1. CostGuard is a standalone CLI tool and local web visualization engine that inspects speculative Terraform execution plans in JSON format to calculate projected infrastructure cost changes before deployment.
2. The system integrates directly with the official Azure Retail Prices API to obtain dynamic consumption rates without relying on hardcoded price tables.
3. An embedded SQLite write-through cache provides sub-millisecond local lookups, performance telemetry, and resilient offline operation.
4. The core accounting engine applies a standardized 730-hour monthly formula across CREATE, DELETE, UPDATE, and REPLACE actions, enforcing automated `--max-increase` budget circuit breakers with strict CI/CD exit codes.
5. A zero-dependency local web dashboard complements the CLI by delivering visual cost comparisons, top contributor rankings, plain-English cost change explanations, and conservative advisory recommendations.

---

## 4. Architecture

CostGuard is structured into seven modular, decoupled subsystems:

```
                         +-----------------------------------+
                         |    Terraform Speculative Plan     |
                         |           (JSON format)           |
                         +-----------------+-----------------+
                                           |
                                           v
                         +-----------------------------------+
                         |       Resource Extractor          |
                         |  (costguard/parser.py & models.py)|
                         +-----------------+-----------------+
                                           |
                                           v
                         +-----------------------------------+
                         |    Azure Retail Pricing Engine    |
                         |       (costguard/pricing.py)      |
                         +-----------------+-----------------+
                                           |
                                           v
                         +-----------------------------------+
                         |    SQLite Write-Through Cache     |
                         |        (costguard/cache.py)       |
                         +-----------------+-----------------+
                                           |
                                           v
                         +-----------------------------------+
                         |      Cost Accounting Engine       |
                         |    (costguard/accounting.py)      |
                         +--------+-----------------+--------+
                                  |                 |
                 +----------------+                 +----------------+
                 v                                                   v
+---------------------------------+               +----------------------------------+
|        Policy Guardrail         |               |     Local Web HTTP API Server    |
|   (CLI Exit Codes 0 / 1 / 2)    |               | (costguard/web.py - port 5000)   |
+----------------+----------------+               +-----------------+----------------+
                 |                                                  |
                 v                                                  v
+---------------------------------+               +----------------------------------+
|          Terminal UI            |               |          Web Dashboard           |
| (costguard/cli.py stdout/stderr)|               | (web/index.html, styles, app.js) |
+---------------------------------+               +----------------------------------+
```

### Resource Extractor (`costguard/parser.py`, `costguard/models.py`)
Parses speculative plan JSON, normalizes change actions (`CREATE`, `DELETE`, `UPDATE`, `REPLACE`), extracts multi-cloud SKU/size and region attributes, and emits structured diagnostic warnings for incomplete or hostile definitions without crashing.

### Azure Retail Pricing Engine (`costguard/pricing.py`)
Queries the official Azure Retail Prices API dynamically using OData `$filter` expressions, isolating standard Consumption pricing while strictly excluding Spot and Low Priority meters.

### SQLite Write-Through Cache (`costguard/cache.py`)
Embedded database (`data/pricing_cache.db`) that intercepts pricing requests, stores normalized records (`resource_type:sku:region`), provides offline resilience, and tracks cache hits, misses, and API calls.

### Cost Accounting Engine (`costguard/accounting.py`)
Applies the 730-hour standard monthly formula to calculate baseline cost, projected cost, and net monthly deltas per resource while preserving full floating-point precision for intermediate summations.

### Policy Guardrail (`costguard/accounting.py`, `costguard/cli.py`)
Evaluates net monthly increases against `--max-increase <amount>` thresholds, triggering automated circuit breaker blocks when budget limits are breached.

### Terminal UI (`costguard/cli.py`)
Renders clean, human-readable terminal tables with resource-level details, SKU transitions, top cost contributors, advisory recommendations, skipped non-billable components, and status banners. Supports `--json` for machine consumption.

### Web Dashboard (`costguard/web.py`, `web/`)
Zero-dependency HTTP server utilizing Python's standard `http.server.ThreadingHTTPServer` that serves a responsive, dark-mode FinOps interface featuring Chart.js visualizations, an interactive Action Selector (`[ CREATE ] [ UPDATE ] [ DELETE ] [ REPLACE ] [ ALL ]`) with dynamic count badges, real-time action-sliced cost filtering powered by Python as the single source of truth, API endpoints (`/api/analysis`, `/api/plans`, `/api/analyze`), and dynamic plan switching.

---

## 5. Resource Extraction Logic

CostGuard ingests Terraform execution plan JSON matching Terraform format specifications 1.x (generated via `terraform show -json <planfile>`). Ingestion supports both `--plan <filepath>` arguments and standard input pipes (e.g. `cat plan.json | costguard`).

The extraction pipeline performs the following steps:
1. **Action Normalization**: Terraform represents resource actions as lists (e.g. `["create"]`, `["delete"]`, `["update"]`, `["delete", "create"]`, or `["create", "delete"]`). CostGuard maps these into standardized `ActionType` enum values: `CREATE`, `DELETE`, `UPDATE`, and `REPLACE`.
2. **SKU & Size Extraction**: Inspects both `before` and `after` configuration states across cloud provider schemas:
   * **Azure**: `size`, `sku_name`, `sku`, `storage_account_type`, `pricing_tier`.
   * **AWS**: `instance_type`, `machine_type`.
   * **GCP**: `machine_type`, `tier`.
3. **Region & Location Extraction**: Normalizes geographical locations across provider schemas (`location`, `region`, `availability_zone`, `zone`).
4. **State Transition Mapping**: Preserves both prior state (`before_state`) and planned target state (`after_state`) for granular diffing.
5. **Non-Crash Diagnostic Logging**: Missing or corrupted blocks (e.g., missing address, omitted change block, undefined action) are assigned safe fallback identifiers and logged as actionable warnings rather than throwing unhandled exceptions.

---

## 6. Azure Pricing Method

CostGuard queries the official Microsoft Azure Retail Prices API endpoint:
`https://prices.azure.com/api/retail/prices`

Key characteristics of the pricing integration:
* **Zero Hardcoded Prices**: All unit prices are fetched dynamically from the official catalog.
* **Consumption Pricing Filter**: Explicitly filters for standard pay-as-you-go Consumption pricing using OData filter syntax:
  `priceType eq 'Consumption'`
* **Spot & Low Priority Exclusion**: To ensure accurate baseline budgeting, discounted, interruptible capacity is strictly filtered out:
  `not endswith(meterName, ' Spot') and not contains(meterName, 'Low Priority')`
* **Operating System Differentiation**: Correctly discriminates between Linux and Windows meter rates based on resource type and software licensing parameters.
* **Meter Disambiguation**: Cross-references meter names, unit of measure (`1 Hour`), and primary retail prices to ensure accurate unit price selection.

---

## 7. Cache Strategy

To prevent redundant network latency, eliminate API rate limits, and enable disconnected operation, CostGuard implements an embedded **SQLite write-through cache**:
* **Storage Location**: `data/pricing_cache.db`.
* **Primary Key Normalization**: Lookups use a sanitized key: `resource_type:sku:region` (e.g. `azurerm_linux_virtual_machine:standard_d4s_v5:eastus`), stripped of whitespace, casing, and hyphens.
* **Write-Through Pattern**:
  1. The pricing client checks the local SQLite table for an existing record.
  2. On a **Cache Hit**, the stored rate is returned immediately with sub-millisecond latency.
  3. On a **Cache Miss**, the client queries the live Azure API, parses the response, and atomically writes the price record to SQLite before returning.
* **Offline Resilience**: When `--offline` is specified or when remote connectivity fails, the engine falls back to cached prices safely.
* **Telemetry**: Tracks and exposes `cache_hits`, `cache_misses`, `api_calls`, and calculates hit ratio percentages in both CLI and Web UI.

---

## 8. Cost Calculation

### Standard 730-Hour Formula
Cloud infrastructure providers bill compute resources on an hourly rate. In accordance with the challenge specification, CostGuard calculates monthly cost using the industry-standard 730-hour average cloud month:
$$\text{monthly\_cost} = \text{hourly\_price} \times 730$$

### Action-Based Cost Rules
For every billable resource change, CostGuard applies strict cost rules:

* **CREATE**:
  $$\text{old\_cost} = \$0.00 \quad \mid \quad \text{new\_cost} = \text{unit\_price} \times 730 \quad \mid \quad \text{monthly\_delta} = +\text{new\_cost}$$
* **DELETE**:
  $$\text{old\_cost} = \text{unit\_price} \times 730 \quad \mid \quad \text{new\_cost} = \$0.00 \quad \mid \quad \text{monthly\_delta} = -\text{old\_cost}$$
* **UPDATE**:
  $$\text{old\_cost} = \text{old\_price} \times 730 \quad \mid \quad \text{new\_cost} = \text{new\_price} \times 730 \quad \mid \quad \text{monthly\_delta} = \text{new\_cost} - \text{old\_cost}$$
* **REPLACE**:
  $$\text{old\_cost} = \text{old\_price} \times 730 \quad \mid \quad \text{new\_cost} = \text{new\_price} \times 730 \quad \mid \quad \text{monthly\_delta} = \text{new\_cost} - \text{old\_cost}$$

### Positive and Negative Deltas
CostGuard natively handles both cost increases (positive deltas) and cost reductions (negative deltas). Total plan delta represents the exact algebraic sum:
$$\text{total\_delta} = \text{total\_new\_cost} - \text{total\_old\_cost} = \sum \text{monthly\_delta}_i$$

### Precision
Intermediate floating-point calculations remain unrounded throughout all summations. Standard currency formatting (`$XX.XX`) is applied exclusively at the final presentation boundary (CLI tables, JSON payloads, and UI cards).

### Non-Billable Components
Resources that do not carry retail meter charges (e.g. `random_pet`, `azurerm_resource_group`, `azurerm_virtual_network`, `azurerm_subnet`) are skipped gracefully with clear diagnostic messages and never cause engine crashes.

---

## 9. Budget Guardrail

CostGuard enforces automated financial policy through the `--max-increase <amount>` command-line option, acting as a programmable circuit breaker:

### Circuit Breaker Logic
* If $\text{total\_delta} \le \text{max\_increase}$: The budget check **PASSES**. Deployment is permitted.
* If $\text{total\_delta} > \text{max\_increase}$: The budget check **FAILS**. The deployment is blocked.

### Standardized Exit Codes
CostGuard communicates result status directly to CI/CD pipelines via POSIX-compliant exit codes:
* **`Exit Code 0` (SUCCESS)**: Plan parsed successfully, costs calculated, and budget check passed (or no `--max-increase` limit was set).
* **`Exit Code 1` (BUDGET BREACH)**: The projected monthly increase exceeded the configured `--max-increase` threshold. The deployment pipeline is halted.
* **`Exit Code 2` (INVALID CLI / INPUT)**: Fatal input error, such as a missing plan file, invalid JSON syntax, unreadable stdin, or negative budget argument.

---

## 10. Smart Analysis

### Cost Explanations
Every priced resource includes granular, contextual explanation attributes:
* Planned action (`CREATE`, `DELETE`, `UPDATE`, `REPLACE`).
* Prior SKU $\to$ Target SKU transition.
* Prior monthly cost $\to$ Target monthly cost.
* Signed monthly delta (`+$XX.XX/mo` or `-$XX.XX/mo`).
* Percentage change when meaningful (e.g. `+300.0%`, `-100.0%`, or `New`).
* Plain-English reason clarifying whether the delta stems from new provisioning, decommissioning, instance upgrading, downscaling, or an in-place modification.

### Top Cost Contributors
The accounting engine identifies and ranks the resources driving the largest positive monthly increases. Ranking is performed purely for presentation sorting, ensuring exact calculation precision is maintained across both the terminal report and web dashboard.

### Advisory Recommendations
CostGuard generates conservative, explainable sizing suggestions based on explicit evidence in resource addresses and tags:
1. **Non-Production Sizing**: Flags resources whose addresses or tags indicate development or staging (`dev`, `test`, `staging`, `qa`, `sandbox`) projected with 24/7 continuous runtime ($\ge \$50.00$/mo). Advises evaluating automated off-hours shutdown schedules (~250 hrs/mo) or burstable B-series instances.
2. **Significant SKU Upgrades**: Flags instance updates resulting in substantial jumps ($\ge \$70.00$/mo or $\ge +100\%$) to verify benchmark justification before deployment.
3. **High-Capacity Provisioning**: Highlights newly provisioned large instances ($\ge \$180.00$/mo) to evaluate Azure 1-Year or 3-Year Reservations / Savings Plans.
4. **Strict Advisory Standard**: All recommendations are explicitly marked as advisory suggestions requiring engineer validation. CostGuard never claims guaranteed savings, never invents alternative prices, and never mutates Terraform files.

---

## 11. Hostile Input Handling

CostGuard was built with defensive programming principles to guarantee that invalid or hostile input never results in an unhandled traceback or crash:
* **Malformed JSON**: Caught at the parser boundary; outputs a clean diagnostic error to stderr and exits safely with exit code 2.
* **Missing Resource Fields**: Missing `address`, `type`, `change`, `actions`, `before`, or `after` fields are substituted with safe defaults and flagged with descriptive warnings.
* **Missing SKU or Region**: Gracefully skipped in the accounting engine with clear diagnostic reasons (`"Missing SKU or region for create"`).
* **Unknown Resource Types**: Flagged with warnings and checked against the pricing engine without throwing exceptions.
* **Empty Plans**: Plans with zero changes report `$0.00` totals and clean summaries.
* **Duplicate Resources**: Processed deterministically without hash collisions or runtime crashes.
* **Invalid Actions**: Actions outside standard Terraform verbs map to `UNKNOWN` and are skipped safely.
* **Network & API Failure**: Network timeouts and HTTP errors degrade gracefully, logging warnings and falling back to cached SQLite entries.

---

## 12. Demo Results Matrix

All five demo scenarios were executed and verified against actual engine values:

| Plan | Scenario | Expected Cost Behavior | Verified Old Cost | Verified New Cost | Verified Monthly Delta | Budget Result | Exit Code |
|---|---|---|---|---|---|---|---|
| `01_create.json` | CREATE | Positive increase (2 Azure VMs, skips non-billable VNet/RG & AWS Bastion) | `$0.00` | `$210.24` | `+$210.24` | PASS (Unset) | `0` |
| `02_delete.json` | DELETE | Negative delta (Decommissions 2 legacy VMs) | `$170.53` | `$0.00` | `-$170.53` | PASS (Unset) | `0` |
| `03_update_sku.json` | UPDATE/REPLACE | Large positive increase (`Standard_D2s_v5` $\to$ `Standard_D8s_v5` `+300%` & dev VM) | `$70.08` | `$420.48` | `+$350.40` | PASS (Unset) | `0` |
| `04_mixed_hostile.json` | Hostile/edge input | Graceful handling (1 valid VM priced, 6 edge-case resources safely skipped, 8 warnings) | `$0.00` | `$30.37` | `+$30.37` | PASS (Unset) | `0` |
| `05_budget_fail.json` | Budget violation | Positive increase (`+$210.24`) strictly exceeds `--max-increase 100` | `$0.00` | `$210.24` | `+$210.24` | **FAILED / Blocked** | `1` |

---

## 13. Test Results

The CostGuard test suite was executed across all unit, integration, and scenario modules:

```text
============================= test session starts =============================
platform win32 -- Python 3.14.4, pytest-9.1.1, pluggy-1.6.0
rootdir: C:\Users\user\Desktop\IT Happens
configfile: pyproject.toml
testpaths: tests
collected 175 items

tests\test_accounting.py .................                               [  9%]
tests\test_action_filtering.py .......................................... [ 33%]
tests\test_cache.py .........                                            [ 38%]
tests\test_cli.py ....................                                   [ 50%]
tests\test_models.py .........                                           [ 55%]
tests\test_parser.py ............................                        [ 71%]
tests\test_pricing.py ............                                       [ 78%]
tests\test_smart_analysis.py ....................                        [ 89%]
tests\test_web.py ..................                                     [100%]

============================= 175 passed in 4.93s =============================
```

* **Total Tests**: `175`
* **Passed**: `175`
* **Failed**: `0`
* **Skipped**: `0`

---

## 14. Exact Run Commands

Execute the following commands from PowerShell using the project virtual environment directly:

### 1. Run Test Suite
```powershell
.\.venv\Scripts\python.exe -m pytest -q
```

### 2. Demo 1: Resource Creation
```powershell
.\.venv\Scripts\python.exe -m costguard --plan sample_plans/01_create.json
```

### 3. Demo 2: Resource Deletion (Negative Cost Delta)
```powershell
.\.venv\Scripts\python.exe -m costguard --plan sample_plans/02_delete.json
```

### 4. Demo 3: SKU Upgrade & Advisory Optimization
```powershell
.\.venv\Scripts\python.exe -m costguard --plan sample_plans/03_update_sku.json
```

### 5. Demo 4: Mixed Hostile & Edge Cases
```powershell
.\.venv\Scripts\python.exe -m costguard --plan sample_plans/04_mixed_hostile.json
```

### 6. Demo 5: Budget Circuit Breaker Failure
```powershell
.\.venv\Scripts\python.exe -m costguard --plan sample_plans/05_budget_fail.json --max-increase 100
```

### 7. Launch Local Web Dashboard
```powershell
.\.venv\Scripts\python.exe -m costguard --web --plan sample_plans/01_create.json --port 5000
```
Open **`http://127.0.0.1:5000`** in your web browser.

---

## 15. Limitations

CostGuard's current implementation operates under specific, intentional boundaries:
1. **Azure Retail Pricing Focus**: Live price lookups and SQLite caching are currently implemented for Microsoft Azure Consumption meters (primarily Virtual Machines). While the parser recognizes and extracts AWS and GCP resources, they are skipped with explicit diagnostic logging because other cloud providers' pricing engines are not yet configured.
2. **Pre-Rendered Plan JSON Requirement**: CostGuard requires Terraform execution plans rendered to JSON format (`terraform show -json tfplan`). It does not parse raw, uncompiled `.tf` files or evaluate dynamic Terragrunt runtime expressions directly.
3. **Advisory Scope**: Optimization recommendations are strictly advisory and require engineer validation. CostGuard does not automatically refactor or mutate Terraform code files.
4. **Consumption Metering Model**: Cost calculations focus on hourly compute instance rates assuming standard continuous monthly runtime (730 hours). Dynamic variable usage (e.g. storage IOPS, network egress bytes) is not modeled without historical telemetry.

---

## 16. Future Scope

* **Multi-Cloud Pricing Expansion**: Add native pricing clients for the AWS Price List API and the Google Cloud Billing Catalog API.
* **CI/CD Pull Request Bots**: Implement automated pull request commenting and status checks for GitHub Actions, GitLab CI, and Azure Pipelines.
* **Telemetry-Driven Variable Modeling**: Ingest cloud monitoring metrics (e.g. Azure Monitor, CloudWatch) to model burstable workloads and fluctuating bandwidth usage.
* **Multi-Currency Support**: Expand currency conversion beyond USD utilizing official multi-currency rate tables.

---

## 17. Conclusion

CostGuard successfully bridges the critical gap between Terraform infrastructure-as-code authoring and proactive cloud financial governance. By shifting FinOps left directly into the pull request and deployment pipeline, CostGuard prevents accidental over-provisioning, enforces departmental budget boundaries, and provides engineering teams with transparent, explainable financial feedback before a single dollar is spent.
