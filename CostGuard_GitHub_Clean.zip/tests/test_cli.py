"""
Tests for CostGuard CLI (costguard.cli)
Verifies command-line options, stdin piping, error handling, and output formats.
"""

import io
import json
import subprocess
import sys
from pathlib import Path

import pytest

from costguard.cli import build_parser, run_cli

SAMPLE_PLANS_DIR = Path(__file__).parent.parent / "sample_plans"


class TestCLIStartupAndHelp:
    def test_cli_parser_builds(self):
        parser = build_parser()
        assert parser.prog == "costguard"

    def test_cli_help(self, capsys):
        with pytest.raises(SystemExit) as exc:
            run_cli(["--help"])
        assert exc.value.code == 0
        captured = capsys.readouterr()
        assert "CostGuard receives a Terraform speculative execution plan" in captured.out
        assert "--plan" in captured.out
        assert "--json" in captured.out

    def test_cli_startup_no_args_non_interactive(self, monkeypatch, capsys):
        # Simulate tty with no args: should display help and exit code 1 or 2
        monkeypatch.setattr(sys.stdin, "isatty", lambda: True)
        exit_code = run_cli([])
        assert exit_code in (1, 2)
        captured = capsys.readouterr()
        assert "No input plan provided" in captured.err

    def test_cli_version(self, capsys):
        from costguard.cli import __version__
        with pytest.raises(SystemExit) as exc:
            run_cli(["--version"])
        assert exc.value.code == 0
        captured = capsys.readouterr()
        assert f"costguard {__version__}" in captured.out or f"costguard {__version__}" in captured.err


class TestCLIPlanFlag:
    def test_cli_plan_create(self, capsys):
        plan_path = str(SAMPLE_PLANS_DIR / "create.json")
        exit_code = run_cli(["--plan", plan_path])
        assert exit_code == 0
        captured = capsys.readouterr()
        assert "CostGuard (Phase 1)" in captured.out
        assert "CREATE: 4" in captured.out
        assert "aws_instance.web_server" in captured.out
        assert "t3.xlarge" in captured.out

    def test_cli_plan_delete(self, capsys):
        plan_path = str(SAMPLE_PLANS_DIR / "delete.json")
        exit_code = run_cli(["--plan", plan_path])
        assert exit_code == 0
        captured = capsys.readouterr()
        assert "DELETE: 3" in captured.out
        assert "aws_instance.legacy_bastion" in captured.out

    def test_cli_plan_update(self, capsys):
        plan_path = str(SAMPLE_PLANS_DIR / "update.json")
        exit_code = run_cli(["--plan", plan_path])
        assert exit_code == 0
        captured = capsys.readouterr()
        assert "UPDATE: 3" in captured.out
        assert "aws_instance.worker_node" in captured.out
        assert "t3.medium -> c6i.2xlarge" in captured.out

    def test_cli_plan_replace(self, capsys):
        plan_path = str(SAMPLE_PLANS_DIR / "replace.json")
        exit_code = run_cli(["--plan", plan_path])
        assert exit_code == 0
        captured = capsys.readouterr()
        assert "REPLACE: 3" in captured.out
        assert "aws_instance.bastion_host" in captured.out

    def test_cli_plan_json_output(self, capsys):
        plan_path = str(SAMPLE_PLANS_DIR / "create.json")
        exit_code = run_cli(["--plan", plan_path, "--json"])
        assert exit_code == 0
        captured = capsys.readouterr()
        parsed = json.loads(captured.out)
        assert parsed["summary"]["create"] == 4
        assert len(parsed["resource_changes"]) == 4
        assert parsed["resource_changes"][0]["address"] == "aws_instance.web_server"

    def test_cli_verbose_mode(self, capsys):
        plan_path = str(SAMPLE_PLANS_DIR / "create.json")
        exit_code = run_cli(["--plan", plan_path, "-v"])
        assert exit_code == 0
        captured = capsys.readouterr()
        assert "After  :" in captured.out


class TestCLIStdin:
    def test_cli_stdin_pipe(self, monkeypatch, capsys):
        plan_path = SAMPLE_PLANS_DIR / "create.json"
        content = plan_path.read_text(encoding="utf-8")
        monkeypatch.setattr(sys.stdin, "isatty", lambda: False)
        monkeypatch.setattr(sys.stdin, "read", lambda: content)

        exit_code = run_cli([])
        assert exit_code == 0
        captured = capsys.readouterr()
        assert "CREATE: 4" in captured.out
        assert "aws_instance.web_server" in captured.out

    def test_cli_stdin_pipe_json_flag(self, monkeypatch, capsys):
        plan_path = SAMPLE_PLANS_DIR / "update.json"
        content = plan_path.read_text(encoding="utf-8")
        monkeypatch.setattr(sys.stdin, "isatty", lambda: False)
        monkeypatch.setattr(sys.stdin, "read", lambda: content)

        exit_code = run_cli(["--json"])
        assert exit_code == 0
        captured = capsys.readouterr()
        parsed = json.loads(captured.out)
        assert parsed["summary"]["update"] == 3


class TestCLIErrorHandling:
    def test_cli_file_not_found(self, capsys):
        exit_code = run_cli(["--plan", "does_not_exist.json"])
        assert exit_code in (1, 2)
        captured = capsys.readouterr()
        assert "Plan file not found" in captured.err

    def test_cli_malformed_json_file(self, capsys):
        plan_path = str(SAMPLE_PLANS_DIR / "malformed.json")
        exit_code = run_cli(["--plan", plan_path])
        assert exit_code in (1, 2)
        captured = capsys.readouterr()
        assert "CostGuard Parse Error" in captured.err
        assert "Invalid JSON format" in captured.err

    def test_cli_malformed_json_stdin(self, monkeypatch, capsys):
        monkeypatch.setattr(sys.stdin, "isatty", lambda: False)
        monkeypatch.setattr(sys.stdin, "read", lambda: "{invalid json")

        exit_code = run_cli([])
        assert exit_code in (1, 2)
        captured = capsys.readouterr()
        assert "CostGuard Parse Error" in captured.err

    def test_cli_empty_plan(self, capsys):
        plan_path = str(SAMPLE_PLANS_DIR / "empty.json")
        exit_code = run_cli(["--plan", plan_path])
        # Empty plan has 0 changes, parses cleanly with empty warning
        assert exit_code == 0
        captured = capsys.readouterr()
        assert "Total Changes: 0" in captured.out
        assert "No resource changes detected in plan" in captured.out

    def test_cli_hostile_plan(self, capsys):
        plan_path = str(SAMPLE_PLANS_DIR / "hostile.json")
        exit_code = run_cli(["--plan", plan_path])
        # Hostile plan has valid JSON with corrupt fields; must not crash!
        assert exit_code == 0
        captured = capsys.readouterr()
        assert "Total Changes: 5" in captured.out
        assert "Warnings (8)" in captured.out or "Warnings" in captured.out


class TestCLISubprocessExecution:
    """Verifies standalone invocation of the installed CLI binary and python -m costguard."""

    def test_module_execution_with_plan(self):
        plan_path = str(SAMPLE_PLANS_DIR / "create.json")
        cmd = [sys.executable, "-m", "costguard", "--plan", plan_path]
        res = subprocess.run(cmd, capture_output=True, text=True)
        assert res.returncode == 0
        assert "Total Changes: 4" in res.stdout
        assert "CREATE: 4" in res.stdout

    def test_module_execution_help(self):
        cmd = [sys.executable, "-m", "costguard", "--help"]
        res = subprocess.run(cmd, capture_output=True, text=True)
        assert res.returncode == 0
        assert "usage: costguard" in res.stdout

    def test_module_execution_stdin(self):
        plan_path = str(SAMPLE_PLANS_DIR / "delete.json")
        with open(plan_path, "r", encoding="utf-8") as f:
            content = f.read()

        cmd = [sys.executable, "-m", "costguard"]
        res = subprocess.run(cmd, input=content, capture_output=True, text=True)
        assert res.returncode == 0
        assert "DELETE: 3" in res.stdout
