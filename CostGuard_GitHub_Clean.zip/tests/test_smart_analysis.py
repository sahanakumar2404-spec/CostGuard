"""
Tests for CostGuard Phase 5: Smart Analysis & Demo Scenarios.
Verifies smart cost explanations, top cost contributors, conservative
advisory optimization suggestions, hostile/edge input handling, and demo plans.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from costguard.accounting import (
    CostAccountingEngine,
    CostAnalysisReport,
    OptimizationSuggestion,
    ResourceCostChange,
    SkippedResource,
    format_cost_table,
)
from costguard.cache import SQLitePricingCache
from costguard.cli import run_cli
from costguard.models import ActionType, PlanParseResult, ResourceChange
from costguard.parser import parse_plan_file, parse_plan_json
from costguard.pricing import AzurePricingClient
from costguard.web import generate_analysis_payload

SAMPLE_PLANS_DIR = Path(__file__).parent.parent / "sample_plans"


@pytest.fixture
def isolated_pricing_client():
    cache = SQLitePricingCache(db_path=":memory:")
    # Preload standard benchmark rates
    cache.set("azurerm_linux_virtual_machine", "Standard_B1s", "eastus", 0.0104)
    cache.set("azurerm_linux_virtual_machine", "Standard_B2s", "eastus", 0.0416)
    cache.set("azurerm_linux_virtual_machine", "Standard_D2s_v5", "eastus", 0.096)
    cache.set("azurerm_linux_virtual_machine", "Standard_D4s_v5", "eastus", 0.192)
    cache.set("azurerm_linux_virtual_machine", "Standard_D8s_v5", "eastus", 0.384)
    return AzurePricingClient(cache=cache, offline=True)


@pytest.fixture
def smart_engine(isolated_pricing_client):
    return CostAccountingEngine(pricing_client=isolated_pricing_client)


class TestSmartCostExplanation:
    """Verifies itemized explanations, percentages, and reasons for all change actions."""

    def test_create_explanation_and_reason(self, smart_engine):
        rc = ResourceChange(
            address="azurerm_linux_virtual_machine.web",
            resource_type="azurerm_linux_virtual_machine",
            action=ActionType.CREATE,
            new_sku="Standard_D4s_v5",
            new_region="eastus",
        )
        item = smart_engine.calculate_resource_cost(rc)
        assert isinstance(item, ResourceCostChange)
        assert item.action == "CREATE"
        assert item.old_monthly_cost == 0.0
        assert item.new_monthly_cost == 140.16
        assert item.monthly_delta == 140.16
        assert item.percentage_change is None
        assert "Newly provisioned" in item.reason
        assert "Standard_D4s_v5" in item.reason
        assert "eastus" in item.reason
        assert "Reason: Newly provisioned infrastructure" in item.explanation

    def test_delete_explanation_and_reason(self, smart_engine):
        rc = ResourceChange(
            address="azurerm_linux_virtual_machine.old_db",
            resource_type="azurerm_linux_virtual_machine",
            action=ActionType.DELETE,
            old_sku="Standard_D4s_v5",
            old_region="eastus",
        )
        item = smart_engine.calculate_resource_cost(rc)
        assert isinstance(item, ResourceCostChange)
        assert item.action == "DELETE"
        assert item.old_monthly_cost == 140.16
        assert item.new_monthly_cost == 0.0
        assert item.monthly_delta == -140.16
        assert item.percentage_change == -100.0
        assert "Decommissioned" in item.reason
        assert "Reason: Resource decommissioned" in item.explanation

    def test_update_upgrade_explanation_and_percent(self, smart_engine):
        rc = ResourceChange(
            address="azurerm_linux_virtual_machine.app",
            resource_type="azurerm_linux_virtual_machine",
            action=ActionType.UPDATE,
            old_sku="Standard_D2s_v5",
            new_sku="Standard_D8s_v5",
            old_region="eastus",
            new_region="eastus",
        )
        item = smart_engine.calculate_resource_cost(rc)
        assert isinstance(item, ResourceCostChange)
        assert item.action == "UPDATE"
        assert item.old_monthly_cost == 70.08
        assert item.new_monthly_cost == 280.32
        assert item.monthly_delta == 210.24
        assert item.percentage_change == 300.0
        assert "Upgraded SKU" in item.reason
        assert "+300.0%" in item.reason
        assert "Reason: Instance capacity upgraded" in item.explanation

    def test_update_downgrade_explanation_and_percent(self, smart_engine):
        rc = ResourceChange(
            address="azurerm_linux_virtual_machine.app",
            resource_type="azurerm_linux_virtual_machine",
            action=ActionType.UPDATE,
            old_sku="Standard_D8s_v5",
            new_sku="Standard_D2s_v5",
            old_region="eastus",
            new_region="eastus",
        )
        item = smart_engine.calculate_resource_cost(rc)
        assert isinstance(item, ResourceCostChange)
        assert item.action == "UPDATE"
        assert item.old_monthly_cost == 280.32
        assert item.new_monthly_cost == 70.08
        assert item.monthly_delta == -210.24
        assert item.percentage_change == -75.0
        assert "Downgraded SKU" in item.reason
        assert "-75.0%" in item.reason
        assert "Reason: Instance capacity downscaled" in item.explanation

    def test_update_unchanged_sku_reason(self, smart_engine):
        rc = ResourceChange(
            address="azurerm_linux_virtual_machine.app",
            resource_type="azurerm_linux_virtual_machine",
            action=ActionType.UPDATE,
            old_sku="Standard_D2s_v5",
            new_sku="Standard_D2s_v5",
            old_region="eastus",
            new_region="eastus",
        )
        item = smart_engine.calculate_resource_cost(rc)
        assert isinstance(item, ResourceCostChange)
        assert item.monthly_delta == 0.0
        assert "unchanged" in item.reason.lower()


class TestTopCostContributors:
    """Verifies identification and presentation sorting of top positive cost contributors."""

    def test_top_contributors_sorted_descending(self, smart_engine):
        changes = [
            ResourceChange("vm_small", "azurerm_linux_virtual_machine", ActionType.CREATE, new_sku="Standard_B1s", new_region="eastus"),
            ResourceChange("vm_large", "azurerm_linux_virtual_machine", ActionType.CREATE, new_sku="Standard_D8s_v5", new_region="eastus"),
            ResourceChange("vm_medium", "azurerm_linux_virtual_machine", ActionType.CREATE, new_sku="Standard_D4s_v5", new_region="eastus"),
            ResourceChange("vm_deleted", "azurerm_linux_virtual_machine", ActionType.DELETE, old_sku="Standard_D4s_v5", old_region="eastus"),
        ]
        plan_result = PlanParseResult(resource_changes=changes)
        report = smart_engine.analyze_plan(plan_result)

        assert len(report.top_contributors) == 3
        # First must be the largest increase
        assert report.top_contributors[0].address == "vm_large"
        assert report.top_contributors[0].monthly_delta == 280.32
        # Second must be the medium increase
        assert report.top_contributors[1].address == "vm_medium"
        assert report.top_contributors[1].monthly_delta == 140.16
        # Third must be the smallest increase
        assert report.top_contributors[2].address == "vm_small"
        # Negative delta (deleted VM) must NOT be in positive top contributors
        assert not any(c.address == "vm_deleted" for c in report.top_contributors)


class TestOptimizationSuggestions:
    """Verifies conservative advisory recommendations without hardcoded or invented prices."""

    def test_non_production_by_address_name(self, smart_engine):
        changes = [
            ResourceChange(
                "azurerm_linux_virtual_machine.dev_test_runner",
                "azurerm_linux_virtual_machine",
                ActionType.CREATE,
                new_sku="Standard_D4s_v5",
                new_region="eastus",
            ),
        ]
        plan_result = PlanParseResult(resource_changes=changes)
        report = smart_engine.analyze_plan(plan_result)

        assert len(report.optimization_suggestions) >= 1
        sug = next(s for s in report.optimization_suggestions if s.category == "Non-Production Sizing")
        assert "Non-Production Sizing" in sug.category
        assert "dev_test_runner" in sug.resource_address
        assert "Advisory recommendation only" in sug.advisory_notice

    def test_non_production_by_tags(self, smart_engine):
        rc = ResourceChange(
            address="azurerm_linux_virtual_machine.analytics_worker",
            resource_type="azurerm_linux_virtual_machine",
            action=ActionType.CREATE,
            new_sku="Standard_D4s_v5",
            new_region="eastus",
            after_state={"tags": {"environment": "staging", "tier": "backend"}},
        )
        plan_result = PlanParseResult(resource_changes=[rc])
        report = smart_engine.analyze_plan(plan_result)

        assert any(s.category == "Non-Production Sizing" for s in report.optimization_suggestions)

    def test_significant_sku_upgrade_advisory(self, smart_engine):
        rc = ResourceChange(
            address="azurerm_linux_virtual_machine.prod_db",
            resource_type="azurerm_linux_virtual_machine",
            action=ActionType.UPDATE,
            old_sku="Standard_D2s_v5",
            new_sku="Standard_D8s_v5",
            old_region="eastus",
            new_region="eastus",
        )
        plan_result = PlanParseResult(resource_changes=[rc])
        report = smart_engine.analyze_plan(plan_result)

        assert any(s.category == "Significant SKU Upgrade" for s in report.optimization_suggestions)
        sug = next(s for s in report.optimization_suggestions if s.category == "Significant SKU Upgrade")
        assert "benchmarks" in sug.description.lower()
        assert "Advisory recommendation only" in sug.advisory_notice

    def test_high_capacity_provisioning_advisory(self, smart_engine):
        rc = ResourceChange(
            address="azurerm_linux_virtual_machine.heavy_compute",
            resource_type="azurerm_linux_virtual_machine",
            action=ActionType.CREATE,
            new_sku="Standard_D8s_v5",
            new_region="eastus",
        )
        plan_result = PlanParseResult(resource_changes=[rc])
        report = smart_engine.analyze_plan(plan_result)

        assert any(s.category == "High-Capacity Provisioning" for s in report.optimization_suggestions)


class TestHostileAndEdgeInputHandling:
    """Verifies robust, fail-safe operation on malformed, incomplete, and edge-case inputs."""

    def test_duplicate_resources_handled_safely(self, smart_engine):
        changes = [
            ResourceChange("vm1", "azurerm_linux_virtual_machine", ActionType.CREATE, new_sku="Standard_B1s", new_region="eastus"),
            ResourceChange("vm1", "azurerm_linux_virtual_machine", ActionType.CREATE, new_sku="Standard_B1s", new_region="eastus"),
        ]
        plan_result = PlanParseResult(resource_changes=changes)
        report = smart_engine.analyze_plan(plan_result)
        assert len(report.cost_changes) == 2
        assert report.total_new_cost > 0

    def test_missing_pricing_results_handled_gracefully(self, smart_engine):
        rc = ResourceChange(
            address="azurerm_linux_virtual_machine.obscure",
            resource_type="azurerm_linux_virtual_machine",
            action=ActionType.CREATE,
            new_sku="NonExistentSKU_XYZ",
            new_region="eastus",
        )
        item = smart_engine.calculate_resource_cost(rc)
        assert isinstance(item, SkippedResource)
        assert "Pricing unavailable" in item.reason

    def test_invalid_action_handled_gracefully(self, smart_engine):
        rc = ResourceChange(
            address="azurerm_linux_virtual_machine.weird",
            resource_type="azurerm_linux_virtual_machine",
            action=ActionType.UNKNOWN,
            new_sku="Standard_B1s",
            new_region="eastus",
        )
        item = smart_engine.calculate_resource_cost(rc)
        assert isinstance(item, SkippedResource)
        assert "does not impact cloud bill" in item.reason

    def test_api_failure_fallback_to_cache(self):
        cache = SQLitePricingCache(db_path=":memory:")
        cache.set("azurerm_linux_virtual_machine", "Standard_D2s_v5", "eastus", 0.096)
        # Client pointing to bad endpoint with cache fallback
        client = AzurePricingClient(base_url="http://invalid.domain.12345/retail", cache=cache, timeout=0.5)
        p = client.get_price("azurerm_linux_virtual_machine", "Standard_D2s_v5", "eastus")
        assert p is not None
        assert p.price == 0.096
        assert p.source == "cache"

    def test_malformed_json_cli_never_crashes(self, capsys):
        exit_code = run_cli(["--plan", str(SAMPLE_PLANS_DIR / "malformed.json")])
        assert exit_code in (1, 2)
        captured = capsys.readouterr()
        assert "CostGuard Parse Error" in captured.err
        assert "Invalid JSON format" in captured.err


class TestDemoScenariosExecution:
    """Verifies that all 5 required demo plans execute accurately."""

    def test_demo_01_create(self):
        plan_path = str(SAMPLE_PLANS_DIR / "01_create.json")
        payload = generate_analysis_payload(plan_path, offline=True)
        assert payload["status"] == "success"
        assert payload["summary"]["total_old_cost"] == 0.0
        assert payload["summary"]["total_new_cost"] == 210.24
        assert payload["summary"]["total_delta"] == 210.24
        assert len(payload["top_contributors"]) == 2
        assert len(payload["skipped_resources"]) == 3

    def test_demo_02_delete(self):
        plan_path = str(SAMPLE_PLANS_DIR / "02_delete.json")
        payload = generate_analysis_payload(plan_path, offline=True)
        assert payload["status"] == "success"
        assert payload["summary"]["total_old_cost"] == 170.53
        assert payload["summary"]["total_new_cost"] == 0.0
        assert payload["summary"]["total_delta"] == -170.53
        assert len(payload["top_contributors"]) == 0
        assert len(payload["skipped_resources"]) == 1

    def test_demo_03_update_sku(self):
        plan_path = str(SAMPLE_PLANS_DIR / "03_update_sku.json")
        payload = generate_analysis_payload(plan_path, offline=True)
        assert payload["status"] == "success"
        assert payload["summary"]["total_old_cost"] == 70.08
        assert payload["summary"]["total_new_cost"] == 420.48
        assert payload["summary"]["total_delta"] == 350.40
        assert len(payload["optimization_suggestions"]) >= 2
        # Check suggestions
        categories = [s["category"] for s in payload["optimization_suggestions"]]
        assert "Significant SKU Upgrade" in categories
        assert "Non-Production Sizing" in categories

    def test_demo_04_mixed_hostile(self):
        plan_path = str(SAMPLE_PLANS_DIR / "04_mixed_hostile.json")
        payload = generate_analysis_payload(plan_path, offline=True)
        assert payload["status"] == "success"
        assert payload["summary"]["billable_count"] == 1
        assert payload["summary"]["skipped_count"] == 6
        assert payload["summary"]["total_delta"] == 30.37

    def test_demo_05_budget_fail(self):
        plan_path = str(SAMPLE_PLANS_DIR / "05_budget_fail.json")
        payload = generate_analysis_payload(plan_path, max_increase=100.0, offline=True)
        assert payload["status"] == "success"
        assert payload["budget"]["passed"] is False
        assert payload["budget"]["status"] == "FAILED"
        assert payload["summary"]["total_delta"] == 210.24
        assert payload["budget"]["remaining_budget"] < 0
