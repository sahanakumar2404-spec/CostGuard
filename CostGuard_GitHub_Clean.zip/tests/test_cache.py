"""
Tests for CostGuard SQLite Pricing Cache (costguard.cache)
"""

import sqlite3
from pathlib import Path

import pytest

from costguard.cache import CachedPrice, SQLitePricingCache


class TestSQLitePricingCache:
    def test_cache_initialization_in_memory(self):
        cache = SQLitePricingCache(db_path=":memory:")
        assert cache.hits == 0
        assert cache.misses == 0
        assert cache.api_calls == 0

    def test_normalize_key(self):
        key = SQLitePricingCache.normalize_key(
            "azurerm_linux_virtual_machine",
            "Standard_D4s_v5",
            "East US",
        )
        assert key == "azurerm_linux_virtual_machine:standard_d4s_v5:eastus"

        key2 = SQLitePricingCache.normalize_key(
            "azurerm_virtual_machine",
            "Standard_B1s",
            "West Europe",
        )
        assert key2 == "azurerm_virtual_machine:standard_b1s:westeurope"

    def test_cache_miss_initially(self):
        cache = SQLitePricingCache(db_path=":memory:")
        res = cache.get("azurerm_linux_virtual_machine", "Standard_D4s_v5", "eastus")
        assert res is None
        assert cache.misses == 1
        assert cache.hits == 0

    def test_cache_write_and_hit(self):
        cache = SQLitePricingCache(db_path=":memory:")
        # Write
        saved = cache.set(
            resource_type="azurerm_linux_virtual_machine",
            sku="Standard_D4s_v5",
            region="eastus",
            price=0.192,
            currency="USD",
            metadata={"unit_of_measure": "1 Hour", "product_name": "Virtual Machines Dsv5 Series"},
        )
        assert saved.price == 0.192
        assert saved.currency == "USD"
        assert saved.retrieved_at is not None

        # Check has()
        assert cache.has("azurerm_linux_virtual_machine", "Standard_D4s_v5", "eastus") is True
        assert cache.has("azurerm_linux_virtual_machine", "NonExistent", "eastus") is False

        # Read (Hit)
        cached = cache.get("azurerm_linux_virtual_machine", "Standard_D4s_v5", "eastus")
        assert cached is not None
        assert cached.price == 0.192
        assert cached.sku == "Standard_D4s_v5"
        assert cached.region == "eastus"
        assert cached.metadata["unit_of_measure"] == "1 Hour"
        assert cache.hits == 1
        assert cache.misses == 0

    def test_cache_required_fields(self):
        cache = SQLitePricingCache(db_path=":memory:")
        cache.set(
            resource_type="azurerm_managed_disk",
            sku="Premium_LRS",
            region="westeurope",
            price=19.71,
            currency="USD",
            metadata={"disk_size": "128GB"},
        )
        entry = cache.get("azurerm_managed_disk", "Premium_LRS", "westeurope")
        assert entry is not None
        assert hasattr(entry, "resource_type")
        assert hasattr(entry, "sku")
        assert hasattr(entry, "region")
        assert hasattr(entry, "price")
        assert hasattr(entry, "currency")
        assert hasattr(entry, "retrieved_at")
        assert hasattr(entry, "metadata")
        assert entry.metadata["disk_size"] == "128GB"

    def test_monthly_price_calculation(self):
        hourly_item = CachedPrice(
            resource_type="azurerm_linux_virtual_machine",
            sku="Standard_B2s",
            region="eastus",
            price=0.0416,
            metadata={"unit_of_measure": "1 Hour"},
        )
        # 0.0416 * 730 = 30.368
        assert round(hourly_item.monthly_price, 2) == 30.37

        monthly_item = CachedPrice(
            resource_type="azurerm_managed_disk",
            sku="P10",
            region="eastus",
            price=19.71,
            metadata={"unit_of_measure": "1/Month"},
        )
        assert monthly_item.monthly_price == 19.71

    def test_cache_replace(self):
        cache = SQLitePricingCache(db_path=":memory:")
        cache.set("azurerm_linux_virtual_machine", "Standard_B1s", "eastus", 0.012)
        assert cache.get("azurerm_linux_virtual_machine", "Standard_B1s", "eastus").price == 0.012

        # Update price
        cache.set("azurerm_linux_virtual_machine", "Standard_B1s", "eastus", 0.014)
        assert cache.get("azurerm_linux_virtual_machine", "Standard_B1s", "eastus").price == 0.014

    def test_cache_clear(self):
        cache = SQLitePricingCache(db_path=":memory:")
        cache.set("azurerm_linux_virtual_machine", "Standard_B1s", "eastus", 0.012)
        cache.get("azurerm_linux_virtual_machine", "Standard_B1s", "eastus")
        assert cache.hits == 1

        cache.clear()
        assert cache.hits == 0
        assert cache.misses == 0
        assert cache.has("azurerm_linux_virtual_machine", "Standard_B1s", "eastus") is False

    def test_cache_stats(self):
        cache = SQLitePricingCache(db_path=":memory:")
        cache.get("type", "sku", "reg")  # miss
        cache.set("type", "sku", "reg", 1.0)
        cache.get("type", "sku", "reg")  # hit
        cache.api_calls += 1

        stats = cache.stats()
        assert stats["cache_hits"] == 1
        assert stats["cache_misses"] == 1
        assert stats["api_calls"] == 1
