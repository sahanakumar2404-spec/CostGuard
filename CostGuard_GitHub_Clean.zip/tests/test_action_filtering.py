"""
Tests for CostGuard Action Filtering in Web Dashboard.
Verifies the Action Selector ([ CREATE ] [ UPDATE ] [ DELETE ] [ REPLACE ] [ ALL ]),
single-source-of-truth calculations in Python, delta summations, action counts,
budget guardrail preservation, explainable insights, and live HTTP API endpoints.
"""

from __future__ import annotations

import json
import threading
import time
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

import pytest

from costguard.cache import SQLitePricingCache
from costguard.pricing import AzurePricingClient
from costguard.web import (
    create_server,
    generate_analysis_payload,
    SAMPLE_PLANS_DIR,
)


@pytest.fixture
def create_plan_path() -> str:
    return str(SAMPLE_PLANS_DIR / "01_create.json")


@pytest.fixture
def delete_plan_path() -> str:
    return str(SAMPLE_PLANS_DIR / "02_delete.json")


@pytest.fixture
def update_sku_plan_path() -> str:
    return str(SAMPLE_PLANS_DIR / "03_update_sku.json")


@pytest.fixture
def mixed_hostile_plan_path() -> str:
    return str(SAMPLE_PLANS_DIR / "04_mixed_hostile.json")


@pytest.fixture
def empty_plan_path() -> str:
    return str(SAMPLE_PLANS_DIR / "empty.json")


class TestActionFilteringPayload:
    """Verifies Python-calculated payloads with action filters."""

    def test_default_action_is_all(self, update_sku_plan_path: str):
        payload = generate_analysis_payload(update_sku_plan_path, offline=True)
        assert payload["selected_action"] == "ALL"
        assert "action_counts" in payload
        counts = payload["action_counts"]
        assert counts["ALL"] >= 3
        assert counts["CREATE"] >= 1
        assert counts["UPDATE"] >= 2
        assert counts["DELETE"] == 0

    def test_explicit_all_action(self, update_sku_plan_path: str):
        payload = generate_analysis_payload(update_sku_plan_path, action="ALL", offline=True)
        assert payload["selected_action"] == "ALL"
        summary = payload["summary"]
        assert summary["billable_count"] == 2
        assert summary["skipped_count"] == 1
        assert summary["total_changes"] == 3

    def test_filter_create_action(self, update_sku_plan_path: str):
        # 03_update_sku.json has 1 CREATE (vm-analytics-dev-01) and 2 UPDATE
        payload = generate_analysis_payload(update_sku_plan_path, action="CREATE", offline=True)
        assert payload["selected_action"] == "CREATE"
        summary = payload["summary"]
        changes = payload["cost_changes"]
        skipped = payload["skipped_resources"]

        # Only CREATE resources are present
        assert len(changes) == 1
        assert changes[0]["action"] == "CREATE"
        assert changes[0]["address"] == "azurerm_linux_virtual_machine.dev_analytics_vm"
        assert len(skipped) == 0

        # Summary values strictly match filtered CREATE resource
        assert summary["billable_count"] == 1
        assert summary["skipped_count"] == 0
        assert summary["total_old_cost"] == 0.0
        assert summary["total_new_cost"] == changes[0]["new_monthly_cost"]
        assert summary["total_delta"] == changes[0]["monthly_delta"]

    def test_filter_update_action(self, update_sku_plan_path: str):
        # 03_update_sku.json has 1 billable UPDATE (database_primary) and 1 skipped UPDATE (vnet_db)
        payload = generate_analysis_payload(update_sku_plan_path, action="UPDATE", offline=True)
        assert payload["selected_action"] == "UPDATE"
        summary = payload["summary"]
        changes = payload["cost_changes"]
        skipped = payload["skipped_resources"]

        assert len(changes) == 1
        assert changes[0]["action"] == "UPDATE"
        assert changes[0]["address"] == "azurerm_linux_virtual_machine.database_primary"
        assert len(skipped) == 1
        assert skipped[0]["action"] == "UPDATE"
        assert skipped[0]["address"] == "azurerm_virtual_network.vnet_db"

        # Summary checks
        assert summary["billable_count"] == 1
        assert summary["skipped_count"] == 1
        assert summary["total_old_cost"] == changes[0]["old_monthly_cost"]
        assert summary["total_new_cost"] == changes[0]["new_monthly_cost"]
        assert summary["total_delta"] == changes[0]["monthly_delta"]

    def test_filter_delete_action_with_zero_resources(self, update_sku_plan_path: str):
        # 03_update_sku.json has NO DELETE resources
        payload = generate_analysis_payload(update_sku_plan_path, action="DELETE", offline=True)
        assert payload["selected_action"] == "DELETE"
        summary = payload["summary"]
        assert summary["billable_count"] == 0
        assert summary["skipped_count"] == 0
        assert summary["total_old_cost"] == 0.0
        assert summary["total_new_cost"] == 0.0
        assert summary["total_delta"] == 0.0
        assert len(payload["cost_changes"]) == 0
        assert len(payload["skipped_resources"]) == 0
        assert len(payload["top_contributors"]) == 0
        # Check explanatory message for empty action
        assert any("No DELETE resources found" in exp for exp in payload["insights"]["explanations"])

    def test_filter_delete_action_on_delete_plan(self, delete_plan_path: str):
        # 02_delete.json contains two deleted VMs (legacy_worker, old_staging_vm) and one skipped rg
        payload = generate_analysis_payload(delete_plan_path, action="DELETE", offline=True)
        assert payload["selected_action"] == "DELETE"
        summary = payload["summary"]
        assert summary["billable_count"] == 2
        assert summary["skipped_count"] == 1
        assert summary["total_old_cost"] > 0
        assert summary["total_new_cost"] == 0.0
        assert summary["total_delta"] < 0
        assert summary["total_delta"] == -summary["total_old_cost"]

    def test_filter_replace_action(self):
        replace_path = str(SAMPLE_PLANS_DIR / "replace.json")
        payload = generate_analysis_payload(replace_path, action="REPLACE", offline=True)
        assert payload["selected_action"] == "REPLACE"
        assert payload["summary"]["billable_count"] >= 1
        for change in payload["cost_changes"]:
            assert change["action"] == "REPLACE"

    def test_invalid_action_falls_back_to_all(self, update_sku_plan_path: str):
        payload = generate_analysis_payload(update_sku_plan_path, action="INVALID_ACTION", offline=True)
        assert payload["selected_action"] == "ALL"
        assert payload["summary"]["billable_count"] == 2

    def test_case_insensitive_action_normalization(self, update_sku_plan_path: str):
        payload = generate_analysis_payload(update_sku_plan_path, action="  create  ", offline=True)
        assert payload["selected_action"] == "CREATE"
        assert payload["summary"]["billable_count"] == 1


class TestActionFilteringBudgetGuardrail:
    """Verifies that budget circuit breaker works correctly and without bypasses under action filtering."""

    def test_budget_preserves_overall_plan_status(self, update_sku_plan_path: str):
        # Suppose limit is $100. If total delta is > $300, overall plan FAILS.
        # But filtering to DELETE (delta = 0) with max_increase=100.0 should show action PASS while preserving plan_passed=False.
        payload_all = generate_analysis_payload(update_sku_plan_path, max_increase=100.0, offline=True)
        plan_delta = payload_all["summary"]["total_delta"]

        if plan_delta > 100.0:
            assert payload_all["budget"]["passed"] is False

        # Filter by DELETE (delta = 0) with max_increase=100.0
        payload_del = generate_analysis_payload(
            update_sku_plan_path, max_increase=100.0, action="DELETE", offline=True
        )
        b_del = payload_del["budget"]
        assert b_del is not None
        assert b_del["filter_action"] == "DELETE"
        assert b_del["total_delta"] == 0.0
        assert b_del["passed"] is True  # 0 <= 100
        assert b_del["plan_total_delta"] == round(plan_delta, 2)
        assert b_del["plan_passed"] == payload_all["budget"]["passed"]

    def test_budget_fails_when_action_delta_exceeds_limit(self, create_plan_path: str):
        # Strict limit of $5.00 for CREATE action
        payload = generate_analysis_payload(
            create_plan_path, max_increase=5.0, action="CREATE", offline=True
        )
        b = payload["budget"]
        assert b is not None
        assert b["passed"] is False
        assert b["status"] == "FAILED"
        assert b["remaining_budget"] < 0


@pytest.fixture(scope="module")
def action_test_server():
    port = 5234
    host = "127.0.0.1"
    server = create_server(
        host=host,
        port=port,
        plan_path=str(SAMPLE_PLANS_DIR / "03_update_sku.json"),
        max_increase=150.0,
        offline=True,
    )
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    time.sleep(0.1)

    base_url = f"http://{host}:{port}"
    yield {"base_url": base_url, "server": server}

    server.shutdown()
    server.server_close()


class TestActionFilteringHTTPAPI:
    """Verifies HTTP GET /api/analysis and POST /api/analyze with action filtering."""

    def test_get_api_analysis_default_all(self, action_test_server):
        base_url = action_test_server["base_url"]
        req = urllib.request.Request(f"{base_url}/api/analysis")
        with urllib.request.urlopen(req) as resp:
            assert resp.status == 200
            data = json.loads(resp.read().decode("utf-8"))
            assert data["selected_action"] == "ALL"
            assert data["action_counts"]["ALL"] >= 3
            assert data["summary"]["billable_count"] == 2

    def test_get_api_analysis_with_action_param(self, action_test_server):
        base_url = action_test_server["base_url"]
        req = urllib.request.Request(f"{base_url}/api/analysis?action=CREATE")
        with urllib.request.urlopen(req) as resp:
            assert resp.status == 200
            data = json.loads(resp.read().decode("utf-8"))
            assert data["selected_action"] == "CREATE"
            assert data["summary"]["billable_count"] == 1
            assert data["cost_changes"][0]["action"] == "CREATE"

    def test_post_api_analyze_with_action(self, action_test_server):
        base_url = action_test_server["base_url"]
        # Database upgrade from D2s_v5 to D8s_v5 delta is ~$210.24/mo, so max_increase of 300.0 passes
        body = json.dumps({
            "plan": "03_update_sku.json",
            "max_increase": 300.0,
            "action": "UPDATE",
        }).encode("utf-8")
        req = urllib.request.Request(
            f"{base_url}/api/analyze",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req) as resp:
            assert resp.status == 200
            data = json.loads(resp.read().decode("utf-8"))
            assert data["selected_action"] == "UPDATE"
            assert data["summary"]["billable_count"] == 1
            assert data["cost_changes"][0]["action"] == "UPDATE"
            assert data["budget"]["passed"] is True

    def test_post_api_analyze_switch_to_all(self, action_test_server):
        base_url = action_test_server["base_url"]
        body = json.dumps({
            "plan": "01_create.json",
            "action": "ALL",
        }).encode("utf-8")
        req = urllib.request.Request(
            f"{base_url}/api/analyze",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req) as resp:
            assert resp.status == 200
            data = json.loads(resp.read().decode("utf-8"))
            assert data["selected_action"] == "ALL"
            assert data["plan_file"] == "01_create.json"


class TestHostileAndEdgeActionFiltering:
    """Verifies robustness on hostile, corrupted, or empty plans."""

    def test_hostile_plan_action_filtering(self, mixed_hostile_plan_path: str):
        payload = generate_analysis_payload(mixed_hostile_plan_path, action="CREATE", offline=True)
        assert payload["status"] == "success"
        assert payload["selected_action"] == "CREATE"
        # Must not crash, should handle valid VM and skipped incomplete entries
        assert payload["summary"]["billable_count"] >= 1
        assert payload["summary"]["skipped_count"] >= 1

    def test_empty_plan_action_filtering(self, empty_plan_path: str):
        payload = generate_analysis_payload(empty_plan_path, action="DELETE", offline=True)
        assert payload["status"] == "success"
        assert payload["selected_action"] == "DELETE"
        assert payload["summary"]["total_changes"] == 0
        assert payload["summary"]["total_delta"] == 0.0
        assert len(payload["cost_changes"]) == 0
        assert len(payload["skipped_resources"]) == 0

    @pytest.mark.parametrize("plan_file", [
        "01_create.json",
        "02_delete.json",
        "03_update_sku.json",
        "04_mixed_hostile.json",
        "05_budget_fail.json",
    ])
    @pytest.mark.parametrize("action", ["ALL", "CREATE", "UPDATE", "DELETE", "REPLACE"])
    def test_all_demo_plans_with_all_actions(self, plan_file: str, action: str):
        path = str(SAMPLE_PLANS_DIR / plan_file)
        payload = generate_analysis_payload(path, max_increase=100.0, action=action, offline=True)
        assert payload["status"] == "success"
        assert payload["selected_action"] == action
        assert "action_counts" in payload
        assert "summary" in payload
        assert "budget" in payload
        assert "cost_changes" in payload
        assert "skipped_resources" in payload

        # Check math consistency
        summary = payload["summary"]
        assert round(summary["total_new_cost"] - summary["total_old_cost"], 2) == summary["total_delta"]
        if action != "ALL":
            for c in payload["cost_changes"]:
                assert c["action"] == action
            for s in payload["skipped_resources"]:
                assert s["action"] == action
