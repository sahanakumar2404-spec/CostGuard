"""
CostGuard Test Suite
"""
