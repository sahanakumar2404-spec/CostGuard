"""
Tests for CostGuard Data Models (costguard.models)
"""

import pytest

from costguard.models import ActionType, PlanParseResult, ResourceChange


class TestActionType:
    def test_action_values(self):
        assert ActionType.CREATE == "CREATE"
        assert ActionType.DELETE == "DELETE"
        assert ActionType.UPDATE == "UPDATE"
        assert ActionType.REPLACE == "REPLACE"
        assert ActionType.NOOP == "NOOP"
        assert ActionType.UNKNOWN == "UNKNOWN"

    def test_str_representation(self):
        assert str(ActionType.CREATE) == "CREATE"
        assert str(ActionType.REPLACE) == "REPLACE"


class TestResourceChange:
    def test_basic_initialization(self):
        rc = ResourceChange(
            address="aws_instance.web",
            resource_type="aws_instance",
            action=ActionType.CREATE,
            after_state={"instance_type": "t3.micro", "availability_zone": "us-east-1a"},
            new_sku="t3.micro",
            new_region="us-east-1",
        )
        assert rc.address == "aws_instance.web"
        assert rc.resource_type == "aws_instance"
        assert rc.action == "CREATE"
        assert rc.is_create is True
        assert rc.is_delete is False
        assert rc.is_update is False
        assert rc.is_replace is False
        assert rc.sku == "t3.micro"
        assert rc.region == "us-east-1"

    def test_action_normalization(self):
        rc_lower = ResourceChange(
            address="res.test",
            resource_type="res",
            action="update",
        )
        assert rc_lower.action == "UPDATE"
        assert rc_lower.is_update is True

    def test_replace_properties(self):
        rc = ResourceChange(
            address="azurerm_linux_virtual_machine.app",
            resource_type="azurerm_linux_virtual_machine",
            action=ActionType.REPLACE,
            before_state={"size": "Standard_B1s"},
            after_state={"size": "Standard_B2s"},
            old_sku="Standard_B1s",
            new_sku="Standard_B2s",
            old_region="eastus",
            new_region="eastus",
        )
        assert rc.is_replace is True
        assert rc.sku == "Standard_B2s"  # prefers new_sku
        assert rc.region == "eastus"

    def test_delete_sku_fallback(self):
        rc = ResourceChange(
            address="aws_instance.old",
            resource_type="aws_instance",
            action=ActionType.DELETE,
            before_state={"instance_type": "t2.micro"},
            old_sku="t2.micro",
            old_region="us-west-2",
        )
        assert rc.is_delete is True
        assert rc.sku == "t2.micro"  # falls back to old_sku
        assert rc.region == "us-west-2"

    def test_to_dict_serialization(self):
        rc = ResourceChange(
            address="aws_instance.web",
            resource_type="aws_instance",
            action=ActionType.CREATE,
            new_sku="t3.micro",
            new_region="us-east-1",
        )
        data = rc.to_dict()
        assert isinstance(data, dict)
        assert data["address"] == "aws_instance.web"
        assert data["action"] == "CREATE"
        assert data["new_sku"] == "t3.micro"
        assert data["new_region"] == "us-east-1"
        assert data["sku"] == "t3.micro"


class TestPlanParseResult:
    def test_summary_calculation(self):
        changes = [
            ResourceChange("r1", "aws_instance", ActionType.CREATE),
            ResourceChange("r2", "aws_instance", ActionType.CREATE),
            ResourceChange("r3", "aws_instance", ActionType.UPDATE),
            ResourceChange("r4", "aws_instance", ActionType.DELETE),
            ResourceChange("r5", "aws_instance", ActionType.REPLACE),
            ResourceChange("r6", "aws_instance", ActionType.NOOP),
            ResourceChange("r7", "aws_instance", ActionType.UNKNOWN),
        ]
        res = PlanParseResult(resource_changes=changes)
        summary = res.summary
        assert summary["total"] == 7
        assert summary["create"] == 2
        assert summary["update"] == 1
        assert summary["delete"] == 1
        assert summary["replace"] == 1
        assert summary["noop"] == 1
        assert summary["unknown"] == 1

    def test_to_dict(self):
        res = PlanParseResult(
            resource_changes=[ResourceChange("r1", "aws_instance", ActionType.CREATE)],
            warnings=["Test warning"],
            terraform_version="1.8.5",
            format_version="1.2",
        )
        d = res.to_dict()
        assert d["summary"]["total"] == 1
        assert len(d["resource_changes"]) == 1
        assert d["warnings"] == ["Test warning"]
        assert d["terraform_version"] == "1.8.5"
