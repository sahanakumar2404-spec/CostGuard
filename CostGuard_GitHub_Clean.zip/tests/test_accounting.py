"""
Tests for CostGuard Cost Accounting & Budget Circuit Breaker (costguard.accounting)
Verifies create, delete, update, replacement calculations, 730-hour rule,
positive/negative deltas, non-billable skips, budget PASS/FAIL, and exit codes.
"""

from unittest.mock import MagicMock, patch

import pytest

from costguard.accounting import (
    HOURS_PER_MONTH,
    CostAccountingEngine,
    CostAnalysisReport,
    ResourceCostChange,
    SkippedResource,
    format_cost_table,
    format_currency,
)
from costguard.cache import SQLitePricingCache
from costguard.cli import run_cli
from costguard.models import ActionType, PlanParseResult, ResourceChange
from costguard.pricing import AzurePricingClient, PriceResult


@pytest.fixture
def mock_pricing_client():
    cache = SQLitePricingCache(db_path=":memory:")
    client = AzurePricingClient(cache=cache, timeout=5.0)

    # Pre-populate cache with known prices
    # Standard_B1s: $0.012/hr (monthly = 0.012 * 730 = $8.76)
    cache.set("azurerm_linux_virtual_machine", "Standard_B1s", "eastus", 0.012)
    # Standard_B2s: $0.0416/hr (monthly = 0.0416 * 730 = $30.368)
    cache.set("azurerm_linux_virtual_machine", "Standard_B2s", "eastus", 0.0416)
    # Standard_D2s_v5: $0.096/hr (monthly = 0.096 * 730 = $70.08)
    cache.set("azurerm_linux_virtual_machine", "Standard_D2s_v5", "eastus", 0.096)
    # Standard_D4s_v5: $0.192/hr (monthly = 0.192 * 730 = $140.16)
    cache.set("azurerm_linux_virtual_machine", "Standard_D4s_v5", "eastus", 0.192)

    return client


@pytest.fixture
def engine(mock_pricing_client):
    return CostAccountingEngine(pricing_client=mock_pricing_client)


class TestCostAccountingActions:
    def test_create_cost(self, engine):
        rc = ResourceChange(
            address="azurerm_linux_virtual_machine.web",
            resource_type="azurerm_linux_virtual_machine",
            action=ActionType.CREATE,
            new_sku="Standard_D4s_v5",
            new_region="eastus",
        )
        item = engine.calculate_resource_cost(rc)
        assert isinstance(item, ResourceCostChange)
        assert item.old_monthly_cost == 0.0
        assert item.new_hourly_price == 0.192
        assert item.new_monthly_cost == 0.192 * HOURS_PER_MONTH  # 140.16
        assert item.monthly_delta == item.new_monthly_cost
        assert item.action == "CREATE"

    def test_delete_cost(self, engine):
        rc = ResourceChange(
            address="azurerm_linux_virtual_machine.old",
            resource_type="azurerm_linux_virtual_machine",
            action=ActionType.DELETE,
            old_sku="Standard_D2s_v5",
            old_region="eastus",
        )
        item = engine.calculate_resource_cost(rc)
        assert isinstance(item, ResourceCostChange)
        assert item.old_hourly_price == 0.096
        assert item.old_monthly_cost == 0.096 * HOURS_PER_MONTH  # 70.08
        assert item.new_monthly_cost == 0.0
        assert item.monthly_delta == -item.old_monthly_cost  # -70.08
        assert item.monthly_delta < 0
        assert item.action == "DELETE"

    def test_update_cost_positive_delta(self, engine):
        # Resize B1s ($8.76/mo) -> B2s ($30.368/mo)
        rc = ResourceChange(
            address="azurerm_linux_virtual_machine.app",
            resource_type="azurerm_linux_virtual_machine",
            action=ActionType.UPDATE,
            old_sku="Standard_B1s",
            new_sku="Standard_B2s",
            old_region="eastus",
            new_region="eastus",
        )
        item = engine.calculate_resource_cost(rc)
        assert isinstance(item, ResourceCostChange)
        assert item.old_monthly_cost == 0.012 * HOURS_PER_MONTH
        assert item.new_monthly_cost == 0.0416 * HOURS_PER_MONTH
        expected_delta = (0.0416 - 0.012) * HOURS_PER_MONTH
        assert round(item.monthly_delta, 4) == round(expected_delta, 4)
        assert item.monthly_delta > 0

    def test_update_cost_negative_delta(self, engine):
        # Downsize D4s_v5 ($140.16) -> D2s_v5 ($70.08)
        rc = ResourceChange(
            address="azurerm_linux_virtual_machine.worker",
            resource_type="azurerm_linux_virtual_machine",
            action=ActionType.UPDATE,
            old_sku="Standard_D4s_v5",
            new_sku="Standard_D2s_v5",
            old_region="eastus",
            new_region="eastus",
        )
        item = engine.calculate_resource_cost(rc)
        assert isinstance(item, ResourceCostChange)
        assert item.old_monthly_cost == 0.192 * HOURS_PER_MONTH
        assert item.new_monthly_cost == 0.096 * HOURS_PER_MONTH
        assert item.monthly_delta < 0
        assert round(item.monthly_delta, 2) == -70.08

    def test_replacement_cost(self, engine):
        rc = ResourceChange(
            address="azurerm_linux_virtual_machine.db",
            resource_type="azurerm_linux_virtual_machine",
            action=ActionType.REPLACE,
            old_sku="Standard_B2s",
            new_sku="Standard_D4s_v5",
            old_region="eastus",
            new_region="eastus",
        )
        item = engine.calculate_resource_cost(rc)
        assert isinstance(item, ResourceCostChange)
        assert item.action == "REPLACE"
        assert item.old_monthly_cost == 0.0416 * HOURS_PER_MONTH
        assert item.new_monthly_cost == 0.192 * HOURS_PER_MONTH
        assert item.monthly_delta == item.new_monthly_cost - item.old_monthly_cost


class TestNonBillableAndEdgeCases:
    def test_non_billable_resources_skipped(self, engine):
        non_billables = [
            ResourceChange("random_pet.server", "random_pet", ActionType.CREATE),
            ResourceChange("null_resource.cluster", "null_resource", ActionType.CREATE),
            ResourceChange("azurerm_resource_group.rg", "azurerm_resource_group", ActionType.CREATE),
        ]
        for rc in non_billables:
            item = engine.calculate_resource_cost(rc)
            assert isinstance(item, SkippedResource)
            assert item.address == rc.address
            assert "Non-billable" in item.reason or "not configured" in item.reason

    def test_missing_sku_skipped(self, engine):
        rc = ResourceChange(
            address="azurerm_linux_virtual_machine.bare",
            resource_type="azurerm_linux_virtual_machine",
            action=ActionType.CREATE,
            new_sku=None,
            new_region="eastus",
        )
        item = engine.calculate_resource_cost(rc)
        assert isinstance(item, SkippedResource)
        assert "Missing SKU" in item.reason

    def test_unknown_unpriced_sku_skipped(self, engine):
        rc = ResourceChange(
            address="azurerm_linux_virtual_machine.mystic",
            resource_type="azurerm_linux_virtual_machine",
            action=ActionType.CREATE,
            new_sku="Standard_MYSTIC_UNKNOWN",
            new_region="eastus",
        )
        item = engine.calculate_resource_cost(rc)
        assert isinstance(item, SkippedResource)
        assert "Pricing unavailable" in item.reason


class TestCostTotalsAndPrecision:
    def test_multiple_resources_unrounded_totals(self, engine):
        changes = [
            ResourceChange("vm1", "azurerm_linux_virtual_machine", ActionType.CREATE, new_sku="Standard_B1s", new_region="eastus"),
            ResourceChange("vm2", "azurerm_linux_virtual_machine", ActionType.CREATE, new_sku="Standard_B2s", new_region="eastus"),
            ResourceChange("vm3", "azurerm_linux_virtual_machine", ActionType.DELETE, old_sku="Standard_D2s_v5", old_region="eastus"),
            ResourceChange("pet", "random_pet", ActionType.CREATE),
        ]
        plan_result = PlanParseResult(resource_changes=changes)
        report = engine.analyze_plan(plan_result)

        assert len(report.cost_changes) == 3
        assert len(report.skipped_resources) == 1

        # Intermediate totals are full precision floats
        expected_old = 0.0 + 0.0 + (0.096 * HOURS_PER_MONTH)
        expected_new = (0.012 * HOURS_PER_MONTH) + (0.0416 * HOURS_PER_MONTH) + 0.0
        expected_delta = expected_new - expected_old

        assert report.total_old_cost == expected_old
        assert report.total_new_cost == expected_new
        assert report.total_delta == expected_delta


class TestBudgetCircuitBreaker:
    def test_budget_pass(self, engine):
        # Create B1s: delta = $8.76
        changes = [
            ResourceChange("vm1", "azurerm_linux_virtual_machine", ActionType.CREATE, new_sku="Standard_B1s", new_region="eastus"),
        ]
        plan_result = PlanParseResult(resource_changes=changes)
        # Budget limit $10.00 >= $8.76 -> PASS
        report = engine.analyze_plan(plan_result, max_increase=10.0)

        assert report.budget_passed is True
        assert report.max_increase == 10.0
        output = format_cost_table(report)
        assert "✓ BUDGET CHECK: PASS" in output

    def test_budget_fail(self, engine):
        # Create D4s_v5: delta = $140.16
        changes = [
            ResourceChange("vm1", "azurerm_linux_virtual_machine", ActionType.CREATE, new_sku="Standard_D4s_v5", new_region="eastus"),
        ]
        plan_result = PlanParseResult(resource_changes=changes)
        # Budget limit $100.00 < $140.16 -> FAIL
        report = engine.analyze_plan(plan_result, max_increase=100.0)

        assert report.budget_passed is False
        assert report.max_increase == 100.0
        output = format_cost_table(report)
        assert "✗ BUDGET CHECK: FAILED" in output
        assert "Deployment BLOCKED" in output
        assert "Exit Code: 1" in output


class TestCLIBudgetAndExitCodes:
    def test_cli_budget_pass_exit_0(self):
        # create.json has Azure VM Standard_D4s_v5 ($140.16)
        # With budget limit 200 -> PASS -> exit 0
        exit_code = run_cli(["--plan", "sample_plans/create.json", "--max-increase", "200"])
        assert exit_code == 0

    def test_cli_budget_fail_exit_1(self, capsys):
        # create.json has Azure VM Standard_D4s_v5 ($140.16)
        # With budget limit 50 -> FAIL -> exit 1
        exit_code = run_cli(["--plan", "sample_plans/create.json", "--max-increase", "50"])
        assert exit_code == 1
        captured = capsys.readouterr()
        assert "✗ BUDGET CHECK: FAILED" in captured.out
        assert "Deployment BLOCKED" in captured.out

    def test_cli_invalid_input_exit_2(self):
        # Non-existent plan file
        exit_code = run_cli(["--plan", "does_not_exist_file.json"])
        assert exit_code == 2

    def test_cli_negative_budget_exit_2(self):
        # Negative max increase is invalid
        exit_code = run_cli(["--plan", "sample_plans/create.json", "--max-increase", "-10"])
        assert exit_code == 2


class TestFormattingAndSerialization:
    def test_format_currency(self):
        assert format_currency(0.0) == "$0.00"
        assert format_currency(1234.567) == "$1,234.57"
        assert format_currency(50.0, show_sign=True) == "+$50.00"
        assert format_currency(-25.5, show_sign=True) == "-$25.50"

    def test_report_to_dict_structure(self, engine):
        changes = [
            ResourceChange("vm1", "azurerm_linux_virtual_machine", ActionType.CREATE, new_sku="Standard_B1s", new_region="eastus"),
        ]
        plan_result = PlanParseResult(resource_changes=changes)
        report = engine.analyze_plan(plan_result, max_increase=50.0)
        d = report.to_dict()

        assert "summary" in d
        assert "budget" in d
        assert d["budget"]["passed"] is True
        assert d["budget"]["status"] == "PASS"
        assert len(d["cost_changes"]) == 1
