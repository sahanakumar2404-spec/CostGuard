"""
Tests for CostGuard Azure Pricing Engine (costguard.pricing)
Verifies Azure Retail Prices API client, filter queries, Spot/Low Priority exclusions,
cache interactions, error handling, and manual live lookups.
"""

import json
import urllib.error
from unittest.mock import MagicMock, patch

import pytest

from costguard.cache import SQLitePricingCache
from costguard.pricing import AzurePricingClient, PriceResult

# Sample mock API responses based on official Azure Retail Prices API structure
MOCK_API_DSV5_ITEMS = [
    {
        "currencyCode": "USD",
        "tierMinimumUnits": 0.0,
        "retailPrice": 0.376,
        "unitPrice": 0.376,
        "armRegionName": "eastus",
        "location": "East US",
        "meterId": "1111-2222-3333",
        "meterName": "D4s v5",
        "productName": "Virtual Machines Dsv5 Series Windows",
        "skuName": "Standard_D4s_v5",
        "serviceName": "Virtual Machines",
        "serviceId": "DZH313Z7MMC8",
        "serviceFamily": "Compute",
        "unitOfMeasure": "1 Hour",
        "type": "Consumption",
        "isPrimaryMeterRegion": True,
        "armSkuName": "Standard_D4s_v5",
    },
    {
        "currencyCode": "USD",
        "tierMinimumUnits": 0.0,
        "retailPrice": 0.0384,
        "unitPrice": 0.0384,
        "armRegionName": "eastus",
        "location": "East US",
        "meterId": "2222-3333-4444",
        "meterName": "D4s v5 Low Priority",
        "productName": "Virtual Machines Dsv5 Series",
        "skuName": "Standard_D4s_v5 Low Priority",
        "serviceName": "Virtual Machines",
        "serviceId": "DZH313Z7MMC8",
        "serviceFamily": "Compute",
        "unitOfMeasure": "1 Hour",
        "type": "Consumption",
        "isPrimaryMeterRegion": True,
        "armSkuName": "Standard_D4s_v5",
    },
    {
        "currencyCode": "USD",
        "tierMinimumUnits": 0.0,
        "retailPrice": 0.079374,
        "unitPrice": 0.079374,
        "armRegionName": "eastus",
        "location": "East US",
        "meterId": "3333-4444-5555",
        "meterName": "D4s v5 Spot",
        "productName": "Virtual Machines Dsv5 Series",
        "skuName": "Standard_D4s_v5 Spot",
        "serviceName": "Virtual Machines",
        "serviceId": "DZH313Z7MMC8",
        "serviceFamily": "Compute",
        "unitOfMeasure": "1 Hour",
        "type": "Consumption",
        "isPrimaryMeterRegion": True,
        "armSkuName": "Standard_D4s_v5",
    },
    {
        "currencyCode": "USD",
        "tierMinimumUnits": 0.0,
        "retailPrice": 0.192,
        "unitPrice": 0.192,
        "armRegionName": "eastus",
        "location": "East US",
        "meterId": "4444-5555-6666",
        "meterName": "D4s v5",
        "productName": "Virtual Machines Dsv5 Series",
        "skuName": "Standard_D4s_v5",
        "serviceName": "Virtual Machines",
        "serviceId": "DZH313Z7MMC8",
        "serviceFamily": "Compute",
        "unitOfMeasure": "1 Hour",
        "type": "Consumption",
        "isPrimaryMeterRegion": True,
        "armSkuName": "Standard_D4s_v5",
    },
    {
        "currencyCode": "USD",
        "tierMinimumUnits": 0.0,
        "retailPrice": 1200.0,
        "unitPrice": 1200.0,
        "armRegionName": "eastus",
        "location": "East US",
        "meterId": "5555-6666-7777",
        "meterName": "D4s v5 1 Year Reserved",
        "productName": "Virtual Machines Dsv5 Series",
        "skuName": "Standard_D4s_v5",
        "serviceName": "Virtual Machines",
        "serviceId": "DZH313Z7MMC8",
        "serviceFamily": "Compute",
        "unitOfMeasure": "1 Year",
        "type": "Reservation",
        "isPrimaryMeterRegion": True,
        "armSkuName": "Standard_D4s_v5",
    },
]


@pytest.fixture
def mem_cache():
    return SQLitePricingCache(db_path=":memory:")


@pytest.fixture
def pricing_client(mem_cache):
    return AzurePricingClient(cache=mem_cache, timeout=5.0)


class TestAzurePricingClient:
    def test_build_query(self, pricing_client):
        query = pricing_client.build_query(
            resource_type="azurerm_linux_virtual_machine",
            sku="Standard_D4s_v5",
            region="East US",
        )
        assert "armRegionName eq 'eastus'" in query
        assert "priceType eq 'Consumption'" in query
        assert "Standard_D4s_v5" in query

    @patch("costguard.pricing.AzurePricingClient._execute_api_request")
    def test_api_lookup(self, mock_exec, pricing_client):
        mock_exec.return_value = MOCK_API_DSV5_ITEMS

        res = pricing_client.get_price(
            resource_type="azurerm_linux_virtual_machine",
            sku="Standard_D4s_v5",
            region="eastus",
        )
        assert res is not None
        assert isinstance(res, PriceResult)
        assert res.price == 0.192
        assert res.currency == "USD"
        assert res.unit_of_measure == "1 Hour"
        assert res.source == "api"
        assert res.product_name == "Virtual Machines Dsv5 Series"
        assert res.monthly_price == round(0.192 * 730, 4)

    @patch("costguard.pricing.AzurePricingClient._execute_api_request")
    def test_spot_exclusion(self, mock_exec, pricing_client):
        # Items only have Spot and standard Linux consumption
        mock_exec.return_value = [
            {
                "retailPrice": 0.05,
                "unitOfMeasure": "1 Hour",
                "type": "Consumption",
                "skuName": "Standard_B2s Spot",
                "productName": "Virtual Machines BS Series",
                "meterName": "B2s Spot",
                "armSkuName": "Standard_B2s",
            },
            {
                "retailPrice": 0.10,
                "unitOfMeasure": "1 Hour",
                "type": "Consumption",
                "skuName": "Standard_B2s",
                "productName": "Virtual Machines BS Series",
                "meterName": "B2s",
                "armSkuName": "Standard_B2s",
            },
        ]
        res = pricing_client.get_price("azurerm_linux_virtual_machine", "Standard_B2s", "eastus")
        assert res is not None
        # Must select the standard 0.10 price, not Spot (0.05)
        assert res.price == 0.10
        assert "spot" not in res.product_name.lower()
        assert "spot" not in res.meter_name.lower()

    @patch("costguard.pricing.AzurePricingClient._execute_api_request")
    def test_low_priority_exclusion(self, mock_exec, pricing_client):
        # Items have Low Priority and standard
        mock_exec.return_value = [
            {
                "retailPrice": 0.02,
                "unitOfMeasure": "1 Hour",
                "type": "Consumption",
                "skuName": "Standard_B2s Low Priority",
                "productName": "Virtual Machines BS Series",
                "meterName": "B2s Low Priority",
                "armSkuName": "Standard_B2s",
            },
            {
                "retailPrice": 0.08,
                "unitOfMeasure": "1 Hour",
                "type": "Consumption",
                "skuName": "Standard_B2s",
                "productName": "Virtual Machines BS Series",
                "meterName": "B2s",
                "armSkuName": "Standard_B2s",
            },
        ]
        res = pricing_client.get_price("azurerm_linux_virtual_machine", "Standard_B2s", "eastus")
        assert res is not None
        assert res.price == 0.08
        assert "low priority" not in res.product_name.lower()

    @patch("costguard.pricing.AzurePricingClient._execute_api_request")
    def test_correct_filtering_non_consumption_excluded(self, mock_exec, pricing_client):
        # Reservation type must be ignored
        mock_exec.return_value = [
            {
                "retailPrice": 500.0,
                "unitOfMeasure": "1 Year",
                "type": "Reservation",
                "skuName": "Standard_B2s",
                "productName": "Virtual Machines BS Series",
                "meterName": "B2s 1 Year",
                "armSkuName": "Standard_B2s",
            }
        ]
        res = pricing_client.get_price("azurerm_linux_virtual_machine", "Standard_B2s", "eastus")
        assert res is None
        assert any("Spot/Low Priority were excluded" in w or "No standard Azure Consumption" in w for w in pricing_client.warnings)

    @patch("costguard.pricing.AzurePricingClient._execute_api_request")
    def test_windows_vs_linux_os_filtering(self, mock_exec, pricing_client):
        mock_exec.return_value = MOCK_API_DSV5_ITEMS

        # Windows VM
        res_win = pricing_client.get_price("azurerm_windows_virtual_machine", "Standard_D4s_v5", "eastus")
        assert res_win is not None
        assert res_win.price == 0.376
        assert "Windows" in res_win.product_name

        # Linux VM
        res_linux = pricing_client.get_price("azurerm_linux_virtual_machine", "Standard_D4s_v5", "eastus")
        assert res_linux is not None
        assert res_linux.price == 0.192
        assert "Windows" not in res_linux.product_name

    @patch("costguard.pricing.AzurePricingClient._execute_api_request")
    def test_cache_miss_then_write_then_hit(self, mock_exec, pricing_client):
        mock_exec.return_value = MOCK_API_DSV5_ITEMS

        stats_start = pricing_client.stats()
        assert stats_start["cache_hits"] == 0
        assert stats_start["cache_misses"] == 0
        assert stats_start["api_calls"] == 0

        # First call: Cache miss -> API call -> write to cache
        res1 = pricing_client.get_price("azurerm_linux_virtual_machine", "Standard_D4s_v5", "eastus")
        assert res1 is not None
        assert res1.source == "api"

        stats_after1 = pricing_client.stats()
        assert stats_after1["cache_misses"] == 1
        assert stats_after1["api_calls"] == 1
        assert stats_after1["cache_hits"] == 0
        assert mock_exec.call_count == 1

        # Second call: Cache hit -> No API call
        res2 = pricing_client.get_price("azurerm_linux_virtual_machine", "Standard_D4s_v5", "eastus")
        assert res2 is not None
        assert res2.source == "cache"
        assert res2.price == 0.192

        stats_after2 = pricing_client.stats()
        assert stats_after2["cache_hits"] == 1
        assert stats_after2["api_calls"] == 1  # No new API call
        assert mock_exec.call_count == 1

    @patch("costguard.pricing.AzurePricingClient._execute_api_request")
    def test_api_failure_with_cache_fallback(self, mock_exec, pricing_client):
        # Populate cache first
        pricing_client.cache.set(
            resource_type="azurerm_linux_virtual_machine",
            sku="Standard_B1s",
            region="eastus",
            price=0.012,
            currency="USD",
            metadata={"unit_of_measure": "1 Hour", "product_name": "Virtual Machines BS Series"},
        )

        # Mock API raising HTTP 500 error on forced refresh
        mock_exec.side_effect = urllib.error.HTTPError(
            url="https://prices.azure.com",
            code=500,
            msg="Internal Server Error",
            hdrs={},
            fp=None,
        )

        res = pricing_client.get_price(
            "azurerm_linux_virtual_machine",
            "Standard_B1s",
            "eastus",
            force_refresh=True,
        )
        assert res is not None
        # Should gracefully return the cached price
        assert res.price == 0.012
        assert res.source == "cache"

    @patch("costguard.pricing.AzurePricingClient._execute_api_request")
    def test_unknown_sku(self, mock_exec, pricing_client):
        mock_exec.return_value = []  # No items returned

        res = pricing_client.get_price(
            "azurerm_linux_virtual_machine",
            "Standard_UNKNOWN_NONEXISTENT",
            "eastus",
        )
        assert res is None
        assert any("No standard Azure Consumption pricing found" in w for w in pricing_client.warnings)

    @patch("costguard.pricing.AzurePricingClient._execute_api_request")
    def test_timeout_handling(self, mock_exec, pricing_client):
        # Mock TimeoutError
        mock_exec.side_effect = TimeoutError("Connection timed out after 5.0s")

        res = pricing_client.get_price(
            "azurerm_linux_virtual_machine",
            "Standard_D4s_v5",
            "eastus",
        )
        assert res is None
        assert any("timeout" in w.lower() for w in pricing_client.warnings)

    def test_offline_mode(self, pricing_client):
        pricing_client.offline = True
        # Try fetching uncached resource in offline mode
        res = pricing_client.get_price(
            "azurerm_linux_virtual_machine",
            "Standard_D4s_v5",
            "eastus",
        )
        assert res is None
        assert any("Offline mode" in w for w in pricing_client.warnings)

        # If resource is cached, offline mode successfully serves it
        pricing_client.cache.set("azurerm_linux_virtual_machine", "Standard_D4s_v5", "eastus", 0.192)
        res_cached = pricing_client.get_price(
            "azurerm_linux_virtual_machine",
            "Standard_D4s_v5",
            "eastus",
        )
        assert res_cached is not None
        assert res_cached.price == 0.192
        assert res_cached.source == "cache"


class TestLiveAzurePricingAPI:
    """Manual/integration test hitting the real public Azure Retail Prices API."""

    def test_live_azure_api_lookup(self):
        client = AzurePricingClient(cache=SQLitePricingCache(db_path=":memory:"), timeout=15.0)
        try:
            res = client.get_price(
                resource_type="azurerm_linux_virtual_machine",
                sku="Standard_D4s_v5",
                region="eastus",
            )
        except Exception as exc:
            pytest.skip(f"Live network access unavailable: {exc}")

        if res is None:
            pytest.skip(f"Could not connect to live Azure API (warnings: {client.warnings})")

        assert res.price > 0.0
        assert res.sku == "Standard_D4s_v5"
        assert res.region == "eastus"
        assert res.currency == "USD"
        assert res.source == "api"
        # Confirm it was written to cache
        cached = client.cache.get("azurerm_linux_virtual_machine", "Standard_D4s_v5", "eastus")
        assert cached is not None
        assert cached.price == res.price
