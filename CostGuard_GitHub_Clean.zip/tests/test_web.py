"""
Tests for CostGuard Web Visualization and Reporting Engine (Phase 4).
Verifies data payload generation, HTTP API endpoints, static assets,
budget guardrail statuses, and explainable cost insights.
"""

from __future__ import annotations

import json
import threading
import time
import urllib.request
import urllib.error
from pathlib import Path
from typing import Any

import pytest

from costguard.cache import SQLitePricingCache
from costguard.pricing import AzurePricingClient
from costguard.web import (
    create_server,
    generate_analysis_payload,
    SAMPLE_PLANS_DIR,
    WEB_DIR,
)


@pytest.fixture
def create_plan_path() -> str:
    return str(SAMPLE_PLANS_DIR / "create.json")


@pytest.fixture
def update_plan_path() -> str:
    return str(SAMPLE_PLANS_DIR / "update.json")


@pytest.fixture
def delete_plan_path() -> str:
    return str(SAMPLE_PLANS_DIR / "delete.json")


@pytest.fixture
def replace_plan_path() -> str:
    return str(SAMPLE_PLANS_DIR / "replace.json")


@pytest.fixture
def empty_plan_path() -> str:
    return str(SAMPLE_PLANS_DIR / "empty.json")


class TestGenerateAnalysisPayload:
    """Tests for payload structure, numerical precision, and insight generation."""

    def test_payload_basic_structure(self, create_plan_path: str):
        payload = generate_analysis_payload(create_plan_path, offline=True)
        assert payload["status"] == "success"
        assert payload["plan_file"] == "create.json"
        assert "summary" in payload
        assert "cost_changes" in payload
        assert "skipped_resources" in payload
        assert "cache_stats" in payload
        assert "insights" in payload
        assert payload["budget"] is None

    def test_payload_summary_values(self, create_plan_path: str):
        payload = generate_analysis_payload(create_plan_path, offline=True)
        summary = payload["summary"]
        assert summary["total_old_cost"] == 0.0
        assert summary["total_new_cost"] > 0.0
        assert summary["total_delta"] == summary["total_new_cost"]
        assert summary["total_changes"] == 4
        assert summary["billable_count"] >= 1
        assert summary["skipped_count"] >= 1

    def test_payload_budget_pass(self, create_plan_path: str):
        # High budget: pass
        payload = generate_analysis_payload(create_plan_path, max_increase=1000.0, offline=True)
        budget = payload["budget"]
        assert budget is not None
        assert budget["max_increase"] == 1000.0
        assert budget["passed"] is True
        assert budget["status"] == "PASS"
        assert budget["remaining_budget"] > 0
        assert budget["percent_used"] < 100.0

    def test_payload_budget_failed(self, create_plan_path: str):
        # Strict low budget: fail
        payload = generate_analysis_payload(create_plan_path, max_increase=10.0, offline=True)
        budget = payload["budget"]
        assert budget is not None
        assert budget["max_increase"] == 10.0
        assert budget["passed"] is False
        assert budget["status"] == "FAILED"
        assert budget["remaining_budget"] < 0
        assert budget["percent_used"] > 100.0

    def test_payload_explainable_insights_increase(self, create_plan_path: str):
        payload = generate_analysis_payload(create_plan_path, offline=True)
        insights = payload["insights"]
        assert insights["increase_count"] >= 1
        assert insights["largest_increase_resource"] is not None
        assert insights["largest_increase_amount"] > 0
        assert any("increased projected monthly cost" in exp for exp in insights["explanations"])

    def test_payload_delete_plan_decrease_insights(self):
        delete_plan_json = json.dumps({
            "format_version": "1.2",
            "terraform_version": "1.8.5",
            "resource_changes": [
                {
                    "address": "azurerm_linux_virtual_machine.old_server",
                    "type": "azurerm_linux_virtual_machine",
                    "change": {
                        "actions": ["delete"],
                        "before": {
                            "size": "Standard_D4s_v5",
                            "location": "eastus"
                        },
                        "after": None
                    }
                }
            ]
        })
        cache = SQLitePricingCache(db_path=":memory:")
        cache.set("azurerm_linux_virtual_machine", "Standard_D4s_v5", "eastus", 0.192)
        client = AzurePricingClient(cache=cache, offline=True)
        payload = generate_analysis_payload(delete_plan_json, pricing_client=client)
        insights = payload["insights"]
        assert insights["decrease_count"] >= 1
        assert insights["largest_decrease_resource"] == "azurerm_linux_virtual_machine.old_server"
        assert insights["largest_decrease_amount"] < 0
        assert any("reduced projected monthly cost" in exp for exp in insights["explanations"])

    def test_payload_empty_plan(self, empty_plan_path: str):
        payload = generate_analysis_payload(empty_plan_path, offline=True)
        assert payload["status"] == "success"
        assert payload["summary"]["total_changes"] == 0
        assert payload["summary"]["total_delta"] == 0.0
        assert len(payload["cost_changes"]) == 0
        assert "No billable cost delta detected" in payload["insights"]["explanations"][0]

    def test_payload_skipped_resources_reasons(self, create_plan_path: str):
        payload = generate_analysis_payload(create_plan_path, offline=True)
        skipped = payload["skipped_resources"]
        assert len(skipped) >= 1
        for item in skipped:
            assert "address" in item
            assert "reason" in item
            assert len(item["reason"]) > 0


@pytest.fixture(scope="module")
def running_test_server():
    """Starts a real ThreadingHTTPServer on an ephemeral port for testing."""
    # Port 5123 for test isolation
    test_port = 5123
    test_host = "127.0.0.1"
    server = create_server(
        host=test_host,
        port=test_port,
        plan_path=str(SAMPLE_PLANS_DIR / "create.json"),
        max_increase=200.0,
        offline=True,
    )
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    time.sleep(0.1)  # Allow server to bind

    base_url = f"http://{test_host}:{test_port}"
    yield {"base_url": base_url, "server": server}

    server.shutdown()
    server.server_close()


class TestWebHTTPServer:
    """Verifies live HTTP server responses, endpoints, and static file serving."""

    def test_get_root_html(self, running_test_server):
        base_url = running_test_server["base_url"]
        req = urllib.request.Request(f"{base_url}/")
        with urllib.request.urlopen(req) as resp:
            assert resp.status == 200
            content_type = resp.headers.get("Content-Type", "")
            assert "text/html" in content_type
            body = resp.read().decode("utf-8")
            assert "COSTGUARD" in body
            assert "Terraform Cost Firewall" in body
            assert "costComparisonChart" in body

    def test_get_styles_css(self, running_test_server):
        base_url = running_test_server["base_url"]
        req = urllib.request.Request(f"{base_url}/styles.css")
        with urllib.request.urlopen(req) as resp:
            assert resp.status == 200
            content_type = resp.headers.get("Content-Type", "")
            assert "text/css" in content_type
            body = resp.read().decode("utf-8")
            assert ":root" in body

    def test_get_app_js(self, running_test_server):
        base_url = running_test_server["base_url"]
        req = urllib.request.Request(f"{base_url}/app.js")
        with urllib.request.urlopen(req) as resp:
            assert resp.status == 200
            content_type = resp.headers.get("Content-Type", "")
            assert "javascript" in content_type
            body = resp.read().decode("utf-8")
            assert "renderDashboard" in body

    def test_get_api_analysis(self, running_test_server):
        base_url = running_test_server["base_url"]
        req = urllib.request.Request(f"{base_url}/api/analysis")
        with urllib.request.urlopen(req) as resp:
            assert resp.status == 200
            content_type = resp.headers.get("Content-Type", "")
            assert "application/json" in content_type
            data = json.loads(resp.read().decode("utf-8"))
            assert data["status"] == "success"
            assert data["budget"]["max_increase"] == 200.0
            assert "total_delta" in data["summary"]

    def test_get_api_plans(self, running_test_server):
        base_url = running_test_server["base_url"]
        req = urllib.request.Request(f"{base_url}/api/plans")
        with urllib.request.urlopen(req) as resp:
            assert resp.status == 200
            data = json.loads(resp.read().decode("utf-8"))
            assert "plans" in data
            assert "create.json" in data["plans"]
            assert "update.json" in data["plans"]

    def test_post_api_analyze_switch_plan(self, running_test_server):
        base_url = running_test_server["base_url"]
        post_data = json.dumps({"plan": "update.json", "max_increase": 50.0}).encode("utf-8")
        req = urllib.request.Request(
            f"{base_url}/api/analyze",
            data=post_data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req) as resp:
            assert resp.status == 200
            data = json.loads(resp.read().decode("utf-8"))
            assert data["status"] == "success"
            assert data["plan_file"] == "update.json"
            assert data["budget"]["max_increase"] == 50.0

    def test_post_api_analyze_non_existent_plan_404(self, running_test_server):
        base_url = running_test_server["base_url"]
        post_data = json.dumps({"plan": "non_existent_plan_12345.json"}).encode("utf-8")
        req = urllib.request.Request(
            f"{base_url}/api/analyze",
            data=post_data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with pytest.raises(urllib.error.HTTPError) as exc_info:
            urllib.request.urlopen(req)
        assert exc_info.value.code == 404

    def test_unknown_endpoint_returns_404(self, running_test_server):
        base_url = running_test_server["base_url"]
        req = urllib.request.Request(f"{base_url}/unknown/endpoint/path")
        with pytest.raises(urllib.error.HTTPError) as exc_info:
            urllib.request.urlopen(req)
        assert exc_info.value.code == 404


class TestCLIWebIntegration:
    """Verifies that the CLI exposes the --web and --port options."""

    def test_cli_parser_has_web_arguments(self):
        from costguard.cli import build_parser

        parser = build_parser()
        args = parser.parse_args(["--web", "--port", "5050", "--no-browser"])
        assert args.web is True
        assert args.port == 5050
        assert args.no_browser is True

    def test_cli_help_mentions_web(self, capsys):
        from costguard.cli import run_cli

        with pytest.raises(SystemExit) as exc:
            run_cli(["--help"])
        assert exc.value.code == 0
        captured = capsys.readouterr()
        assert "--web" in captured.out
        assert "--port" in captured.out
