"""
Tests for CostGuard Plan Parser (costguard.parser)
"""

import json
from pathlib import Path

import pytest

from costguard.models import ActionType
from costguard.parser import (
    extract_region,
    extract_sku,
    normalize_action,
    parse_plan,
    parse_plan_dict,
    parse_plan_file,
    parse_plan_json,
)

SAMPLE_PLANS_DIR = Path(__file__).parent.parent / "sample_plans"


class TestActionNormalization:
    def test_single_actions(self):
        assert normalize_action(["create"]) == ActionType.CREATE
        assert normalize_action(["delete"]) == ActionType.DELETE
        assert normalize_action(["update"]) == ActionType.UPDATE
        assert normalize_action(["no-op"]) == ActionType.NOOP
        assert normalize_action(["read"]) == ActionType.NOOP

    def test_replace_actions(self):
        # Terraform default replace
        assert normalize_action(["delete", "create"]) == ActionType.REPLACE
        # Terraform create-before-destroy replace
        assert normalize_action(["create", "delete"]) == ActionType.REPLACE

    def test_string_action(self):
        assert normalize_action("create") == ActionType.CREATE
        assert normalize_action("delete") == ActionType.DELETE
        assert normalize_action("update") == ActionType.UPDATE

    def test_invalid_actions(self):
        assert normalize_action([]) == ActionType.UNKNOWN
        assert normalize_action(None) == ActionType.UNKNOWN
        assert normalize_action(["unknown_action_xyz"]) == ActionType.UNKNOWN


class TestSKUExtraction:
    def test_aws_skus(self):
        # ec2 instance
        assert extract_sku("aws_instance", {"instance_type": "m5.large"}) == "m5.large"
        # rds db
        assert extract_sku("aws_db_instance", {"instance_class": "db.t3.medium"}) == "db.t3.medium"
        # elasticache
        assert extract_sku("aws_elasticache_cluster", {"node_type": "cache.t3.micro"}) == "cache.t3.micro"
        # ebs volume with size
        assert extract_sku("aws_ebs_volume", {"type": "gp3", "size": 100}) == "gp3 (100GB)"
        # eks node group
        assert extract_sku("aws_eks_node_group", {"instance_types": ["t3.medium"]}) == "t3.medium"

    def test_azure_skus(self):
        # linux vm
        assert extract_sku("azurerm_linux_virtual_machine", {"size": "Standard_B2s"}) == "Standard_B2s"
        # classic vm
        assert extract_sku("azurerm_virtual_machine", {"vm_size": "Standard_D2s_v3"}) == "Standard_D2s_v3"
        # managed disk
        assert extract_sku("azurerm_managed_disk", {"storage_account_type": "Premium_LRS", "disk_size_gb": 64}) == "Premium_LRS (64GB)"
        # mssql db
        assert extract_sku("azurerm_mssql_database", {"sku_name": "GP_Gen5_2"}) == "GP_Gen5_2"
        # storage account
        assert extract_sku("azurerm_storage_account", {"account_tier": "Standard", "account_replication_type": "LRS"}) == "Standard_LRS"

    def test_gcp_skus(self):
        # compute instance
        assert extract_sku("google_compute_instance", {"machine_type": "e2-medium"}) == "e2-medium"
        # compute disk
        assert extract_sku("google_compute_disk", {"type": "pd-ssd", "size": 200}) == "pd-ssd (200GB)"
        # cloud sql
        assert extract_sku("google_sql_database_instance", {"settings": {"tier": "db-f1-micro"}}) == "db-f1-micro"
        assert extract_sku("google_sql_database_instance", {"settings": [{"tier": "db-custom-2-7680"}]}) == "db-custom-2-7680"
        # cloud storage
        assert extract_sku("google_storage_bucket", {"storage_class": "NEARLINE"}) == "NEARLINE"

    def test_generic_fallback_sku(self):
        assert extract_sku("custom_server", {"instance_type": "c1.custom"}) == "c1.custom"
        assert extract_sku("custom_db", {"tier": "gold"}) == "gold"
        assert extract_sku("custom_app", {"sku": {"name": "basic_tier"}}) == "basic_tier"


class TestRegionExtraction:
    def test_aws_regions(self):
        # from AZ
        assert extract_region("aws_instance", {"availability_zone": "us-east-1a"}) == "us-east-1"
        assert extract_region("aws_instance", {"availability_zone": "eu-central-1b"}) == "eu-central-1"
        # from direct region
        assert extract_region("aws_instance", {"region": "us-west-2"}) == "us-west-2"
        # from ARN
        assert extract_region("aws_s3_bucket", {"arn": "arn:aws:s3:us-east-2:123456789012:bucket"}) == "us-east-2"

    def test_azure_regions(self):
        assert extract_region("azurerm_linux_virtual_machine", {"location": "eastus"}) == "eastus"
        assert extract_region("azurerm_storage_account", {"location": "West Europe"}) == "West Europe"

    def test_gcp_regions(self):
        assert extract_region("google_compute_instance", {"zone": "us-central1-a"}) == "us-central1"
        assert extract_region("google_compute_instance", {"region": "europe-west1"}) == "europe-west1"
        assert extract_region("google_storage_bucket", {"location": "US"}) == "US"


class TestPlanParsingActions:
    def test_create_action(self):
        create_file = SAMPLE_PLANS_DIR / "create.json"
        result = parse_plan_file(create_file)

        assert len(result.resource_changes) == 4
        assert result.summary["create"] == 4
        assert result.summary["total"] == 4

        # Verify AWS EC2 Create
        aws_rc = next(r for r in result.resource_changes if r.address == "aws_instance.web_server")
        assert aws_rc.action == ActionType.CREATE
        assert aws_rc.resource_type == "aws_instance"
        assert aws_rc.new_sku == "t3.xlarge"
        assert aws_rc.new_region == "us-east-1"
        assert aws_rc.before_state is None
        assert aws_rc.after_state is not None

        # Verify Azure VM Create
        azure_rc = next(r for r in result.resource_changes if r.address == "azurerm_linux_virtual_machine.api_backend")
        assert azure_rc.action == ActionType.CREATE
        assert azure_rc.new_sku == "Standard_D4s_v5"
        assert azure_rc.new_region == "eastus"

        # Verify GCP VM Create
        gcp_rc = next(r for r in result.resource_changes if r.address == "google_compute_instance.data_processor")
        assert gcp_rc.action == ActionType.CREATE
        assert gcp_rc.new_sku == "n2-standard-4"
        assert gcp_rc.new_region == "us-central1"

    def test_delete_action(self):
        delete_file = SAMPLE_PLANS_DIR / "delete.json"
        result = parse_plan_file(delete_file)

        assert len(result.resource_changes) == 3
        assert result.summary["delete"] == 3
        assert result.summary["total"] == 3

        # Verify AWS Delete
        aws_rc = next(r for r in result.resource_changes if r.address == "aws_instance.legacy_bastion")
        assert aws_rc.action == ActionType.DELETE
        assert aws_rc.resource_type == "aws_instance"
        assert aws_rc.old_sku == "t2.micro"
        assert aws_rc.old_region == "us-west-2"
        assert aws_rc.before_state is not None
        assert aws_rc.after_state is None

    def test_update_action(self):
        update_file = SAMPLE_PLANS_DIR / "update.json"
        result = parse_plan_file(update_file)

        assert len(result.resource_changes) == 3
        assert result.summary["update"] == 3

        # Verify AWS EC2 Resize Update
        aws_rc = next(r for r in result.resource_changes if r.address == "aws_instance.worker_node")
        assert aws_rc.action == ActionType.UPDATE
        assert aws_rc.old_sku == "t3.medium"
        assert aws_rc.new_sku == "c6i.2xlarge"
        assert aws_rc.old_region == "us-east-1"
        assert aws_rc.new_region == "us-east-1"
        assert aws_rc.before_state is not None
        assert aws_rc.after_state is not None

        # Verify GCP Cloud SQL Update
        gcp_rc = next(r for r in result.resource_changes if r.address == "google_sql_database_instance.master_db")
        assert gcp_rc.action == ActionType.UPDATE
        assert gcp_rc.old_sku == "db-n1-standard-1"
        assert gcp_rc.new_sku == "db-n1-standard-4"

    def test_replace_action(self):
        replace_file = SAMPLE_PLANS_DIR / "replace.json"
        result = parse_plan_file(replace_file)

        assert len(result.resource_changes) == 3
        assert result.summary["replace"] == 3

        # AWS replace with ["delete", "create"]
        aws_rc = next(r for r in result.resource_changes if r.address == "aws_instance.bastion_host")
        assert aws_rc.action == ActionType.REPLACE
        assert aws_rc.old_sku == "t3.nano"
        assert aws_rc.new_sku == "t3.small"

        # Azure replace with ["create", "delete"] (create-before-destroy)
        azure_rc = next(r for r in result.resource_changes if r.address == "azurerm_linux_virtual_machine.frontend")
        assert azure_rc.action == ActionType.REPLACE
        assert azure_rc.old_sku == "Standard_B2s"
        assert azure_rc.new_sku == "Standard_D2s_v5"


class TestEdgeCasesAndHostileInput:
    def test_missing_fields_and_no_crash(self):
        # Item with missing address, missing type, missing change
        partial_plan = {
            "resource_changes": [
                {
                    # No address, no type, no change
                },
                {
                    "address": "aws_instance.without_type",
                    "change": {
                        "actions": ["create"],
                        "after": {"instance_type": "t3.micro"}
                    }
                },
                {
                    "address": "aws_instance.without_change",
                    "type": "aws_instance"
                },
                {
                    "address": "custom_widget.foo",
                    "type": "custom_widget",
                    "change": {
                        "actions": ["update"],
                        # missing before and after
                    }
                }
            ]
        }
        result = parse_plan_dict(partial_plan)
        assert len(result.resource_changes) == 4
        # Warnings should have been generated for missing fields
        assert len(result.warnings) > 0
        # Check that deduced type worked for aws_instance.without_type
        assert result.resource_changes[1].resource_type == "aws_instance"
        assert result.resource_changes[1].new_sku == "t3.micro"

    def test_malformed_json_file(self):
        malformed_file = SAMPLE_PLANS_DIR / "malformed.json"
        result = parse_plan_file(malformed_file)
        assert len(result.resource_changes) == 0
        assert len(result.warnings) > 0
        assert any("Invalid JSON format" in w for w in result.warnings)

    def test_malformed_json_string(self):
        result = parse_plan_json("{{{not valid json")
        assert len(result.resource_changes) == 0
        assert len(result.warnings) > 0
        assert any("Invalid JSON format" in w for w in result.warnings)

    def test_empty_string_input(self):
        result = parse_plan_json("")
        assert len(result.resource_changes) == 0
        assert any("empty" in w.lower() for w in result.warnings)

    def test_empty_plan_dict(self):
        result = parse_plan_dict({})
        assert len(result.resource_changes) == 0
        assert any("missing 'resource_changes'" in w for w in result.warnings)

    def test_empty_resource_changes_list(self):
        result = parse_plan_dict({"resource_changes": []})
        assert len(result.resource_changes) == 0
        assert any("empty" in w for w in result.warnings)

    def test_hostile_plan_file(self):
        hostile_file = SAMPLE_PLANS_DIR / "hostile.json"
        result = parse_plan_file(hostile_file)
        # Should not crash and should parse all 5 items safely
        assert len(result.resource_changes) == 5
        assert len(result.warnings) > 0

    def test_unknown_resource_type_warning(self):
        plan = {
            "resource_changes": [
                {
                    "address": "alienship_saucer.mothership",
                    "type": "alienship_saucer",
                    "change": {
                        "actions": ["create"],
                        "after": {"hull_plating": "titanium"}
                    }
                }
            ]
        }
        result = parse_plan_dict(plan)
        assert len(result.resource_changes) == 1
        assert any("unrecognized or custom resource type" in w for w in result.warnings)

    def test_missing_sku_warning(self):
        plan = {
            "resource_changes": [
                {
                    "address": "aws_instance.bare",
                    "type": "aws_instance",
                    "change": {
                        "actions": ["create"],
                        "after": {"ami": "ami-12345"}
                    }
                }
            ]
        }
        result = parse_plan_dict(plan)
        assert len(result.resource_changes) == 1
        assert any("SKU / VM size could not be determined" in w for w in result.warnings)

    def test_missing_location_warning(self):
        plan = {
            "resource_changes": [
                {
                    "address": "aws_instance.no_loc",
                    "type": "aws_instance",
                    "change": {
                        "actions": ["create"],
                        "after": {"instance_type": "t3.micro"}
                    }
                }
            ]
        }
        result = parse_plan_dict(plan)
        assert len(result.resource_changes) == 1
        assert any("Location / region could not be determined" in w for w in result.warnings)

    def test_missing_before_and_after_state_warnings(self):
        plan = {
            "resource_changes": [
                {
                    "address": "aws_instance.no_before",
                    "type": "aws_instance",
                    "change": {
                        "actions": ["update"],
                        "before": None,
                        "after": {"instance_type": "t3.micro"}
                    }
                },
                {
                    "address": "aws_instance.no_after",
                    "type": "aws_instance",
                    "change": {
                        "actions": ["create"],
                        "before": None,
                        "after": None
                    }
                }
            ]
        }
        result = parse_plan_dict(plan)
        assert len(result.resource_changes) == 2
        assert any("missing 'before' state" in w for w in result.warnings)
        assert any("missing 'after' state" in w for w in result.warnings)

    def test_file_not_found(self):
        result = parse_plan_file("non_existent_file_path_123.json")
        assert len(result.resource_changes) == 0
        assert any("not found" in w for w in result.warnings)

    def test_universal_parse_plan_router(self):
        # test with path
        res_file = parse_plan(SAMPLE_PLANS_DIR / "create.json")
        assert res_file.summary["create"] == 4

        # test with dict
        res_dict = parse_plan({"resource_changes": []})
        assert len(res_dict.resource_changes) == 0

        # test with JSON string
        json_content = (SAMPLE_PLANS_DIR / "create.json").read_text(encoding="utf-8")
        res_str = parse_plan(json_content)
        assert res_str.summary["create"] == 4
